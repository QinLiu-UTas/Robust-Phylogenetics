# This script is to store the sitelh files for the Short branch length simulations.

# For different branch length simulations (e.g., Medium and Long), just change the path name in the script.


for k in $(seq 80 1 100);
do
for i in $(seq 1 1 400);
do

sed -n "2p" /swap-leaves-short/$k-per-results/$k-$i.sitelh > /swap-leaves-short/all_tree_sitelh_txt/$k-sitelh/$k-$i.sitelh

cut -c1-11 --complement  /swap-leaves-short/all_tree_sitelh_txt/$k-sitelh/$k-$i.sitelh > /swap-leaves-short/all_tree_sitelh_txt/$k-sitelh/$k-$i.txt

rm //swap-leaves-short/all_tree_sitelh_txt/$k-sitelh/$k-$i.sitelh

done
done

