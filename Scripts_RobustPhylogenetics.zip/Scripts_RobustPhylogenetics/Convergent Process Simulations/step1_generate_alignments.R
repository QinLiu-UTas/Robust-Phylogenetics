# This script is used to generate the alignments in the Convergent Process Simulations.
# This is for the 0.05-500JC-500GC simulations. 
# For other simulations, users need to change the parameters: t_short and nsites.

library(Matrix)

alpha <- 1
beta <- 5


Q <- matrix(c(-3*alpha, alpha, alpha, alpha, alpha, -3*alpha, alpha, alpha, alpha, alpha, -3*alpha, alpha, alpha, alpha, alpha, -3*alpha), ncol = 4)
Q
Q_bias <- matrix(c(-alpha-2*beta, beta, beta, alpha, alpha, -2*alpha - beta, beta, alpha, alpha, beta, -2*alpha - beta, alpha, alpha, beta, beta, -alpha-2*beta), byrow=TRUE, ncol = 4)
Q_bias

t_short<-0.05
t_long <- 0.2

P_short <- expm(t_short*Q)
P_short

P_long <- expm(t_long*Q)
P_long

P_short_bias <- expm(t_short*Q_bias)
P_short_bias

P_long_bias <- expm(t_long*Q_bias)
P_long_bias

# Function to generate the next state given a transition matrix
generate_next_state <- function(current_state, P) {
  # Get the row corresponding to the current state in the transition matrix
  probs <- P[current_state, ]
  # Sample the next state based on the transition probabilities
  next_state <- sample(1:4, size = 1, prob = probs)
  return(next_state)
}

# Convert numbers to nucleotides
convert_to_nucleotide <- function(state) {
  nucleotides <- c("a", "c", "g", "t")
  return(nucleotides[state])
}
ntaxa<-9
nsites<-500
nalignment<-400

# Create a list to store the 100 alignments
alignment_list <- vector("list", nalignment)

# Loop to generate 100 alignments
for (alignment_num in 1:nalignment) {
  
  # Initialise the alignment data frame for the current alignment
  df_alignment <- data.frame(matrix(nrow = ntaxa, ncol = nsites))
  row.names(df_alignment) <- c("I", "A", "B", "C", "D", "E", "F", "G", "H")
  
  # Simulate each of the 10000 sites for the current alignment
  for (i in 1:nsites) {
    
    # Simulate root state
    root <- sample(1:4, 1)
    
    # First level taxa (two children of the root)
    taxon1 <- generate_next_state(root, P_short)
    taxon_outgroup <- generate_next_state(root, P_short)

    # Second level taxa
    taxon_outgroup_1 <- generate_next_state(taxon_outgroup, P_short)
    taxon1_1 <- generate_next_state(taxon1, P_short)
    taxon1_2 <- generate_next_state(taxon1, P_short)

    
    # Third level taxa
    taxon_outgroup_1_1 <- generate_next_state(taxon_outgroup_1, P_short)
    
    taxon1_1_1 <- generate_next_state(taxon1_1, P_short) 
    taxon1_1_2 <- generate_next_state(taxon1_1, P_short)
    
    taxon1_2_1 <- generate_next_state(taxon1_2, P_short)
    taxon1_2_2 <- generate_next_state(taxon1_2, P_short)

    # Fourth level taxa
    taxon_outgroup_1_1_1 <- generate_next_state(taxon_outgroup_1_1, P_long_bias) #I - gc biased
    
    taxon1_1_1_1 <- generate_next_state(taxon1_1_1, P_long) #A 
    taxon1_1_1_2 <- generate_next_state(taxon1_1_1, P_long) #B 
    
    taxon1_1_2_1 <- generate_next_state(taxon1_1_2, P_long) #C
    taxon1_1_2_2 <- generate_next_state(taxon1_1_2, P_long) # D
    
    taxon1_2_1_1 <- generate_next_state(taxon1_2_1, P_long) #E
    taxon1_2_1_2 <- generate_next_state(taxon1_2_1, P_long) #F
    
    taxon1_2_2_1 <- generate_next_state(taxon1_2_2, P_long_bias) #G - gc biased
    taxon1_2_2_2 <- generate_next_state(taxon1_2_2, P_long) #H
    
    
    
    # Convert states to nucleotides and store in the alignment
    df_alignment[, i] <- c(convert_to_nucleotide(taxon_outgroup_1_1_1), #I
                           convert_to_nucleotide(taxon1_1_1_1), #A
                           convert_to_nucleotide(taxon1_1_1_2), #B
                           convert_to_nucleotide(taxon1_1_2_1), #C
                           convert_to_nucleotide(taxon1_1_2_2), #D
                           convert_to_nucleotide(taxon1_2_1_1), #E
                           convert_to_nucleotide(taxon1_2_1_2), #F
                           convert_to_nucleotide(taxon1_2_2_1), #G
                           convert_to_nucleotide(taxon1_2_2_2)) #H
  }
  
  # Store the current alignment in the list
  alignment_list[[alignment_num]] <- df_alignment
}
# Function to calculate nucleotide content
calculate_nucleotide_content <- function(taxon_seq) {
  total_sites <- length(taxon_seq)
  
  A_content <- sum(taxon_seq == "a") / total_sites
  C_content <- sum(taxon_seq == "c") / total_sites
  G_content <- sum(taxon_seq == "g") / total_sites
  T_content <- sum(taxon_seq == "t") / total_sites
  
  return(c(A_content, C_content, G_content, T_content))
}

# Initialise a matrix to store ACGT content for each taxon
acgt_content <- matrix(nrow = ntaxa, ncol = 4)
colnames(acgt_content) <- c("a", "c", "g", "t")
rownames(acgt_content) <- rownames(df_alignment)

# Calculate ACGT content for each taxon
for (taxon in rownames(alignment_list[[1]])) {
  acgt_content[taxon, ] <- calculate_nucleotide_content(alignment_list[[1]][taxon, ])
}

# Display the ACGT content for each taxon
acgt_content
######################################################
# convert a dataframe to a phy data.

library(ape)
library(phangorn)

true_tree<-read.tree(text="(I:0.35,(((A:0.2,B:0.2):0.05,(C:0.2,D:0.2):0.05):0.05,((E:0.2,F:0.2):0.05,(G:0.2,H:0.2):0.05):0.05):0.05);")
#true_tree<-read.tree(text="(I:0.29,(((A:0.2,B:0.2):0.03,(C:0.2,D:0.2):0.03):0.03,((E:0.2,F:0.2):0.03,(G:0.2,H:0.2):0.03):0.03):0.03);")
#true_tree<-read.tree(text="(I:0.23,(((A:0.2,B:0.2):0.01,(C:0.2,D:0.2):0.01):0.01,((E:0.2,F:0.2):0.01,(G:0.2,H:0.2):0.01):0.01):0.01);")
#true_tree<-read.tree(text="((((A:0.2,B:0.2):0.01,(C:0.2,D:0.2):0.01):0.01,((E:0.2,F:0.2):0.01,(G:0.2,H:0.2):0.01):0.01):0.005,I:0.225);")
#true_tree<-read.tree(text="(I:0.21,(((A:0.2,B:0.2):0.005,(C:0.2,D:0.2):0.005):0.0025,((E:0.2,F:0.2):0.005,(G:0.2,H:0.2):0.005):0.0025):0.0025);")

#true_tree<-read.tree("tree_9taxa.tre")
plot(true_tree)
edgelabels(round(true_tree$edge.length, 4), col = "black", bg = "lightgray",adj = c(0.9, 0.5),frame = "rect",cex=0.5)
cat(write.tree(true_tree))
is.rooted(true_tree)

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroFive")
write.tree(true_tree, file ="true_tree_9taxa.tre")

############################################################################################################
############################################################################################################
############################################################################################################
############################################################################################################
############################################################################################################
# generate some sites -JC model

# Create a list to store the 100 alignments
alignment_JC_list <- vector("list", nalignment)
nsites<-500

# Loop to generate 300 alignments
for (alignment_num in 1:nalignment) {
  
  # Initialise the alignment data frame for the current alignment
  df_alignment <- data.frame(matrix(nrow = ntaxa, ncol = nsites))
  row.names(df_alignment) <- c("I", "A", "B", "C", "D", "E", "F", "G", "H")
  
  # Simulate each of the 1000 sites for the current alignment
  for (i in 1:nsites) {
    
    # Simulate root state
    root <- sample(1:4, 1)
    
    # First level taxa (two children of the root)
    taxon1 <- generate_next_state(root, P_short)
    taxon_outgroup <- generate_next_state(root, P_short)
    #taxon1 <- generate_next_state(root, P_short_1)
    #taxon_outgroup <- generate_next_state(root, P_short_1)
    
    # Second level taxa
    taxon1_1 <- generate_next_state(taxon1, P_short)
    taxon1_2 <- generate_next_state(taxon1, P_short)
    
    taxon_outgroup_1 <- generate_next_state(taxon_outgroup, P_short)
    
    #taxon1_1 <- generate_next_state(taxon1, P_short_1)
    #taxon1_2 <- generate_next_state(taxon1, P_short_1)
    
    #taxon_outgroup_1 <- generate_next_state(taxon_outgroup, P_short_1)
    
    # Third level taxa
    taxon_outgroup_1_1 <- generate_next_state(taxon_outgroup_1, P_short)
    
    taxon1_1_1 <- generate_next_state(taxon1_1, P_short) 
    taxon1_1_2 <- generate_next_state(taxon1_1, P_short)
    
    taxon1_2_1 <- generate_next_state(taxon1_2, P_short)
    taxon1_2_2 <- generate_next_state(taxon1_2, P_short)
    
    #taxon_outgroup_1_1 <- generate_next_state(taxon_outgroup_1, P_short_2)
    
    # taxon1_1_1 <- generate_next_state(taxon1_1, P_short_2) 
    #taxon1_1_2 <- generate_next_state(taxon1_1, P_short_2)
    
    #taxon1_2_1 <- generate_next_state(taxon1_2, P_short_2)
    #taxon1_2_2 <- generate_next_state(taxon1_2, P_short_2)
    
    # Fourth level taxa
    taxon_outgroup_1_1_1 <- generate_next_state(taxon_outgroup_1_1, P_long) #I 
    
    taxon1_1_1_1 <- generate_next_state(taxon1_1_1, P_long) #A 
    taxon1_1_1_2 <- generate_next_state(taxon1_1_1, P_long) #B 
    
    taxon1_1_2_1 <- generate_next_state(taxon1_1_2, P_long) #C
    taxon1_1_2_2 <- generate_next_state(taxon1_1_2, P_long) # D
    
    taxon1_2_1_1 <- generate_next_state(taxon1_2_1, P_long) #E
    taxon1_2_1_2 <- generate_next_state(taxon1_2_1, P_long) #F
    
    taxon1_2_2_1 <- generate_next_state(taxon1_2_2, P_long) #G
    taxon1_2_2_2 <- generate_next_state(taxon1_2_2, P_long) #H
    
    
    
    # Convert states to nucleotides and store in the alignment
    df_alignment[, i] <- c(convert_to_nucleotide(taxon_outgroup_1_1_1), #I
                           convert_to_nucleotide(taxon1_1_1_1), #A
                           convert_to_nucleotide(taxon1_1_1_2), #B
                           convert_to_nucleotide(taxon1_1_2_1), #C
                           convert_to_nucleotide(taxon1_1_2_2), #D
                           convert_to_nucleotide(taxon1_2_1_1), #E
                           convert_to_nucleotide(taxon1_2_1_2), #F
                           convert_to_nucleotide(taxon1_2_2_1), #G
                           convert_to_nucleotide(taxon1_2_2_2)) #H
  }
  
  # Store the current alignment in the list
  alignment_JC_list[[alignment_num]] <- df_alignment
}
#########################################################
# Initialise a matrix to store ACGT content for each taxon
acgt_content <- matrix(nrow = ntaxa, ncol = 4)
colnames(acgt_content) <- c("a", "c", "g", "t")
rownames(acgt_content) <- rownames(df_alignment)

# Calculate ACGT content for each taxon
for (taxon in rownames(alignment_JC_list[[1]])) {
  acgt_content[taxon, ] <- calculate_nucleotide_content(alignment_JC_list[[1]][taxon, ])
}

# Display the ACGT content for each taxon
acgt_content
####################################################################
# Create an empty list to store the combined alignments
combined_alignments <- list()

# Use a loop to iterate over each element in the lists and combine them
for (i in seq_along(alignment_JC_list)) {
  # Combine the alignments for the same index from both lists
  combined_alignment <- cbind(alignment_JC_list[[i]], alignment_list[[i]])
  
  # Store the combined alignment in the result list
  combined_alignments[[i]] <- combined_alignment
}
########################################################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroFive/500sites")
for (i in 1:length(combined_alignments)){
  alignment<-as.DNAbin(as.matrix(combined_alignments[[i]]))
  # Create a unique filename for each alignment using the iteration index
  filename <- paste0(i+100, "-sim.fst")
  write.FASTA(alignment, file = filename)
  
}

save(alignment_list, alignment_JC_list,file = "alignment_AThousand_500sites.Rdata")

