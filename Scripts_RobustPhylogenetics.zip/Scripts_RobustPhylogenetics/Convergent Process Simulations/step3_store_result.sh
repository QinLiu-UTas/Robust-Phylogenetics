
# Store all results
for i in $(seq 50 1 100);
   do
     mkdir -p $i-per-results
done

for i in $(seq 50 1 100);
  do
     for Num in $(seq 1 1 400); 
     do     
        mv $i-$Num.iqtree $i-per-results
        mv $i-$Num.sitelh $i-per-results
        mv $i-$Num.treefile $i-per-results
    done
done

# Delete unnecessary files
rm *.bionj
rm *.ckp.gz
rm *.mldist
rm *.log
 

