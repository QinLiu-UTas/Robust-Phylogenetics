# This script is to abstract the site log-likelihood information.

# And to see what proportion of sites (or how many of the bottom 200 sites) from the last 200 sites were removed from the analysis.

# Load packages:
library(ape)
library(phangorn)
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation")
source("robust_phylo_functions.R")
library("stringr")
library(dplyr)

# g.read_tree reads the .treefile while g.read_tree_tre reads the .tre files
library(gtools)
g.read_sitelh_txt<-function(filedir_1){
  sitelh<-list()
  temp_sitelh<-list()
  for (i in 1:length(filedir_1)){
    setwd(filedir_1[i])
    list_directory <- dir(pattern = "*.txt") 
    # order: 1,2,3,4,5,...,100, instead of 1,10,11,12,13,...2,20,...
    list_directory <- mixedsort(list_directory)
    list_directory<-rev(list_directory)
    for (k in 1:length(list_directory)){
      temp_sitelh[[k]] <-read.table(list_directory[k])
    }
    sitelh[[i]]<-temp_sitelh
    setwd("..")
  }
  return(sitelh)
}
###########################

#################
# Now put it together.
# 200 sites

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites/all_tree_sitelh_txt")
dirfile_sitelh<-c("./100-sitelh",
                  "./99-sitelh", "./98-sitelh",
                  "./97-sitelh", "./96-sitelh",
                  "./95-sitelh", "./94-sitelh",
                  "./93-sitelh", "./92-sitelh",
                  "./91-sitelh", "./90-sitelh",
                  "./89-sitelh", "./88-sitelh",
                  "./87-sitelh", "./86-sitelh",
                  "./85-sitelh", "./84-sitelh",
                  "./83-sitelh", "./82-sitelh",
                  "./81-sitelh", "./80-sitelh",
                  "./79-sitelh", "./78-sitelh",
                  "./77-sitelh", "./76-sitelh",
                  "./75-sitelh", "./74-sitelh",
                  "./73-sitelh", "./72-sitelh",
                  "./71-sitelh", "./70-sitelh",
                  "./69-sitelh", "./68-sitelh",
                  "./67-sitelh", "./66-sitelh",
                  "./65-sitelh", "./64-sitelh",
                  "./63-sitelh", "./62-sitelh",
                  "./61-sitelh", "./60-sitelh",
                  "./59-sitelh", "./58-sitelh",
                  "./57-sitelh", "./56-sitelh",
                  "./55-sitelh", "./54-sitelh",
                  "./53-sitelh", "./52-sitelh",
                  "./51-sitelh", "./50-sitelh")


sitelh_list_0.01_200sites<-g.read_sitelh_txt(dirfile_sitelh)

length(sitelh_list_0.01_200sites)

################################################################################
# There are 400 txt file storing in 100per list.
site_lh_100per_0.01_200sites<-sitelh_list_0.01_200sites[[1]]
site_lh_99per_0.01_200sites<-sitelh_list_0.01_200sites[[2]]
site_lh_98per_0.01_200sites<-sitelh_list_0.01_200sites[[3]]
site_lh_97per_0.01_200sites<-sitelh_list_0.01_200sites[[4]]
site_lh_96per_0.01_200sites<-sitelh_list_0.01_200sites[[5]]
site_lh_95per_0.01_200sites<-sitelh_list_0.01_200sites[[6]]
site_lh_94per_0.01_200sites<-sitelh_list_0.01_200sites[[7]]
site_lh_93per_0.01_200sites<-sitelh_list_0.01_200sites[[8]]
site_lh_92per_0.01_200sites<-sitelh_list_0.01_200sites[[9]]
site_lh_91per_0.01_200sites<-sitelh_list_0.01_200sites[[10]]
site_lh_90per_0.01_200sites<-sitelh_list_0.01_200sites[[11]]

site_lh_89per_0.01_200sites<-sitelh_list_0.01_200sites[[12]]
site_lh_88per_0.01_200sites<-sitelh_list_0.01_200sites[[13]]
site_lh_87per_0.01_200sites<-sitelh_list_0.01_200sites[[14]]
site_lh_86per_0.01_200sites<-sitelh_list_0.01_200sites[[15]]
site_lh_85per_0.01_200sites<-sitelh_list_0.01_200sites[[16]]
site_lh_84per_0.01_200sites<-sitelh_list_0.01_200sites[[17]]
site_lh_83per_0.01_200sites<-sitelh_list_0.01_200sites[[18]]
site_lh_82per_0.01_200sites<-sitelh_list_0.01_200sites[[19]]
site_lh_81per_0.01_200sites<-sitelh_list_0.01_200sites[[20]]
site_lh_80per_0.01_200sites<-sitelh_list_0.01_200sites[[21]]

site_lh_79per_0.01_200sites<-sitelh_list_0.01_200sites[[22]]
site_lh_78per_0.01_200sites<-sitelh_list_0.01_200sites[[23]]
site_lh_77per_0.01_200sites<-sitelh_list_0.01_200sites[[24]]
site_lh_76per_0.01_200sites<-sitelh_list_0.01_200sites[[25]]
site_lh_75per_0.01_200sites<-sitelh_list_0.01_200sites[[26]]
site_lh_74per_0.01_200sites<-sitelh_list_0.01_200sites[[27]]
site_lh_73per_0.01_200sites<-sitelh_list_0.01_200sites[[28]]
site_lh_72per_0.01_200sites<-sitelh_list_0.01_200sites[[29]]
site_lh_71per_0.01_200sites<-sitelh_list_0.01_200sites[[30]]
site_lh_70per_0.01_200sites<-sitelh_list_0.01_200sites[[31]]

site_lh_69per_0.01_200sites<-sitelh_list_0.01_200sites[[32]]
site_lh_68per_0.01_200sites<-sitelh_list_0.01_200sites[[33]]
site_lh_67per_0.01_200sites<-sitelh_list_0.01_200sites[[34]]
site_lh_66per_0.01_200sites<-sitelh_list_0.01_200sites[[35]]
site_lh_65per_0.01_200sites<-sitelh_list_0.01_200sites[[36]]
site_lh_64per_0.01_200sites<-sitelh_list_0.01_200sites[[37]]
site_lh_63per_0.01_200sites<-sitelh_list_0.01_200sites[[38]]
site_lh_62per_0.01_200sites<-sitelh_list_0.01_200sites[[39]]
site_lh_61per_0.01_200sites<-sitelh_list_0.01_200sites[[40]]
site_lh_60per_0.01_200sites<-sitelh_list_0.01_200sites[[41]]

site_lh_59per_0.01_200sites<-sitelh_list_0.01_200sites[[42]]
site_lh_58per_0.01_200sites<-sitelh_list_0.01_200sites[[43]]
site_lh_57per_0.01_200sites<-sitelh_list_0.01_200sites[[44]]
site_lh_56per_0.01_200sites<-sitelh_list_0.01_200sites[[45]]
site_lh_55per_0.01_200sites<-sitelh_list_0.01_200sites[[46]]
site_lh_54per_0.01_200sites<-sitelh_list_0.01_200sites[[47]]
site_lh_53per_0.01_200sites<-sitelh_list_0.01_200sites[[48]]
site_lh_52per_0.01_200sites<-sitelh_list_0.01_200sites[[49]]
site_lh_51per_0.01_200sites<-sitelh_list_0.01_200sites[[50]]
site_lh_50per_0.01_200sites<-sitelh_list_0.01_200sites[[51]]

# save first
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites/")
save(sitelh_list_0.01_200sites, file = "sitelh_list_0.01_200sites.rdata")

load("sitelh_list_0.01_200sites.rdata")

# each list contains 400 vectors (or dataframes) recording the 1000 site likelihoods.
# m is the number of sites removed
g.count_site<-function(list,m){
  n=1000
  count_sites_greater_than_nsubtractm<-rep(0,length(list))
  for (i in 1:length(list)){
    df<-unlist(t(list[[i]]))
    df<-as.data.frame(df)
    colnames(df)<- "sitelh"
    df$site<- c(1:n)
    
    library(dplyr)
    # Rank the site likelihood
    # df <- df %>%
    #   mutate(order = rank(-sitelh))
    
    
    df <- df %>%
      arrange(desc(sitelh))
    
    df$rank<-c(1:n)
    
    subset_df <- df %>%
      filter(rank > ((n-m+1)))
    
    # hard coding 800 here, since we messed up the last 200 sites (801-1000)
    # So we want to find out how many removed sites were in the last 200 sites
    # Therefore, site number =>801 or site number >800
    nsite =800
    count_sites_greater_than_nsubtractm[i] <- sum(subset_df$site >nsite)
    
  }
  return(count_sites_greater_than_nsubtractm)
  
}

###################################
# 1 percent removed = 0.01*1000=10 sites
vec_99per_removed_1per_0.01_200sites<-g.count_site(site_lh_99per_0.01_200sites,m=10)
# Out of the 10 sites removed, how many sites were in the position of 801-1000?
vec_99per_removed_1per_0.01_200sites

vec_98per_removed_2per_0.01_200sites<-g.count_site(site_lh_98per_0.01_200sites,m=20)
# Out of the 20 sites removed, how many sites were in the position of 801-1000?
vec_98per_removed_2per_0.01_200sites

vec_97per_removed_3per_0.01_200sites<-g.count_site(site_lh_97per_0.01_200sites,m=30)
# Out of the 30 sites removed, how many sites were in the position of 801-1000?
vec_97per_removed_3per_0.01_200sites

vec_96per_removed_4per_0.01_200sites<-g.count_site(site_lh_96per_0.01_200sites,m=40)
# Out of the 4 sites removed, how many sites were in the position of 801-1000?
vec_96per_removed_4per_0.01_200sites

vec_95per_removed_5per_0.01_200sites<-g.count_site(site_lh_95per_0.01_200sites,m=50)
# Out of the 50 sites removed, how many sites were in the position of 801-1000?
vec_95per_removed_5per_0.01_200sites

vec_94per_removed_6per_0.01_200sites<-g.count_site(site_lh_94per_0.01_200sites,m=60)
# Out of the 60 sites removed, how many sites were in the position of 801-1000?
vec_94per_removed_6per_0.01_200sites

vec_93per_removed_7per_0.01_200sites<-g.count_site(site_lh_93per_0.01_200sites,m=70)
# Out of the 70 sites removed, how many sites were in the position of 801-1000?
vec_93per_removed_7per_0.01_200sites

vec_92per_removed_8per_0.01_200sites<-g.count_site(site_lh_92per_0.01_200sites,m=80)
# Out of the 80 sites removed, how many sites were in the position of 801-1000?
vec_92per_removed_8per_0.01_200sites

vec_91per_removed_9per_0.01_200sites<-g.count_site(site_lh_91per_0.01_200sites,m=90)
# Out of the 90 sites removed, how many sites were in the position of 801-1000?
vec_91per_removed_9per_0.01_200sites

vec_90per_removed_10per_0.01_200sites<-g.count_site(site_lh_90per_0.01_200sites,m=100)
# Out of the 100 sites removed, how many sites were in the position of 801-1000?
vec_90per_removed_10per_0.01_200sites
###########################################
vec_89per_removed_11per_0.01_200sites<-g.count_site(site_lh_89per_0.01_200sites,m=110)
# Out of the 110 sites removed, how many sites were in the position of 801-1000?
vec_89per_removed_11per_0.01_200sites

vec_88per_removed_12per_0.01_200sites<-g.count_site(site_lh_88per_0.01_200sites,m=120)
# Out of the 120 sites removed, how many sites were in the position of 801-1000?
vec_88per_removed_12per_0.01_200sites


vec_87per_removed_13per_0.01_200sites<-g.count_site(site_lh_87per_0.01_200sites,m=130)
# Out of the 130 sites removed, how many sites were in the position of 801-1000?
vec_87per_removed_13per_0.01_200sites

vec_86per_removed_14per_0.01_200sites<-g.count_site(site_lh_86per_0.01_200sites,m=140)
# Out of the 140 sites removed, how many sites were in the position of 801-1000?
vec_86per_removed_14per_0.01_200sites

vec_85per_removed_15per_0.01_200sites<-g.count_site(site_lh_85per_0.01_200sites,m=150)
# Out of the 150 sites removed, how many sites were in the position of 801-1000?
vec_85per_removed_15per_0.01_200sites

vec_84per_removed_16per_0.01_200sites<-g.count_site(site_lh_84per_0.01_200sites,m=160)
# Out of the 160 sites removed, how many sites were in the position of 801-1000?
vec_84per_removed_16per_0.01_200sites

vec_83per_removed_17per_0.01_200sites<-g.count_site(site_lh_83per_0.01_200sites,m=170)
# Out of the 170 sites removed, how many sites were in the position of 801-1000?
vec_83per_removed_17per_0.01_200sites

vec_82per_removed_18per_0.01_200sites<-g.count_site(site_lh_82per_0.01_200sites,m=180)
# Out of the 180 sites removed, how many sites were in the position of 801-1000?
vec_82per_removed_18per_0.01_200sites

vec_81per_removed_19per_0.01_200sites<-g.count_site(site_lh_81per_0.01_200sites,m=190)
# Out of the 190 sites removed, how many sites were in the position of 801-1000?
vec_81per_removed_19per_0.01_200sites

vec_80per_removed_20per_0.01_200sites<-g.count_site(site_lh_80per_0.01_200sites,m=200)
# Out of the 200 sites removed, how many sites were in the position of 801-1000?
vec_80per_removed_20per_0.01_200sites
###########################################
vec_79per_removed_21per_0.01_200sites<-g.count_site(site_lh_79per_0.01_200sites,m=210)
# Out of the 210 sites removed, how many sites were in the position of 801-1000?
vec_79per_removed_21per_0.01_200sites

vec_78per_removed_22per_0.01_200sites<-g.count_site(site_lh_78per_0.01_200sites,m=220)
# Out of the 220 sites removed, how many sites were in the position of 801-1000?
vec_78per_removed_22per_0.01_200sites

vec_77per_removed_23per_0.01_200sites<-g.count_site(site_lh_77per_0.01_200sites,m=230)
# Out of the 230 sites removed, how many sites were in the position of 801-1000?
vec_77per_removed_23per_0.01_200sites

vec_76per_removed_24per_0.01_200sites<-g.count_site(site_lh_76per_0.01_200sites,m=240)
# Out of the 240 sites removed, how many sites were in the position of 801-1000?
vec_76per_removed_24per_0.01_200sites

vec_75per_removed_25per_0.01_200sites<-g.count_site(site_lh_75per_0.01_200sites,m=250)
# Out of the 250 sites removed, how many sites were in the position of 801-1000?
vec_75per_removed_25per_0.01_200sites

vec_74per_removed_26per_0.01_200sites<-g.count_site(site_lh_74per_0.01_200sites,m=260)
# Out of the 260 sites removed, how many sites were in the position of 801-1000?
vec_74per_removed_26per_0.01_200sites

vec_73per_removed_27per_0.01_200sites<-g.count_site(site_lh_73per_0.01_200sites,m=270)
# Out of the 270 sites removed, how many sites were in the position of 801-1000?
vec_73per_removed_27per_0.01_200sites

vec_72per_removed_28per_0.01_200sites<-g.count_site(site_lh_72per_0.01_200sites,m=280)
# Out of the 280 sites removed, how many sites were in the position of 801-1000?
vec_72per_removed_28per_0.01_200sites

vec_71per_removed_29per_0.01_200sites<-g.count_site(site_lh_71per_0.01_200sites,m=290)
# Out of the 290 sites removed, how many sites were in the position of 801-1000?
vec_71per_removed_29per_0.01_200sites

vec_70per_removed_30per_0.01_200sites<-g.count_site(site_lh_70per_0.01_200sites,m=300)
# Out of the 300 sites removed, how many sites were in the position of 801-1000?

vec_70per_removed_30per_0.01_200sites
###########################################
vec_69per_removed_31per_0.01_200sites<-g.count_site(site_lh_69per_0.01_200sites,m=310)
# Out of the 310 sites removed, how many sites were in the position of 801-1000?
vec_69per_removed_31per_0.01_200sites

vec_68per_removed_32per_0.01_200sites<-g.count_site(site_lh_68per_0.01_200sites,m=320)
# Out of the 320 sites removed, how many sites were in the position of 801-1000?
vec_68per_removed_32per_0.01_200sites

vec_67per_removed_33per_0.01_200sites<-g.count_site(site_lh_67per_0.01_200sites,m=330)
# Out of the 330 sites removed, how many sites were in the position of 801-1000?
vec_67per_removed_33per_0.01_200sites

vec_66per_removed_34per_0.01_200sites<-g.count_site(site_lh_66per_0.01_200sites,m=340)
# Out of the 340 sites removed, how many sites were in the position of 801-1000?
vec_66per_removed_34per_0.01_200sites

vec_65per_removed_35per_0.01_200sites<-g.count_site(site_lh_65per_0.01_200sites,m=350)
# Out of the 350 sites removed, how many sites were in the position of 801-1000?
vec_65per_removed_35per_0.01_200sites

vec_64per_removed_36per_0.01_200sites<-g.count_site(site_lh_64per_0.01_200sites,m=360)
# Out of the 360 sites removed, how many sites were in the position of 801-1000?
vec_64per_removed_36per_0.01_200sites

vec_63per_removed_37per_0.01_200sites<-g.count_site(site_lh_63per_0.01_200sites,m=370)
# Out of the 370 sites removed, how many sites were in the position of 801-1000?
vec_63per_removed_37per_0.01_200sites

vec_62per_removed_38per_0.01_200sites<-g.count_site(site_lh_62per_0.01_200sites,m=380)
# Out of the 380 sites removed, how many sites were in the position of 801-1000?
vec_62per_removed_38per_0.01_200sites

vec_61per_removed_39per_0.01_200sites<-g.count_site(site_lh_61per_0.01_200sites,m=390)
# Out of the 390 sites removed, how many sites were in the position of 801-1000?
vec_61per_removed_39per_0.01_200sites

vec_60per_removed_40per_0.01_200sites<-g.count_site(site_lh_60per_0.01_200sites,m=400)
# Out of the 400 sites removed, how many sites were in the position of 801-1000?
vec_60per_removed_40per_0.01_200sites




###########################################
vec_59per_removed_41per_0.01_200sites<-g.count_site(site_lh_59per_0.01_200sites,m=410)
# Out of the 410 sites removed, how many sites were in the position of 800-1000?
vec_59per_removed_41per_0.01_200sites

vec_58per_removed_42per_0.01_200sites<-g.count_site(site_lh_58per_0.01_200sites,m=420)
# Out of the 420 sites removed, how many sites were in the position of 800-1000?
vec_58per_removed_42per_0.01_200sites

vec_57per_removed_43per_0.01_200sites<-g.count_site(site_lh_57per_0.01_200sites,m=430)
# Out of the 430 sites removed, how many sites were in the position of 800-1000?
vec_57per_removed_43per_0.01_200sites

vec_56per_removed_44per_0.01_200sites<-g.count_site(site_lh_56per_0.01_200sites,m=440)
# Out of the 440 sites removed, how many sites were in the position of 800-1000?
vec_56per_removed_44per_0.01_200sites

vec_55per_removed_45per_0.01_200sites<-g.count_site(site_lh_55per_0.01_200sites,m=450)
# Out of the 450 sites removed, how many sites were in the position of 800-1000?
vec_55per_removed_45per_0.01_200sites

vec_54per_removed_46per_0.01_200sites<-g.count_site(site_lh_54per_0.01_200sites,m=460)
# Out of the 460 sites removed, how many sites were in the position of 800-1000?
vec_54per_removed_46per_0.01_200sites

vec_53per_removed_47per_0.01_200sites<-g.count_site(site_lh_53per_0.01_200sites,m=470)
# Out of the 370 sites removed, how many sites were in the position of 800-1000?
vec_53per_removed_47per_0.01_200sites

vec_52per_removed_48per_0.01_200sites<-g.count_site(site_lh_52per_0.01_200sites,m=480)
# Out of the 480 sites removed, how many sites were in the position of 800-1000?
vec_52per_removed_48per_0.01_200sites

vec_51per_removed_49per_0.01_200sites<-g.count_site(site_lh_51per_0.01_200sites,m=490)
# Out of the 490 sites removed, how many sites were in the position of 800-1000?
vec_51per_removed_49per_0.01_200sites

vec_50per_removed_50per_0.01_200sites<-g.count_site(site_lh_50per_0.01_200sites,m=500)
# Out of the 500 sites removed, how many sites were in the position of 800-1000?
vec_50per_removed_50per_0.01_200sites



##################################
# combine

df_removed_0.01_200sites<-cbind(vec_99per_removed_1per_0.01_200sites,
                                vec_98per_removed_2per_0.01_200sites,
                                vec_97per_removed_3per_0.01_200sites,
                                vec_96per_removed_4per_0.01_200sites,
                                vec_95per_removed_5per_0.01_200sites,
                                vec_94per_removed_6per_0.01_200sites,
                                vec_93per_removed_7per_0.01_200sites,
                                vec_92per_removed_8per_0.01_200sites,
                                vec_91per_removed_9per_0.01_200sites,
                                vec_90per_removed_10per_0.01_200sites,
                                vec_89per_removed_11per_0.01_200sites,
                                vec_88per_removed_12per_0.01_200sites,
                                vec_87per_removed_13per_0.01_200sites,
                                vec_86per_removed_14per_0.01_200sites,
                                vec_85per_removed_15per_0.01_200sites,
                                vec_84per_removed_16per_0.01_200sites,
                                vec_83per_removed_17per_0.01_200sites,
                                vec_82per_removed_18per_0.01_200sites,
                                vec_81per_removed_19per_0.01_200sites,
                                vec_80per_removed_20per_0.01_200sites,
                                vec_79per_removed_21per_0.01_200sites,
                                vec_78per_removed_22per_0.01_200sites,
                                vec_77per_removed_23per_0.01_200sites,
                                vec_76per_removed_24per_0.01_200sites,
                                vec_75per_removed_25per_0.01_200sites,
                                vec_74per_removed_26per_0.01_200sites,
                                vec_73per_removed_27per_0.01_200sites,
                                vec_72per_removed_28per_0.01_200sites,
                                vec_71per_removed_29per_0.01_200sites,
                                vec_70per_removed_30per_0.01_200sites,
                                vec_69per_removed_31per_0.01_200sites,
                                vec_68per_removed_32per_0.01_200sites,
                                vec_67per_removed_33per_0.01_200sites,
                                vec_66per_removed_34per_0.01_200sites,
                                vec_65per_removed_35per_0.01_200sites,
                                vec_64per_removed_36per_0.01_200sites,
                                vec_63per_removed_37per_0.01_200sites,
                                vec_62per_removed_38per_0.01_200sites,
                                vec_61per_removed_39per_0.01_200sites,
                                vec_60per_removed_40per_0.01_200sites,
                                vec_59per_removed_41per_0.01_200sites,
                                vec_58per_removed_42per_0.01_200sites,
                                vec_57per_removed_43per_0.01_200sites,
                                vec_56per_removed_44per_0.01_200sites,
                                vec_55per_removed_45per_0.01_200sites,
                                vec_54per_removed_46per_0.01_200sites,
                                vec_53per_removed_47per_0.01_200sites,
                                vec_52per_removed_48per_0.01_200sites,
                                vec_51per_removed_49per_0.01_200sites,
                                vec_50per_removed_50per_0.01_200sites)

colnames(df_removed_0.01_200sites)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                                      "removed_5per","removed_6per","removed_7per","removed_8per",
                                      "removed_9per","removed_10per","removed_11per","removed_12per",
                                      "removed_13per","removed_14per","removed_15per","removed_16per",
                                      "removed_17per","removed_18per","removed_19per","removed_20per",
                                      "removed_21per","removed_22per","removed_23per","removed_24per",
                                      "removed_25per","removed_26per","removed_27per","removed_28per",
                                      "removed_29per","removed_30per",
                                      "removed_31per","removed_32per","removed_33per","removed_34per",
                                      "removed_35per","removed_36per","removed_37per","removed_38per",
                                      "removed_39per","removed_40per",
                                      "removed_41per","removed_42per","removed_43per","removed_44per",
                                      "removed_45per","removed_46per","removed_47per","removed_48per",
                                      "removed_49per","removed_50per")

df_mean_removed_0.01_200sites<-round(colMeans(df_removed_0.01_200sites),digits=4)

df_mean_removed_0.01_200sites<-as.data.frame(df_mean_removed_0.01_200sites)
is.data.frame(df_mean_removed_0.01_200sites)


rownames(df_mean_removed_0.01_200sites)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                                           "removed_5per","removed_6per","removed_7per","removed_8per",
                                           "removed_9per","removed_10per","removed_11per","removed_12per",
                                           "removed_13per","removed_14per","removed_15per","removed_16per",
                                           "removed_17per","removed_18per","removed_19per","removed_20per",
                                           "removed_21per","removed_22per","removed_23per","removed_24per",
                                           "removed_25per","removed_26per","removed_27per","removed_28per",
                                           "removed_29per","removed_30per",
                                           "removed_31per","removed_32per","removed_33per","removed_34per",
                                           "removed_35per","removed_36per","removed_37per","removed_38per",
                                           "removed_39per","removed_40per",
                                           "removed_41per","removed_42per","removed_43per","removed_44per",
                                           "removed_45per","removed_46per","removed_47per","removed_48per",
                                           "removed_49per","removed_50per")
colnames(df_mean_removed_0.01_200sites)<-"Mean_Num_sites_In801To1000_removed"


df_mean_removed_0.01_200sites

for (i in 1:nrow(df_mean_removed_0.01_200sites)){
  df_mean_removed_0.01_200sites$proption[i]<-round(df_mean_removed_0.01_200sites$Mean_Num_sites_In801To1000_removed[i]/(i*10),2)
}

df_mean_removed_0.01_200sites

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites")
save(df_removed_0.01_200sites,df_mean_removed_0.01_200sites, 
     file="info_site_removed_0.01_200sites.rdata")
#########################################################################################


#################
# Now put it together.
# 300 sites
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/300sites/all_tree_sitelh_txt")
dirfile_sitelh<-c("./100-sitelh",
                  "./99-sitelh", "./98-sitelh",
                  "./97-sitelh", "./96-sitelh",
                  "./95-sitelh", "./94-sitelh",
                  "./93-sitelh", "./92-sitelh",
                  "./91-sitelh", "./90-sitelh",
                  "./89-sitelh", "./88-sitelh",
                  "./87-sitelh", "./86-sitelh",
                  "./85-sitelh", "./84-sitelh",
                  "./83-sitelh", "./82-sitelh",
                  "./81-sitelh", "./80-sitelh",
                  "./79-sitelh", "./78-sitelh",
                  "./77-sitelh", "./76-sitelh",
                  "./75-sitelh", "./74-sitelh",
                  "./73-sitelh", "./72-sitelh",
                  "./71-sitelh", "./70-sitelh",
                  "./69-sitelh", "./68-sitelh",
                  "./67-sitelh", "./66-sitelh",
                  "./65-sitelh", "./64-sitelh",
                  "./63-sitelh", "./62-sitelh",
                  "./61-sitelh", "./60-sitelh",
                  "./59-sitelh", "./58-sitelh",
                  "./57-sitelh", "./56-sitelh",
                  "./55-sitelh", "./54-sitelh",
                  "./53-sitelh", "./52-sitelh",
                  "./51-sitelh", "./50-sitelh")


sitelh_list_0.01_300sites<-g.read_sitelh_txt(dirfile_sitelh)

length(sitelh_list_0.01_300sites)

# save first
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/300sites/")

save(sitelh_list_0.01_300sites, file = "sitelh_list_0.01_300sites.rdata")

################################################################################
# There are 100 txt file storing in 100per list.
site_lh_100per_0.01_300sites<-sitelh_list_0.01_300sites[[1]]
site_lh_99per_0.01_300sites<-sitelh_list_0.01_300sites[[2]]
site_lh_98per_0.01_300sites<-sitelh_list_0.01_300sites[[3]]
site_lh_97per_0.01_300sites<-sitelh_list_0.01_300sites[[4]]
site_lh_96per_0.01_300sites<-sitelh_list_0.01_300sites[[5]]
site_lh_95per_0.01_300sites<-sitelh_list_0.01_300sites[[6]]
site_lh_94per_0.01_300sites<-sitelh_list_0.01_300sites[[7]]
site_lh_93per_0.01_300sites<-sitelh_list_0.01_300sites[[8]]
site_lh_92per_0.01_300sites<-sitelh_list_0.01_300sites[[9]]
site_lh_91per_0.01_300sites<-sitelh_list_0.01_300sites[[10]]
site_lh_90per_0.01_300sites<-sitelh_list_0.01_300sites[[11]]

site_lh_89per_0.01_300sites<-sitelh_list_0.01_300sites[[12]]
site_lh_88per_0.01_300sites<-sitelh_list_0.01_300sites[[13]]
site_lh_87per_0.01_300sites<-sitelh_list_0.01_300sites[[14]]
site_lh_86per_0.01_300sites<-sitelh_list_0.01_300sites[[15]]
site_lh_85per_0.01_300sites<-sitelh_list_0.01_300sites[[16]]
site_lh_84per_0.01_300sites<-sitelh_list_0.01_300sites[[17]]
site_lh_83per_0.01_300sites<-sitelh_list_0.01_300sites[[18]]
site_lh_82per_0.01_300sites<-sitelh_list_0.01_300sites[[19]]
site_lh_81per_0.01_300sites<-sitelh_list_0.01_300sites[[20]]
site_lh_80per_0.01_300sites<-sitelh_list_0.01_300sites[[21]]

site_lh_79per_0.01_300sites<-sitelh_list_0.01_300sites[[22]]
site_lh_78per_0.01_300sites<-sitelh_list_0.01_300sites[[23]]
site_lh_77per_0.01_300sites<-sitelh_list_0.01_300sites[[24]]
site_lh_76per_0.01_300sites<-sitelh_list_0.01_300sites[[25]]
site_lh_75per_0.01_300sites<-sitelh_list_0.01_300sites[[26]]
site_lh_74per_0.01_300sites<-sitelh_list_0.01_300sites[[27]]
site_lh_73per_0.01_300sites<-sitelh_list_0.01_300sites[[28]]
site_lh_72per_0.01_300sites<-sitelh_list_0.01_300sites[[29]]
site_lh_71per_0.01_300sites<-sitelh_list_0.01_300sites[[30]]
site_lh_70per_0.01_300sites<-sitelh_list_0.01_300sites[[31]]

site_lh_69per_0.01_300sites<-sitelh_list_0.01_300sites[[32]]
site_lh_68per_0.01_300sites<-sitelh_list_0.01_300sites[[33]]
site_lh_67per_0.01_300sites<-sitelh_list_0.01_300sites[[34]]
site_lh_66per_0.01_300sites<-sitelh_list_0.01_300sites[[35]]
site_lh_65per_0.01_300sites<-sitelh_list_0.01_300sites[[36]]
site_lh_64per_0.01_300sites<-sitelh_list_0.01_300sites[[37]]
site_lh_63per_0.01_300sites<-sitelh_list_0.01_300sites[[38]]
site_lh_62per_0.01_300sites<-sitelh_list_0.01_300sites[[39]]
site_lh_61per_0.01_300sites<-sitelh_list_0.01_300sites[[40]]
site_lh_60per_0.01_300sites<-sitelh_list_0.01_300sites[[41]]

site_lh_59per_0.01_300sites<-sitelh_list_0.01_300sites[[42]]
site_lh_58per_0.01_300sites<-sitelh_list_0.01_300sites[[43]]
site_lh_57per_0.01_300sites<-sitelh_list_0.01_300sites[[44]]
site_lh_56per_0.01_300sites<-sitelh_list_0.01_300sites[[45]]
site_lh_55per_0.01_300sites<-sitelh_list_0.01_300sites[[46]]
site_lh_54per_0.01_300sites<-sitelh_list_0.01_300sites[[47]]
site_lh_53per_0.01_300sites<-sitelh_list_0.01_300sites[[48]]
site_lh_52per_0.01_300sites<-sitelh_list_0.01_300sites[[49]]
site_lh_51per_0.01_300sites<-sitelh_list_0.01_300sites[[50]]
site_lh_50per_0.01_300sites<-sitelh_list_0.01_300sites[[51]]

# each list contains 40 vectors (or dataframes) recording the 1000 site likelihoods.
# m is the number of sites removed
g.count_site<-function(list,m){
  n=1000
  count_sites_greater_than_nsubtractm<-rep(0,length(list))
  for (i in 1:length(list)){
    df<-unlist(t(list[[i]]))
    df<-as.data.frame(df)
    colnames(df)<- "sitelh"
    df$site<- c(1:n)
    
    library(dplyr)
    # Rank the site likelihood
    # df <- df %>%
    #   mutate(order = rank(-sitelh))
    
    
    df <- df %>%
      arrange(desc(sitelh))
    
    df$rank<-c(1:n)
    
    subset_df <- df %>%
      filter(rank > ((n-m+1)))
    
    # hard coding 700 here, since we messed up the last 300 sites (701-1000)
    # So we want to find out how many removed sites were in the last 300 sites
    # Therefore, site number >=701 or site number >700
    nsite =700
    count_sites_greater_than_nsubtractm[i] <- sum(subset_df$site >nsite)
    
  }
  return(count_sites_greater_than_nsubtractm)
  
}

###################################
vec_99per_removed_1per_0.01_300sites<-g.count_site(site_lh_99per_0.01_300sites,m=10)
# Out of the 10 sites removed, how many sites were in the position of 701-1000?
vec_99per_removed_1per_0.01_300sites

vec_98per_removed_2per_0.01_300sites<-g.count_site(site_lh_98per_0.01_300sites,m=20)
# Out of the 20 sites removed, how many sites were in the position of 701-1000?
vec_98per_removed_2per_0.01_300sites

vec_97per_removed_3per_0.01_300sites<-g.count_site(site_lh_97per_0.01_300sites,m=30)
# Out of the 30 sites removed, how many sites were in the position of 701-1000?
vec_97per_removed_3per_0.01_300sites

vec_96per_removed_4per_0.01_300sites<-g.count_site(site_lh_96per_0.01_300sites,m=40)
# Out of the 40 sites removed, how many sites were in the position of 701-1000?
vec_96per_removed_4per_0.01_300sites

vec_95per_removed_5per_0.01_300sites<-g.count_site(site_lh_95per_0.01_300sites,m=50)
# Out of the 50 sites removed, how many sites were in the position of 701-1000?
vec_95per_removed_5per_0.01_300sites

vec_94per_removed_6per_0.01_300sites<-g.count_site(site_lh_94per_0.01_300sites,m=60)
# Out of the 60 sites removed, how many sites were in the position of 701-1000?
vec_94per_removed_6per_0.01_300sites

vec_93per_removed_7per_0.01_300sites<-g.count_site(site_lh_93per_0.01_300sites,m=70)
# Out of the 70 sites removed, how many sites were in the position of 701-1000?
vec_93per_removed_7per_0.01_300sites

vec_92per_removed_8per_0.01_300sites<-g.count_site(site_lh_92per_0.01_300sites,m=80)
# Out of the 80 sites removed, how many sites were in the position of 701-1000?
vec_92per_removed_8per_0.01_300sites

vec_91per_removed_9per_0.01_300sites<-g.count_site(site_lh_91per_0.01_300sites,m=90)
# Out of the 90 sites removed, how many sites were in the position of 701-1000?
vec_91per_removed_9per_0.01_300sites

vec_90per_removed_10per_0.01_300sites<-g.count_site(site_lh_90per_0.01_300sites,m=100)
# Out of the 100 sites removed, how many sites were in the position of 701-1000?
vec_90per_removed_10per_0.01_300sites
###########################################
vec_89per_removed_11per_0.01_300sites<-g.count_site(site_lh_89per_0.01_300sites,m=110)
# Out of the 110 sites removed, how many sites were in the position of 701-1000?
vec_89per_removed_11per_0.01_300sites

vec_88per_removed_12per_0.01_300sites<-g.count_site(site_lh_88per_0.01_300sites,m=120)
# Out of the 120 sites removed, how many sites were in the position of 701-1000?
vec_88per_removed_12per_0.01_300sites


vec_87per_removed_13per_0.01_300sites<-g.count_site(site_lh_87per_0.01_300sites,m=130)
# Out of the 130 sites removed, how many sites were in the position of 701-1000?
vec_87per_removed_13per_0.01_300sites

vec_86per_removed_14per_0.01_300sites<-g.count_site(site_lh_86per_0.01_300sites,m=140)
# Out of the 140 sites removed, how many sites were in the position of 701-1000?
vec_86per_removed_14per_0.01_300sites

vec_85per_removed_15per_0.01_300sites<-g.count_site(site_lh_85per_0.01_300sites,m=150)
# Out of the 150 sites removed, how many sites were in the position of 701-1000?
vec_85per_removed_15per_0.01_300sites

vec_84per_removed_16per_0.01_300sites<-g.count_site(site_lh_84per_0.01_300sites,m=160)
# Out of the 160 sites removed, how many sites were in the position of 701-1000?
vec_84per_removed_16per_0.01_300sites

vec_83per_removed_17per_0.01_300sites<-g.count_site(site_lh_83per_0.01_300sites,m=170)
# Out of the 170 sites removed, how many sites were in the position of 701-1000?
vec_83per_removed_17per_0.01_300sites

vec_82per_removed_18per_0.01_300sites<-g.count_site(site_lh_82per_0.01_300sites,m=180)
# Out of the 180 sites removed, how many sites were in the position of 701-1000?
vec_82per_removed_18per_0.01_300sites

vec_81per_removed_19per_0.01_300sites<-g.count_site(site_lh_81per_0.01_300sites,m=190)
# Out of the 190 sites removed, how many sites were in the position of 701-1000?
vec_81per_removed_19per_0.01_300sites

vec_80per_removed_20per_0.01_300sites<-g.count_site(site_lh_80per_0.01_300sites,m=200)
# Out of the 200 sites removed, how many sites were in the position of 701-1000?
vec_80per_removed_20per_0.01_300sites
###########################################
vec_79per_removed_21per_0.01_300sites<-g.count_site(site_lh_79per_0.01_300sites,m=210)
# Out of the 210 sites removed, how many sites were in the position of 701-1000?
vec_79per_removed_21per_0.01_300sites

vec_78per_removed_22per_0.01_300sites<-g.count_site(site_lh_78per_0.01_300sites,m=220)
# Out of the 220 sites removed, how many sites were in the position of 701-1000?
vec_78per_removed_22per_0.01_300sites

vec_77per_removed_23per_0.01_300sites<-g.count_site(site_lh_77per_0.01_300sites,m=230)
# Out of the 230 sites removed, how many sites were in the position of 701-1000?
vec_77per_removed_23per_0.01_300sites

vec_76per_removed_24per_0.01_300sites<-g.count_site(site_lh_76per_0.01_300sites,m=240)
# Out of the 240 sites removed, how many sites were in the position of 701-1000?
vec_76per_removed_24per_0.01_300sites

vec_75per_removed_25per_0.01_300sites<-g.count_site(site_lh_75per_0.01_300sites,m=250)
# Out of the 250 sites removed, how many sites were in the position of 701-1000?
vec_75per_removed_25per_0.01_300sites

vec_74per_removed_26per_0.01_300sites<-g.count_site(site_lh_74per_0.01_300sites,m=260)
# Out of the 260 sites removed, how many sites were in the position of 701-1000?
vec_74per_removed_26per_0.01_300sites

vec_73per_removed_27per_0.01_300sites<-g.count_site(site_lh_73per_0.01_300sites,m=270)
# Out of the 270 sites removed, how many sites were in the position of 701-1000?
vec_73per_removed_27per_0.01_300sites

vec_72per_removed_28per_0.01_300sites<-g.count_site(site_lh_72per_0.01_300sites,m=280)
# Out of the 280 sites removed, how many sites were in the position of 701-1000?
vec_72per_removed_28per_0.01_300sites

vec_71per_removed_29per_0.01_300sites<-g.count_site(site_lh_71per_0.01_300sites,m=290)
# Out of the 290 sites removed, how many sites were in the position of 701-1000?
vec_71per_removed_29per_0.01_300sites

vec_70per_removed_30per_0.01_300sites<-g.count_site(site_lh_70per_0.01_300sites,m=300)
# Out of the 300 sites removed, how many sites were in the position of 701-1000?

vec_70per_removed_30per_0.01_300sites
###########################################
vec_69per_removed_31per_0.01_300sites<-g.count_site(site_lh_69per_0.01_300sites,m=310)
# Out of the 310 sites removed, how many sites were in the position of 701-1000?
vec_69per_removed_31per_0.01_300sites

vec_68per_removed_32per_0.01_300sites<-g.count_site(site_lh_68per_0.01_300sites,m=320)
# Out of the 320 sites removed, how many sites were in the position of 701-1000?
vec_68per_removed_32per_0.01_300sites

vec_67per_removed_33per_0.01_300sites<-g.count_site(site_lh_67per_0.01_300sites,m=330)
# Out of the 330 sites removed, how many sites were in the position of 701-1000?
vec_67per_removed_33per_0.01_300sites

vec_66per_removed_34per_0.01_300sites<-g.count_site(site_lh_66per_0.01_300sites,m=340)
# Out of the 340 sites removed, how many sites were in the position of 701-1000?
vec_66per_removed_34per_0.01_300sites

vec_65per_removed_35per_0.01_300sites<-g.count_site(site_lh_65per_0.01_300sites,m=350)
# Out of the 350 sites removed, how many sites were in the position of 701-1000?
vec_65per_removed_35per_0.01_300sites

vec_64per_removed_36per_0.01_300sites<-g.count_site(site_lh_64per_0.01_300sites,m=360)
# Out of the 360 sites removed, how many sites were in the position of 701-1000?
vec_64per_removed_36per_0.01_300sites

vec_63per_removed_37per_0.01_300sites<-g.count_site(site_lh_63per_0.01_300sites,m=370)
# Out of the 370 sites removed, how many sites were in the position of 701-1000?
vec_63per_removed_37per_0.01_300sites

vec_62per_removed_38per_0.01_300sites<-g.count_site(site_lh_62per_0.01_300sites,m=380)
# Out of the 380 sites removed, how many sites were in the position of 701-1000?
vec_62per_removed_38per_0.01_300sites

vec_61per_removed_39per_0.01_300sites<-g.count_site(site_lh_61per_0.01_300sites,m=390)
# Out of the 390 sites removed, how many sites were in the position of 701-1000?
vec_61per_removed_39per_0.01_300sites

vec_60per_removed_40per_0.01_300sites<-g.count_site(site_lh_60per_0.01_300sites,m=400)
# Out of the 400 sites removed, how many sites were in the position of 701-1000?
vec_60per_removed_40per_0.01_300sites


###########################################
vec_59per_removed_41per_0.01_300sites<-g.count_site(site_lh_59per_0.01_300sites,m=410)
# Out of the 410 sites removed, how many sites were in the position of 701-1000?
vec_59per_removed_41per_0.01_300sites

vec_58per_removed_42per_0.01_300sites<-g.count_site(site_lh_58per_0.01_300sites,m=420)
# Out of the 420 sites removed, how many sites were in the position of 701-1000?
vec_58per_removed_42per_0.01_300sites

vec_57per_removed_43per_0.01_300sites<-g.count_site(site_lh_57per_0.01_300sites,m=430)
# Out of the 430 sites removed, how many sites were in the position of 701-1000?
vec_57per_removed_43per_0.01_300sites

vec_56per_removed_44per_0.01_300sites<-g.count_site(site_lh_56per_0.01_300sites,m=440)
# Out of the 440 sites removed, how many sites were in the position of 701-1000?
vec_56per_removed_44per_0.01_300sites

vec_55per_removed_45per_0.01_300sites<-g.count_site(site_lh_55per_0.01_300sites,m=450)
# Out of the 450 sites removed, how many sites were in the position of 701-1000?
vec_55per_removed_45per_0.01_300sites

vec_54per_removed_46per_0.01_300sites<-g.count_site(site_lh_54per_0.01_300sites,m=460)
# Out of the 460 sites removed, how many sites were in the position of 701-1000?
vec_54per_removed_46per_0.01_300sites

vec_53per_removed_47per_0.01_300sites<-g.count_site(site_lh_53per_0.01_300sites,m=470)
# Out of the 470 sites removed, how many sites were in the position of 701-1000?
vec_53per_removed_47per_0.01_300sites

vec_52per_removed_48per_0.01_300sites<-g.count_site(site_lh_52per_0.01_300sites,m=480)
# Out of the 480 sites removed, how many sites were in the position of 701-1000?
vec_52per_removed_48per_0.01_300sites

vec_51per_removed_49per_0.01_300sites<-g.count_site(site_lh_51per_0.01_300sites,m=490)
# Out of the 490 sites removed, how many sites were in the position of 701-1000?
vec_51per_removed_49per_0.01_300sites

vec_50per_removed_50per_0.01_300sites<-g.count_site(site_lh_50per_0.01_300sites,m=500)
# Out of the 500 sites removed, how many sites were in the position of 701-1000?
vec_50per_removed_50per_0.01_300sites



##################################
# combine

df_removed_0.01_300sites<-cbind(vec_99per_removed_1per_0.01_300sites,
                                vec_98per_removed_2per_0.01_300sites,
                                vec_97per_removed_3per_0.01_300sites,
                                vec_96per_removed_4per_0.01_300sites,
                                vec_95per_removed_5per_0.01_300sites,
                                vec_94per_removed_6per_0.01_300sites,
                                vec_93per_removed_7per_0.01_300sites,
                                vec_92per_removed_8per_0.01_300sites,
                                vec_91per_removed_9per_0.01_300sites,
                                vec_90per_removed_10per_0.01_300sites,
                                vec_89per_removed_11per_0.01_300sites,
                                vec_88per_removed_12per_0.01_300sites,
                                vec_87per_removed_13per_0.01_300sites,
                                vec_86per_removed_14per_0.01_300sites,
                                vec_85per_removed_15per_0.01_300sites,
                                vec_84per_removed_16per_0.01_300sites,
                                vec_83per_removed_17per_0.01_300sites,
                                vec_82per_removed_18per_0.01_300sites,
                                vec_81per_removed_19per_0.01_300sites,
                                vec_80per_removed_20per_0.01_300sites,
                                vec_79per_removed_21per_0.01_300sites,
                                vec_78per_removed_22per_0.01_300sites,
                                vec_77per_removed_23per_0.01_300sites,
                                vec_76per_removed_24per_0.01_300sites,
                                vec_75per_removed_25per_0.01_300sites,
                                vec_74per_removed_26per_0.01_300sites,
                                vec_73per_removed_27per_0.01_300sites,
                                vec_72per_removed_28per_0.01_300sites,
                                vec_71per_removed_29per_0.01_300sites,
                                vec_70per_removed_30per_0.01_300sites,
                                vec_69per_removed_31per_0.01_300sites,
                                vec_68per_removed_32per_0.01_300sites,
                                vec_67per_removed_33per_0.01_300sites,
                                vec_66per_removed_34per_0.01_300sites,
                                vec_65per_removed_35per_0.01_300sites,
                                vec_64per_removed_36per_0.01_300sites,
                                vec_63per_removed_37per_0.01_300sites,
                                vec_62per_removed_38per_0.01_300sites,
                                vec_61per_removed_39per_0.01_300sites,
                                vec_60per_removed_40per_0.01_300sites,
                                vec_59per_removed_41per_0.01_300sites,
                                vec_58per_removed_42per_0.01_300sites,
                                vec_57per_removed_43per_0.01_300sites,
                                vec_56per_removed_44per_0.01_300sites,
                                vec_55per_removed_45per_0.01_300sites,
                                vec_54per_removed_46per_0.01_300sites,
                                vec_53per_removed_47per_0.01_300sites,
                                vec_52per_removed_48per_0.01_300sites,
                                vec_51per_removed_49per_0.01_300sites,
                                vec_50per_removed_50per_0.01_300sites)

colnames(df_removed_0.01_300sites)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                                      "removed_5per","removed_6per","removed_7per","removed_8per",
                                      "removed_9per","removed_10per","removed_11per","removed_12per",
                                      "removed_13per","removed_14per","removed_15per","removed_16per",
                                      "removed_17per","removed_18per","removed_19per","removed_20per",
                                      "removed_21per","removed_22per","removed_23per","removed_24per",
                                      "removed_25per","removed_26per","removed_27per","removed_28per",
                                      "removed_29per","removed_30per",
                                      "removed_31per","removed_32per","removed_33per","removed_34per",
                                      "removed_35per","removed_36per","removed_37per","removed_38per",
                                      "removed_39per","removed_40per",
                                      "removed_41per","removed_42per","removed_43per","removed_44per",
                                      "removed_45per","removed_46per","removed_47per","removed_48per",
                                      "removed_49per","removed_50per")

df_mean_removed_0.01_300sites<-round(colMeans(df_removed_0.01_300sites),digits=4)

df_mean_removed_0.01_300sites<-as.data.frame(df_mean_removed_0.01_300sites)
is.data.frame(df_mean_removed_0.01_300sites)


rownames(df_mean_removed_0.01_300sites)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                                           "removed_5per","removed_6per","removed_7per","removed_8per",
                                           "removed_9per","removed_10per","removed_11per","removed_12per",
                                           "removed_13per","removed_14per","removed_15per","removed_16per",
                                           "removed_17per","removed_18per","removed_19per","removed_20per",
                                           "removed_21per","removed_22per","removed_23per","removed_24per",
                                           "removed_25per","removed_26per","removed_27per","removed_28per",
                                           "removed_29per","removed_30per",
                                           "removed_31per","removed_32per","removed_33per","removed_34per",
                                           "removed_35per","removed_36per","removed_37per","removed_38per",
                                           "removed_39per","removed_40per",
                                           "removed_41per","removed_42per","removed_43per","removed_44per",
                                           "removed_45per","removed_46per","removed_47per","removed_48per",
                                           "removed_49per","removed_50per")
colnames(df_mean_removed_0.01_300sites)<-"Mean_Num_sites_In701To1000_removed"


df_mean_removed_0.01_300sites

for (i in 1:nrow(df_mean_removed_0.01_300sites)){
  df_mean_removed_0.01_300sites$proption[i]<-round(df_mean_removed_0.01_300sites$Mean_Num_sites_In701To1000_removed[i]/(i*10),2)
}

df_mean_removed_0.01_300sites

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/300sites/")

save(df_removed_0.01_300sites,df_mean_removed_0.01_300sites, 
     file="info_site_removed_0.01_300sites.rdata")
#################
# Now put it together.
# 500 sites
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/500sites/all_tree_sitelh_txt")
dirfile_sitelh<-c("./100-sitelh",
                  "./99-sitelh", "./98-sitelh",
                  "./97-sitelh", "./96-sitelh",
                  "./95-sitelh", "./94-sitelh",
                  "./93-sitelh", "./92-sitelh",
                  "./91-sitelh", "./90-sitelh",
                  "./89-sitelh", "./88-sitelh",
                  "./87-sitelh", "./86-sitelh",
                  "./85-sitelh", "./84-sitelh",
                  "./83-sitelh", "./82-sitelh",
                  "./81-sitelh", "./80-sitelh",
                  "./79-sitelh", "./78-sitelh",
                  "./77-sitelh", "./76-sitelh",
                  "./75-sitelh", "./74-sitelh",
                  "./73-sitelh", "./72-sitelh",
                  "./71-sitelh", "./70-sitelh",
                  "./69-sitelh", "./68-sitelh",
                  "./67-sitelh", "./66-sitelh",
                  "./65-sitelh", "./64-sitelh",
                  "./63-sitelh", "./62-sitelh",
                  "./61-sitelh", "./60-sitelh",
                  "./59-sitelh", "./58-sitelh",
                  "./57-sitelh", "./56-sitelh",
                  "./55-sitelh", "./54-sitelh",
                  "./53-sitelh", "./52-sitelh",
                  "./51-sitelh", "./50-sitelh")


sitelh_list_0.01_500sites<-g.read_sitelh_txt(dirfile_sitelh)

length(sitelh_list_0.01_500sites)
# save first
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/500sites")

save(sitelh_list_0.01_500sites, file = "sitelh_list_0.01_500sites.rdata")
################################################################################
# There are 100 txt file storing in 100per list.
site_lh_100per_0.01_500sites<-sitelh_list_0.01_500sites[[1]]
site_lh_99per_0.01_500sites<-sitelh_list_0.01_500sites[[2]]
site_lh_98per_0.01_500sites<-sitelh_list_0.01_500sites[[3]]
site_lh_97per_0.01_500sites<-sitelh_list_0.01_500sites[[4]]
site_lh_96per_0.01_500sites<-sitelh_list_0.01_500sites[[5]]
site_lh_95per_0.01_500sites<-sitelh_list_0.01_500sites[[6]]
site_lh_94per_0.01_500sites<-sitelh_list_0.01_500sites[[7]]
site_lh_93per_0.01_500sites<-sitelh_list_0.01_500sites[[8]]
site_lh_92per_0.01_500sites<-sitelh_list_0.01_500sites[[9]]
site_lh_91per_0.01_500sites<-sitelh_list_0.01_500sites[[10]]
site_lh_90per_0.01_500sites<-sitelh_list_0.01_500sites[[11]]

site_lh_89per_0.01_500sites<-sitelh_list_0.01_500sites[[12]]
site_lh_88per_0.01_500sites<-sitelh_list_0.01_500sites[[13]]
site_lh_87per_0.01_500sites<-sitelh_list_0.01_500sites[[14]]
site_lh_86per_0.01_500sites<-sitelh_list_0.01_500sites[[15]]
site_lh_85per_0.01_500sites<-sitelh_list_0.01_500sites[[16]]
site_lh_84per_0.01_500sites<-sitelh_list_0.01_500sites[[17]]
site_lh_83per_0.01_500sites<-sitelh_list_0.01_500sites[[18]]
site_lh_82per_0.01_500sites<-sitelh_list_0.01_500sites[[19]]
site_lh_81per_0.01_500sites<-sitelh_list_0.01_500sites[[20]]
site_lh_80per_0.01_500sites<-sitelh_list_0.01_500sites[[21]]

site_lh_79per_0.01_500sites<-sitelh_list_0.01_500sites[[22]]
site_lh_78per_0.01_500sites<-sitelh_list_0.01_500sites[[23]]
site_lh_77per_0.01_500sites<-sitelh_list_0.01_500sites[[24]]
site_lh_76per_0.01_500sites<-sitelh_list_0.01_500sites[[25]]
site_lh_75per_0.01_500sites<-sitelh_list_0.01_500sites[[26]]
site_lh_74per_0.01_500sites<-sitelh_list_0.01_500sites[[27]]
site_lh_73per_0.01_500sites<-sitelh_list_0.01_500sites[[28]]
site_lh_72per_0.01_500sites<-sitelh_list_0.01_500sites[[29]]
site_lh_71per_0.01_500sites<-sitelh_list_0.01_500sites[[30]]
site_lh_70per_0.01_500sites<-sitelh_list_0.01_500sites[[31]]

site_lh_69per_0.01_500sites<-sitelh_list_0.01_500sites[[32]]
site_lh_68per_0.01_500sites<-sitelh_list_0.01_500sites[[33]]
site_lh_67per_0.01_500sites<-sitelh_list_0.01_500sites[[34]]
site_lh_66per_0.01_500sites<-sitelh_list_0.01_500sites[[35]]
site_lh_65per_0.01_500sites<-sitelh_list_0.01_500sites[[36]]
site_lh_64per_0.01_500sites<-sitelh_list_0.01_500sites[[37]]
site_lh_63per_0.01_500sites<-sitelh_list_0.01_500sites[[38]]
site_lh_62per_0.01_500sites<-sitelh_list_0.01_500sites[[39]]
site_lh_61per_0.01_500sites<-sitelh_list_0.01_500sites[[40]]
site_lh_60per_0.01_500sites<-sitelh_list_0.01_500sites[[41]]

site_lh_59per_0.01_500sites<-sitelh_list_0.01_500sites[[42]]
site_lh_58per_0.01_500sites<-sitelh_list_0.01_500sites[[43]]
site_lh_57per_0.01_500sites<-sitelh_list_0.01_500sites[[44]]
site_lh_56per_0.01_500sites<-sitelh_list_0.01_500sites[[45]]
site_lh_55per_0.01_500sites<-sitelh_list_0.01_500sites[[46]]
site_lh_54per_0.01_500sites<-sitelh_list_0.01_500sites[[47]]
site_lh_53per_0.01_500sites<-sitelh_list_0.01_500sites[[48]]
site_lh_52per_0.01_500sites<-sitelh_list_0.01_500sites[[49]]
site_lh_51per_0.01_500sites<-sitelh_list_0.01_500sites[[50]]
site_lh_50per_0.01_500sites<-sitelh_list_0.01_500sites[[51]]

# each list contains 100 vectors (or dataframes) recording the 1000 site likelihoods.
# m is the number of sites removed
g.count_site<-function(list,m){
  n=1000
  count_sites_greater_than_nsubtractm<-rep(0,length(list))
  for (i in 1:length(list)){
    df<-unlist(t(list[[i]]))
    df<-as.data.frame(df)
    colnames(df)<- "sitelh"
    df$site<- c(1:n)
    
    library(dplyr)
    # Rank the site likelihood
    # df <- df %>%
    #   mutate(order = rank(-sitelh))
    
    
    df <- df %>%
      arrange(desc(sitelh))
    
    df$rank<-c(1:n)
    
    subset_df <- df %>%
      filter(rank > ((n-m+1)))
    
    # hard coding 500 here, since we messed up the last 501 sites (501-1000)
    # So we want to find out how many removed sites were in the last 5000 sites
    # Therefore, site number =>501 or site number >500
    nsite =500
    count_sites_greater_than_nsubtractm[i] <- sum(subset_df$site >nsite)
    
  }
  return(count_sites_greater_than_nsubtractm)
  
}

###################################
vec_99per_removed_1per_0.01_500sites<-g.count_site(site_lh_99per_0.01_500sites,m=10)
# Out of the 10 sites removed, how many sites were in the position of 501-1000?
vec_99per_removed_1per_0.01_500sites

vec_98per_removed_2per_0.01_500sites<-g.count_site(site_lh_98per_0.01_500sites,m=20)
# Out of the 20 sites removed, how many sites were in the position of 501-1000?
vec_98per_removed_2per_0.01_500sites

vec_97per_removed_3per_0.01_500sites<-g.count_site(site_lh_97per_0.01_500sites,m=30)
# Out of the 30 sites removed, how many sites were in the position of 501-1000?
vec_97per_removed_3per_0.01_500sites

vec_96per_removed_4per_0.01_500sites<-g.count_site(site_lh_96per_0.01_500sites,m=40)
# Out of the 40 sites removed, how many sites were in the position of 501-1000?
vec_96per_removed_4per_0.01_500sites

vec_95per_removed_5per_0.01_500sites<-g.count_site(site_lh_95per_0.01_500sites,m=50)
# Out of the 50 sites removed, how many sites were in the position of 501-1000?
vec_95per_removed_5per_0.01_500sites

vec_94per_removed_6per_0.01_500sites<-g.count_site(site_lh_94per_0.01_500sites,m=60)
# Out of the 60 sites removed, how many sites were in the position of 501-1000?
vec_94per_removed_6per_0.01_500sites

vec_93per_removed_7per_0.01_500sites<-g.count_site(site_lh_93per_0.01_500sites,m=70)
# Out of the 70 sites removed, how many sites were in the position of 501-1000?
vec_93per_removed_7per_0.01_500sites

vec_92per_removed_8per_0.01_500sites<-g.count_site(site_lh_92per_0.01_500sites,m=80)
# Out of the 80 sites removed, how many sites were in the position of 501-1000?
vec_92per_removed_8per_0.01_500sites

vec_91per_removed_9per_0.01_500sites<-g.count_site(site_lh_91per_0.01_500sites,m=90)
# Out of the 90 sites removed, how many sites were in the position of 501-1000?
vec_91per_removed_9per_0.01_500sites

vec_90per_removed_10per_0.01_500sites<-g.count_site(site_lh_90per_0.01_500sites,m=100)
# Out of the 100 sites removed, how many sites were in the position of 501-1000?
vec_90per_removed_10per_0.01_500sites
###########################################
vec_89per_removed_11per_0.01_500sites<-g.count_site(site_lh_89per_0.01_500sites,m=110)
# Out of the 110 sites removed, how many sites were in the position of 501-1000?
vec_89per_removed_11per_0.01_500sites

vec_88per_removed_12per_0.01_500sites<-g.count_site(site_lh_88per_0.01_500sites,m=120)
# Out of the 120 sites removed, how many sites were in the position of 501-1000?
vec_88per_removed_12per_0.01_500sites


vec_87per_removed_13per_0.01_500sites<-g.count_site(site_lh_87per_0.01_500sites,m=130)
# Out of the 130 sites removed, how many sites were in the position of 501-1000?
vec_87per_removed_13per_0.01_500sites

vec_86per_removed_14per_0.01_500sites<-g.count_site(site_lh_86per_0.01_500sites,m=140)
# Out of the 140 sites removed, how many sites were in the position of 501-1000?
vec_86per_removed_14per_0.01_500sites

vec_85per_removed_15per_0.01_500sites<-g.count_site(site_lh_85per_0.01_500sites,m=150)
# Out of the 150 sites removed, how many sites were in the position of 501-1000?
vec_85per_removed_15per_0.01_500sites

vec_84per_removed_16per_0.01_500sites<-g.count_site(site_lh_84per_0.01_500sites,m=160)
# Out of the 160 sites removed, how many sites were in the position of 501-1000?
vec_84per_removed_16per_0.01_500sites

vec_83per_removed_17per_0.01_500sites<-g.count_site(site_lh_83per_0.01_500sites,m=170)
# Out of the 170 sites removed, how many sites were in the position of 501-1000?
vec_83per_removed_17per_0.01_500sites

vec_82per_removed_18per_0.01_500sites<-g.count_site(site_lh_82per_0.01_500sites,m=180)
# Out of the 180 sites removed, how many sites were in the position of 501-1000?
vec_82per_removed_18per_0.01_500sites

vec_81per_removed_19per_0.01_500sites<-g.count_site(site_lh_81per_0.01_500sites,m=190)
# Out of the 190 sites removed, how many sites were in the position of 501-1000?
vec_81per_removed_19per_0.01_500sites

vec_80per_removed_20per_0.01_500sites<-g.count_site(site_lh_80per_0.01_500sites,m=200)
# Out of the 500 sites removed, how many sites were in the position of 501-1000?
vec_80per_removed_20per_0.01_500sites
###########################################
vec_79per_removed_21per_0.01_500sites<-g.count_site(site_lh_79per_0.01_500sites,m=210)
# Out of the 210 sites removed, how many sites were in the position of 501-1000?
vec_79per_removed_21per_0.01_500sites

vec_78per_removed_22per_0.01_500sites<-g.count_site(site_lh_78per_0.01_500sites,m=220)
# Out of the 220 sites removed, how many sites were in the position of 501-1000?
vec_78per_removed_22per_0.01_500sites

vec_77per_removed_23per_0.01_500sites<-g.count_site(site_lh_77per_0.01_500sites,m=230)
# Out of the 230 sites removed, how many sites were in the position of 501-1000?
vec_77per_removed_23per_0.01_500sites

vec_76per_removed_24per_0.01_500sites<-g.count_site(site_lh_76per_0.01_500sites,m=240)
# Out of the 240 sites removed, how many sites were in the position of 501-1000?
vec_76per_removed_24per_0.01_500sites

vec_75per_removed_25per_0.01_500sites<-g.count_site(site_lh_75per_0.01_500sites,m=250)
# Out of the 250 sites removed, how many sites were in the position of 501-1000?
vec_75per_removed_25per_0.01_500sites

vec_74per_removed_26per_0.01_500sites<-g.count_site(site_lh_74per_0.01_500sites,m=260)
# Out of the 260 sites removed, how many sites were in the position of 501-1000?
vec_74per_removed_26per_0.01_500sites

vec_73per_removed_27per_0.01_500sites<-g.count_site(site_lh_73per_0.01_500sites,m=270)
# Out of the 270 sites removed, how many sites were in the position of 501-1000?
vec_73per_removed_27per_0.01_500sites

vec_72per_removed_28per_0.01_500sites<-g.count_site(site_lh_72per_0.01_500sites,m=280)
# Out of the 280 sites removed, how many sites were in the position of 501-1000?
vec_72per_removed_28per_0.01_500sites

vec_71per_removed_29per_0.01_500sites<-g.count_site(site_lh_71per_0.01_500sites,m=290)
# Out of the 290 sites removed, how many sites were in the position of 501-1000?
vec_71per_removed_29per_0.01_500sites

vec_70per_removed_30per_0.01_500sites<-g.count_site(site_lh_70per_0.01_500sites,m=300)
# Out of the 300 sites removed, how many sites were in the position of 501-1000?

vec_70per_removed_30per_0.01_500sites
###########################################
vec_69per_removed_31per_0.01_500sites<-g.count_site(site_lh_69per_0.01_500sites,m=310)
# Out of the 310 sites removed, how many sites were in the position of 501-1000?
vec_69per_removed_31per_0.01_500sites

vec_68per_removed_32per_0.01_500sites<-g.count_site(site_lh_68per_0.01_500sites,m=320)
# Out of the 320 sites removed, how many sites were in the position of 501-1000?
vec_68per_removed_32per_0.01_500sites

vec_67per_removed_33per_0.01_500sites<-g.count_site(site_lh_67per_0.01_500sites,m=330)
# Out of the 330 sites removed, how many sites were in the position of 501-1000?
vec_67per_removed_33per_0.01_500sites

vec_66per_removed_34per_0.01_500sites<-g.count_site(site_lh_66per_0.01_500sites,m=340)
# Out of the 340 sites removed, how many sites were in the position of 501-1000?
vec_66per_removed_34per_0.01_500sites

vec_65per_removed_35per_0.01_500sites<-g.count_site(site_lh_65per_0.01_500sites,m=350)
# Out of the 350 sites removed, how many sites were in the position of 501-1000?
vec_65per_removed_35per_0.01_500sites

vec_64per_removed_36per_0.01_500sites<-g.count_site(site_lh_64per_0.01_500sites,m=360)
# Out of the 360 sites removed, how many sites were in the position of 501-1000?
vec_64per_removed_36per_0.01_500sites

vec_63per_removed_37per_0.01_500sites<-g.count_site(site_lh_63per_0.01_500sites,m=370)
# Out of the 370 sites removed, how many sites were in the position of 501-1000?
vec_63per_removed_37per_0.01_500sites

vec_62per_removed_38per_0.01_500sites<-g.count_site(site_lh_62per_0.01_500sites,m=380)
# Out of the 380 sites removed, how many sites were in the position of 501-1000?
vec_62per_removed_38per_0.01_500sites

vec_61per_removed_39per_0.01_500sites<-g.count_site(site_lh_61per_0.01_500sites,m=390)
# Out of the 390 sites removed, how many sites were in the position of 501-1000?
vec_61per_removed_39per_0.01_500sites

vec_60per_removed_40per_0.01_500sites<-g.count_site(site_lh_60per_0.01_500sites,m=400)
# Out of the 400 sites removed, how many sites were in the position of 501-1000?
vec_60per_removed_40per_0.01_500sites


###########################################
vec_59per_removed_41per_0.01_500sites<-g.count_site(site_lh_59per_0.01_500sites,m=410)
# Out of the 410 sites removed, how many sites were in the position of 501-1000?
vec_59per_removed_41per_0.01_500sites

vec_58per_removed_42per_0.01_500sites<-g.count_site(site_lh_58per_0.01_500sites,m=420)
# Out of the 420 sites removed, how many sites were in the position of 501-1000?
vec_58per_removed_42per_0.01_500sites

vec_57per_removed_43per_0.01_500sites<-g.count_site(site_lh_57per_0.01_500sites,m=430)
# Out of the 430 sites removed, how many sites were in the position of 501-1000?
vec_57per_removed_43per_0.01_500sites

vec_56per_removed_44per_0.01_500sites<-g.count_site(site_lh_56per_0.01_500sites,m=440)
# Out of the 440 sites removed, how many sites were in the position of 501-1000?
vec_56per_removed_44per_0.01_500sites

vec_55per_removed_45per_0.01_500sites<-g.count_site(site_lh_55per_0.01_500sites,m=450)
# Out of the 450 sites removed, how many sites were in the position of 501-1000?
vec_55per_removed_45per_0.01_500sites

vec_54per_removed_46per_0.01_500sites<-g.count_site(site_lh_54per_0.01_500sites,m=460)
# Out of the 460 sites removed, how many sites were in the position of 501-1000?
vec_54per_removed_46per_0.01_500sites

vec_53per_removed_47per_0.01_500sites<-g.count_site(site_lh_53per_0.01_500sites,m=470)
# Out of the 370 sites removed, how many sites were in the position of 501-1000?
vec_53per_removed_47per_0.01_500sites

vec_52per_removed_48per_0.01_500sites<-g.count_site(site_lh_52per_0.01_500sites,m=480)
# Out of the 480 sites removed, how many sites were in the position of 501-1000?
vec_52per_removed_48per_0.01_500sites

vec_51per_removed_49per_0.01_500sites<-g.count_site(site_lh_51per_0.01_500sites,m=490)
# Out of the 490 sites removed, how many sites were in the position of 501-1000?
vec_51per_removed_49per_0.01_500sites

vec_50per_removed_50per_0.01_500sites<-g.count_site(site_lh_50per_0.01_500sites,m=500)
# Out of the 500 sites removed, how many sites were in the position of 501-1000?
vec_50per_removed_50per_0.01_500sites



##################################
# combine

df_removed_0.01_500sites<-cbind(vec_99per_removed_1per_0.01_500sites,
                                vec_98per_removed_2per_0.01_500sites,
                                vec_97per_removed_3per_0.01_500sites,
                                vec_96per_removed_4per_0.01_500sites,
                                vec_95per_removed_5per_0.01_500sites,
                                vec_94per_removed_6per_0.01_500sites,
                                vec_93per_removed_7per_0.01_500sites,
                                vec_92per_removed_8per_0.01_500sites,
                                vec_91per_removed_9per_0.01_500sites,
                                vec_90per_removed_10per_0.01_500sites,
                                vec_89per_removed_11per_0.01_500sites,
                                vec_88per_removed_12per_0.01_500sites,
                                vec_87per_removed_13per_0.01_500sites,
                                vec_86per_removed_14per_0.01_500sites,
                                vec_85per_removed_15per_0.01_500sites,
                                vec_84per_removed_16per_0.01_500sites,
                                vec_83per_removed_17per_0.01_500sites,
                                vec_82per_removed_18per_0.01_500sites,
                                vec_81per_removed_19per_0.01_500sites,
                                vec_80per_removed_20per_0.01_500sites,
                                vec_79per_removed_21per_0.01_500sites,
                                vec_78per_removed_22per_0.01_500sites,
                                vec_77per_removed_23per_0.01_500sites,
                                vec_76per_removed_24per_0.01_500sites,
                                vec_75per_removed_25per_0.01_500sites,
                                vec_74per_removed_26per_0.01_500sites,
                                vec_73per_removed_27per_0.01_500sites,
                                vec_72per_removed_28per_0.01_500sites,
                                vec_71per_removed_29per_0.01_500sites,
                                vec_70per_removed_30per_0.01_500sites,
                                vec_69per_removed_31per_0.01_500sites,
                                vec_68per_removed_32per_0.01_500sites,
                                vec_67per_removed_33per_0.01_500sites,
                                vec_66per_removed_34per_0.01_500sites,
                                vec_65per_removed_35per_0.01_500sites,
                                vec_64per_removed_36per_0.01_500sites,
                                vec_63per_removed_37per_0.01_500sites,
                                vec_62per_removed_38per_0.01_500sites,
                                vec_61per_removed_39per_0.01_500sites,
                                vec_60per_removed_40per_0.01_500sites,
                                vec_59per_removed_41per_0.01_500sites,
                                vec_58per_removed_42per_0.01_500sites,
                                vec_57per_removed_43per_0.01_500sites,
                                vec_56per_removed_44per_0.01_500sites,
                                vec_55per_removed_45per_0.01_500sites,
                                vec_54per_removed_46per_0.01_500sites,
                                vec_53per_removed_47per_0.01_500sites,
                                vec_52per_removed_48per_0.01_500sites,
                                vec_51per_removed_49per_0.01_500sites,
                                vec_50per_removed_50per_0.01_500sites)

colnames(df_removed_0.01_500sites)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                                      "removed_5per","removed_6per","removed_7per","removed_8per",
                                      "removed_9per","removed_10per","removed_11per","removed_12per",
                                      "removed_13per","removed_14per","removed_15per","removed_16per",
                                      "removed_17per","removed_18per","removed_19per","removed_20per",
                                      "removed_21per","removed_22per","removed_23per","removed_24per",
                                      "removed_25per","removed_26per","removed_27per","removed_28per",
                                      "removed_29per","removed_30per",
                                      "removed_31per","removed_32per","removed_33per","removed_34per",
                                      "removed_35per","removed_36per","removed_37per","removed_38per",
                                      "removed_39per","removed_40per",
                                      "removed_41per","removed_42per","removed_43per","removed_44per",
                                      "removed_45per","removed_46per","removed_47per","removed_48per",
                                      "removed_49per","removed_50per")

df_mean_removed_0.01_500sites<-round(colMeans(df_removed_0.01_500sites),digits=4)

df_mean_removed_0.01_500sites<-as.data.frame(df_mean_removed_0.01_500sites)
is.data.frame(df_mean_removed_0.01_500sites)


rownames(df_mean_removed_0.01_500sites)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                                           "removed_5per","removed_6per","removed_7per","removed_8per",
                                           "removed_9per","removed_10per","removed_11per","removed_12per",
                                           "removed_13per","removed_14per","removed_15per","removed_16per",
                                           "removed_17per","removed_18per","removed_19per","removed_20per",
                                           "removed_21per","removed_22per","removed_23per","removed_24per",
                                           "removed_25per","removed_26per","removed_27per","removed_28per",
                                           "removed_29per","removed_30per",
                                           "removed_31per","removed_32per","removed_33per","removed_34per",
                                           "removed_35per","removed_36per","removed_37per","removed_38per",
                                           "removed_39per","removed_40per",
                                           "removed_41per","removed_42per","removed_43per","removed_44per",
                                           "removed_45per","removed_46per","removed_47per","removed_48per",
                                           "removed_49per","removed_50per")
colnames(df_mean_removed_0.01_500sites)<-"Mean_Num_sites_In501To1000_removed"


df_mean_removed_0.01_500sites

for (i in 1:nrow(df_mean_removed_0.01_500sites)){
  df_mean_removed_0.01_500sites$proption[i]<-round(df_mean_removed_0.01_500sites$Mean_Num_sites_In501To1000_removed[i]/(i*10),2)
}

df_mean_removed_0.01_500sites

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/")

save(df_removed_0.01_200sites,df_mean_removed_0.01_200sites, 
     df_removed_0.01_300sites,df_mean_removed_0.01_300sites, 
     df_removed_0.01_500sites,df_mean_removed_0.01_500sites, 
     file="info_site_removed_0.01.rdata")
