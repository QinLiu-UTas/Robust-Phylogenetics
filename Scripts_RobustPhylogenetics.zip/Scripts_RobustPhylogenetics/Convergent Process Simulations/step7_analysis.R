# This script is to analyse the results from IQTREE2. 
# This script is for the 0.01-800JC-200GC, 0.01-700JC-300GC and 0.01-500JC-500GC simulations.
# Other convergent process simulations use the same script but change the folder path names.

library(ape)
library(phangorn)

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation")
source("robust_phylo_functions.R")
library(TreeSim)
library("stringr")
library(dplyr)

##############################################################################
# Load functions
library(gtools)
# g.read_tree and g.read_tree_tre are very similar.
# g.read_tree reads the .treefile while g.read_tree_tre reads the .tre files
g.read_tree<-function(filedir_1){
  tree<-list()
  temp_list_tree_p1<-list()
  for (i in 1:length(filedir_1)){
    setwd(filedir_1[i])
    listtree_g <- dir(pattern = "*.treefile") 
    listtree_g <- mixedsort(listtree_g)
    listtree_g<-rev(listtree_g)
    list_all_g<-list()
    for (k in 1:length(listtree_g)){
      list_all_g[[k]] <-unroot(read.tree(listtree_g[k]))
    }
    tree[[i]]<-list_all_g
    setwd("..")
  }
  return(tree)
}

g.read_tree_tre <- function(filedir_1) {
  tree <- list()
  
  for (i in 1:length(filedir_1)) {
    setwd(filedir_1[i])
    listtree_g <- dir(pattern = "*.tre")
    
    # Sort the list of files by numeric values
    listtree_g <- mixedsort(listtree_g)
    listtree_g<-rev(listtree_g)
    
    list_all_g <- list()
    
    for (k in 1:length(listtree_g)) {
      list_all_g[[k]] <- unroot(read.tree(listtree_g[k]))
    }
    
    tree[[i]] <- list_all_g
    setwd("..")
  }
  
  return(tree)
}

PH85_topo<-function(true_tree, infer_tree){
  # Initialize an empty list
  dist_ph85 <- list()
  
  # Create and add empty vectors to the list
  for (i in 1:1:length(infer_tree)) {
    # Create an empty numeric vector
    dist_ph85[[i]] <- rep(-1,length(infer_tree[[i]]))   # Add the empty vector to the list
  }
  
  for (i in 1:length(infer_tree)){
    for (j in 1:length(infer_tree[[i]])){
      dist_ph85[[i]][[j]]<-as.vector(dist.topo(true_tree,infer_tree[[i]][[j]],method = "PH85"))
    }
  }
  return(dist_ph85)
}

KF_BE<-function(true_tree, infer_tree){
  # Initialize an empty list
  dist_KF <- list()
  
  # Create and add empty vectors to the list
  for (i in 1:1:length(infer_tree)) {
    # Create an empty numeric vector
    dist_KF[[i]] <- rep(-1,length(infer_tree[[i]]))   # Add the empty vector to the list
  }
  
  for (i in 1:length(infer_tree)){
    for (j in 1:length(infer_tree[[i]])){
      dist_KF[[i]][[j]]<-KF.dist(true_tree,infer_tree[[i]][[j]])
    }
  }
  return(dist_KF)
}
###############################################################################################


###############################################################################################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne")
true_tree_9taxa<-read.tree("true_tree_9taxa.tre")
plot(true_tree_9taxa)
edgelabels(round(true_tree_9taxa$edge.length, 4), col = "black", bg = "lightgray",adj = c(0.9, 0.5),frame = "rect",cex=0.7)
cat(write.tree(true_tree_9taxa))
is.rooted(true_tree_9taxa)
true_tree_9taxa<-unroot(true_tree_9taxa)

###############################################################
# 200sites
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites")
dirfile_tree<-c("./100-per-results",
                "./99-per-results", "./98-per-results",
                "./97-per-results", "./96-per-results",
                "./95-per-results", "./94-per-results",
                "./93-per-results", "./92-per-results",
                "./91-per-results", "./90-per-results",
                "./89-per-results", "./88-per-results",
                "./87-per-results", "./86-per-results",
                "./85-per-results", "./84-per-results",
                "./83-per-results", "./82-per-results",
                "./81-per-results", "./80-per-results",
                "./79-per-results", "./78-per-results",
                "./77-per-results", "./76-per-results",
                "./75-per-results", "./74-per-results",
                "./73-per-results", "./72-per-results",
                "./71-per-results", "./70-per-results",
                "./69-per-results", "./68-per-results",
                "./67-per-results", "./66-per-results",
                "./65-per-results", "./64-per-results",
                "./63-per-results", "./62-per-results",
                "./61-per-results", "./60-per-results",
                "./59-per-results", "./58-per-results",
                "./57-per-results", "./56-per-results",
                "./55-per-results", "./54-per-results",
                "./53-per-results", "./52-per-results",
                "./51-per-results", "./50-per-results")

tree_9taxa_0.01_200sites<-g.read_tree(dirfile_tree)
tree_9taxa_0.01_200sites_100per<-tree_9taxa_0.01_200sites[[1]]

tree_9taxa_0.01_200sites_99per<-tree_9taxa_0.01_200sites[[2]]
tree_9taxa_0.01_200sites_98per<-tree_9taxa_0.01_200sites[[3]]
tree_9taxa_0.01_200sites_97per<-tree_9taxa_0.01_200sites[[4]]
tree_9taxa_0.01_200sites_96per<-tree_9taxa_0.01_200sites[[5]]
tree_9taxa_0.01_200sites_95per<-tree_9taxa_0.01_200sites[[6]]
tree_9taxa_0.01_200sites_94per<-tree_9taxa_0.01_200sites[[7]]
tree_9taxa_0.01_200sites_93per<-tree_9taxa_0.01_200sites[[8]]
tree_9taxa_0.01_200sites_92per<-tree_9taxa_0.01_200sites[[9]]
tree_9taxa_0.01_200sites_91per<-tree_9taxa_0.01_200sites[[10]]
tree_9taxa_0.01_200sites_90per<-tree_9taxa_0.01_200sites[[11]]

tree_9taxa_0.01_200sites_89per<-tree_9taxa_0.01_200sites[[12]]
tree_9taxa_0.01_200sites_88per<-tree_9taxa_0.01_200sites[[13]]
tree_9taxa_0.01_200sites_87per<-tree_9taxa_0.01_200sites[[14]]
tree_9taxa_0.01_200sites_86per<-tree_9taxa_0.01_200sites[[15]]
tree_9taxa_0.01_200sites_85per<-tree_9taxa_0.01_200sites[[16]]
tree_9taxa_0.01_200sites_84per<-tree_9taxa_0.01_200sites[[17]]
tree_9taxa_0.01_200sites_83per<-tree_9taxa_0.01_200sites[[18]]
tree_9taxa_0.01_200sites_82per<-tree_9taxa_0.01_200sites[[19]]
tree_9taxa_0.01_200sites_81per<-tree_9taxa_0.01_200sites[[20]]
tree_9taxa_0.01_200sites_80per<-tree_9taxa_0.01_200sites[[21]]

tree_9taxa_0.01_200sites_79per<-tree_9taxa_0.01_200sites[[22]]
tree_9taxa_0.01_200sites_78per<-tree_9taxa_0.01_200sites[[23]]
tree_9taxa_0.01_200sites_77per<-tree_9taxa_0.01_200sites[[24]]
tree_9taxa_0.01_200sites_76per<-tree_9taxa_0.01_200sites[[25]]
tree_9taxa_0.01_200sites_75per<-tree_9taxa_0.01_200sites[[26]]
tree_9taxa_0.01_200sites_74per<-tree_9taxa_0.01_200sites[[27]]
tree_9taxa_0.01_200sites_73per<-tree_9taxa_0.01_200sites[[28]]
tree_9taxa_0.01_200sites_72per<-tree_9taxa_0.01_200sites[[29]]
tree_9taxa_0.01_200sites_71per<-tree_9taxa_0.01_200sites[[30]]
tree_9taxa_0.01_200sites_70per<-tree_9taxa_0.01_200sites[[31]]

tree_9taxa_0.01_200sites_69per<-tree_9taxa_0.01_200sites[[32]]
tree_9taxa_0.01_200sites_68per<-tree_9taxa_0.01_200sites[[33]]
tree_9taxa_0.01_200sites_67per<-tree_9taxa_0.01_200sites[[34]]
tree_9taxa_0.01_200sites_66per<-tree_9taxa_0.01_200sites[[35]]
tree_9taxa_0.01_200sites_65per<-tree_9taxa_0.01_200sites[[36]]
tree_9taxa_0.01_200sites_64per<-tree_9taxa_0.01_200sites[[37]]
tree_9taxa_0.01_200sites_63per<-tree_9taxa_0.01_200sites[[38]]
tree_9taxa_0.01_200sites_62per<-tree_9taxa_0.01_200sites[[39]]
tree_9taxa_0.01_200sites_61per<-tree_9taxa_0.01_200sites[[40]]
tree_9taxa_0.01_200sites_60per<-tree_9taxa_0.01_200sites[[41]]

tree_9taxa_0.01_200sites_59per<-tree_9taxa_0.01_200sites[[42]]
tree_9taxa_0.01_200sites_58per<-tree_9taxa_0.01_200sites[[43]]
tree_9taxa_0.01_200sites_57per<-tree_9taxa_0.01_200sites[[44]]
tree_9taxa_0.01_200sites_56per<-tree_9taxa_0.01_200sites[[45]]
tree_9taxa_0.01_200sites_55per<-tree_9taxa_0.01_200sites[[46]]
tree_9taxa_0.01_200sites_54per<-tree_9taxa_0.01_200sites[[47]]
tree_9taxa_0.01_200sites_53per<-tree_9taxa_0.01_200sites[[48]]
tree_9taxa_0.01_200sites_52per<-tree_9taxa_0.01_200sites[[49]]
tree_9taxa_0.01_200sites_51per<-tree_9taxa_0.01_200sites[[50]]
tree_9taxa_0.01_200sites_50per<-tree_9taxa_0.01_200sites[[51]]

cat(write.tree(tree_9taxa_0.01_200sites_50per[[13]]))
cat(write.tree(tree_9taxa_0.01_200sites_100per[[13]]))
#######################################################

true_tree_9taxa_0.01<-true_tree_9taxa
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites")
save(tree_9taxa_0.01_200sites_100per,
     tree_9taxa_0.01_200sites_99per,tree_9taxa_0.01_200sites_98per,
     tree_9taxa_0.01_200sites_97per,tree_9taxa_0.01_200sites_96per,
     tree_9taxa_0.01_200sites_95per,tree_9taxa_0.01_200sites_94per,
     tree_9taxa_0.01_200sites_93per,tree_9taxa_0.01_200sites_92per,
     tree_9taxa_0.01_200sites_91per,tree_9taxa_0.01_200sites_90per,
     tree_9taxa_0.01_200sites_89per,tree_9taxa_0.01_200sites_88per,
     tree_9taxa_0.01_200sites_87per,tree_9taxa_0.01_200sites_86per,
     tree_9taxa_0.01_200sites_85per,tree_9taxa_0.01_200sites_84per,
     tree_9taxa_0.01_200sites_83per,tree_9taxa_0.01_200sites_82per,
     tree_9taxa_0.01_200sites_81per,tree_9taxa_0.01_200sites_80per,
     tree_9taxa_0.01_200sites_79per,tree_9taxa_0.01_200sites_78per,
     tree_9taxa_0.01_200sites_77per,tree_9taxa_0.01_200sites_76per,
     tree_9taxa_0.01_200sites_75per,tree_9taxa_0.01_200sites_74per,
     tree_9taxa_0.01_200sites_73per,tree_9taxa_0.01_200sites_72per,
     tree_9taxa_0.01_200sites_71per,tree_9taxa_0.01_200sites_70per,
     tree_9taxa_0.01_200sites_69per,tree_9taxa_0.01_200sites_68per,
     tree_9taxa_0.01_200sites_67per,tree_9taxa_0.01_200sites_66per,
     tree_9taxa_0.01_200sites_65per,tree_9taxa_0.01_200sites_64per,
     tree_9taxa_0.01_200sites_63per,tree_9taxa_0.01_200sites_62per,
     tree_9taxa_0.01_200sites_61per,tree_9taxa_0.01_200sites_60per,
     tree_9taxa_0.01_200sites_59per,tree_9taxa_0.01_200sites_58per,
     tree_9taxa_0.01_200sites_57per,tree_9taxa_0.01_200sites_56per,
     tree_9taxa_0.01_200sites_55per,tree_9taxa_0.01_200sites_54per,
     tree_9taxa_0.01_200sites_53per,tree_9taxa_0.01_200sites_52per,
     tree_9taxa_0.01_200sites_51per,tree_9taxa_0.01_200sites_50per,
     true_tree_9taxa_0.01,tree_9taxa_0.01_200sites,
     file="tree_9taxa_0.01_200sites.Rdata")
######################################
# compare topologies and branch scores
is.rooted(true_tree_9taxa_0.01)
dist_ph85_tree_9taxa_0.01_200sites<-PH85_topo(true_tree_9taxa_0.01,tree_9taxa_0.01_200sites)

dist_ph85_tree_9taxa_0.01_200sites_100per<-dist_ph85_tree_9taxa_0.01_200sites[[1]]
dist_ph85_tree_9taxa_0.01_200sites_99per<-dist_ph85_tree_9taxa_0.01_200sites[[2]]
dist_ph85_tree_9taxa_0.01_200sites_98per<-dist_ph85_tree_9taxa_0.01_200sites[[3]]
dist_ph85_tree_9taxa_0.01_200sites_97per<-dist_ph85_tree_9taxa_0.01_200sites[[4]]
dist_ph85_tree_9taxa_0.01_200sites_96per<-dist_ph85_tree_9taxa_0.01_200sites[[5]]
dist_ph85_tree_9taxa_0.01_200sites_95per<-dist_ph85_tree_9taxa_0.01_200sites[[6]]
dist_ph85_tree_9taxa_0.01_200sites_94per<-dist_ph85_tree_9taxa_0.01_200sites[[7]]
dist_ph85_tree_9taxa_0.01_200sites_93per<-dist_ph85_tree_9taxa_0.01_200sites[[8]]
dist_ph85_tree_9taxa_0.01_200sites_92per<-dist_ph85_tree_9taxa_0.01_200sites[[9]]
dist_ph85_tree_9taxa_0.01_200sites_91per<-dist_ph85_tree_9taxa_0.01_200sites[[10]]
dist_ph85_tree_9taxa_0.01_200sites_90per<-dist_ph85_tree_9taxa_0.01_200sites[[11]]
dist_ph85_tree_9taxa_0.01_200sites_89per<-dist_ph85_tree_9taxa_0.01_200sites[[12]]
dist_ph85_tree_9taxa_0.01_200sites_88per<-dist_ph85_tree_9taxa_0.01_200sites[[13]]
dist_ph85_tree_9taxa_0.01_200sites_87per<-dist_ph85_tree_9taxa_0.01_200sites[[14]]
dist_ph85_tree_9taxa_0.01_200sites_86per<-dist_ph85_tree_9taxa_0.01_200sites[[15]]
dist_ph85_tree_9taxa_0.01_200sites_85per<-dist_ph85_tree_9taxa_0.01_200sites[[16]]
dist_ph85_tree_9taxa_0.01_200sites_84per<-dist_ph85_tree_9taxa_0.01_200sites[[17]]
dist_ph85_tree_9taxa_0.01_200sites_83per<-dist_ph85_tree_9taxa_0.01_200sites[[18]]
dist_ph85_tree_9taxa_0.01_200sites_82per<-dist_ph85_tree_9taxa_0.01_200sites[[19]]
dist_ph85_tree_9taxa_0.01_200sites_81per<-dist_ph85_tree_9taxa_0.01_200sites[[20]]
dist_ph85_tree_9taxa_0.01_200sites_80per<-dist_ph85_tree_9taxa_0.01_200sites[[21]]

dist_ph85_tree_9taxa_0.01_200sites_79per<-dist_ph85_tree_9taxa_0.01_200sites[[22]]
dist_ph85_tree_9taxa_0.01_200sites_78per<-dist_ph85_tree_9taxa_0.01_200sites[[23]]
dist_ph85_tree_9taxa_0.01_200sites_77per<-dist_ph85_tree_9taxa_0.01_200sites[[24]]
dist_ph85_tree_9taxa_0.01_200sites_76per<-dist_ph85_tree_9taxa_0.01_200sites[[25]]
dist_ph85_tree_9taxa_0.01_200sites_75per<-dist_ph85_tree_9taxa_0.01_200sites[[26]]
dist_ph85_tree_9taxa_0.01_200sites_74per<-dist_ph85_tree_9taxa_0.01_200sites[[27]]
dist_ph85_tree_9taxa_0.01_200sites_73per<-dist_ph85_tree_9taxa_0.01_200sites[[28]]
dist_ph85_tree_9taxa_0.01_200sites_72per<-dist_ph85_tree_9taxa_0.01_200sites[[29]]
dist_ph85_tree_9taxa_0.01_200sites_71per<-dist_ph85_tree_9taxa_0.01_200sites[[30]]
dist_ph85_tree_9taxa_0.01_200sites_70per<-dist_ph85_tree_9taxa_0.01_200sites[[31]]

dist_ph85_tree_9taxa_0.01_200sites_69per<-dist_ph85_tree_9taxa_0.01_200sites[[32]]
dist_ph85_tree_9taxa_0.01_200sites_68per<-dist_ph85_tree_9taxa_0.01_200sites[[33]]
dist_ph85_tree_9taxa_0.01_200sites_67per<-dist_ph85_tree_9taxa_0.01_200sites[[34]]
dist_ph85_tree_9taxa_0.01_200sites_66per<-dist_ph85_tree_9taxa_0.01_200sites[[35]]
dist_ph85_tree_9taxa_0.01_200sites_65per<-dist_ph85_tree_9taxa_0.01_200sites[[36]]
dist_ph85_tree_9taxa_0.01_200sites_64per<-dist_ph85_tree_9taxa_0.01_200sites[[37]]
dist_ph85_tree_9taxa_0.01_200sites_63per<-dist_ph85_tree_9taxa_0.01_200sites[[38]]
dist_ph85_tree_9taxa_0.01_200sites_62per<-dist_ph85_tree_9taxa_0.01_200sites[[39]]
dist_ph85_tree_9taxa_0.01_200sites_61per<-dist_ph85_tree_9taxa_0.01_200sites[[40]]
dist_ph85_tree_9taxa_0.01_200sites_60per<-dist_ph85_tree_9taxa_0.01_200sites[[41]]

dist_ph85_tree_9taxa_0.01_200sites_59per<-dist_ph85_tree_9taxa_0.01_200sites[[42]]
dist_ph85_tree_9taxa_0.01_200sites_58per<-dist_ph85_tree_9taxa_0.01_200sites[[43]]
dist_ph85_tree_9taxa_0.01_200sites_57per<-dist_ph85_tree_9taxa_0.01_200sites[[44]]
dist_ph85_tree_9taxa_0.01_200sites_56per<-dist_ph85_tree_9taxa_0.01_200sites[[45]]
dist_ph85_tree_9taxa_0.01_200sites_55per<-dist_ph85_tree_9taxa_0.01_200sites[[46]]
dist_ph85_tree_9taxa_0.01_200sites_54per<-dist_ph85_tree_9taxa_0.01_200sites[[47]]
dist_ph85_tree_9taxa_0.01_200sites_53per<-dist_ph85_tree_9taxa_0.01_200sites[[48]]
dist_ph85_tree_9taxa_0.01_200sites_52per<-dist_ph85_tree_9taxa_0.01_200sites[[49]]
dist_ph85_tree_9taxa_0.01_200sites_51per<-dist_ph85_tree_9taxa_0.01_200sites[[50]]
dist_ph85_tree_9taxa_0.01_200sites_50per<-dist_ph85_tree_9taxa_0.01_200sites[[51]]

######################################
######################################
# branch error

BranchError_tree_9taxa_0.01_200sites<-KF_BE(true_tree_9taxa_0.01,tree_9taxa_0.01_200sites)

BranchError_tree_9taxa_0.01_200sites_100per<-BranchError_tree_9taxa_0.01_200sites[[1]]

BranchError_tree_9taxa_0.01_200sites_99per<-BranchError_tree_9taxa_0.01_200sites[[2]]
BranchError_tree_9taxa_0.01_200sites_98per<-BranchError_tree_9taxa_0.01_200sites[[3]]
BranchError_tree_9taxa_0.01_200sites_97per<-BranchError_tree_9taxa_0.01_200sites[[4]]
BranchError_tree_9taxa_0.01_200sites_96per<-BranchError_tree_9taxa_0.01_200sites[[5]]
BranchError_tree_9taxa_0.01_200sites_95per<-BranchError_tree_9taxa_0.01_200sites[[6]]
BranchError_tree_9taxa_0.01_200sites_94per<-BranchError_tree_9taxa_0.01_200sites[[7]]
BranchError_tree_9taxa_0.01_200sites_93per<-BranchError_tree_9taxa_0.01_200sites[[8]]
BranchError_tree_9taxa_0.01_200sites_92per<-BranchError_tree_9taxa_0.01_200sites[[9]]
BranchError_tree_9taxa_0.01_200sites_91per<-BranchError_tree_9taxa_0.01_200sites[[10]]
BranchError_tree_9taxa_0.01_200sites_90per<-BranchError_tree_9taxa_0.01_200sites[[11]]

BranchError_tree_9taxa_0.01_200sites_89per<-BranchError_tree_9taxa_0.01_200sites[[12]]
BranchError_tree_9taxa_0.01_200sites_88per<-BranchError_tree_9taxa_0.01_200sites[[13]]
BranchError_tree_9taxa_0.01_200sites_87per<-BranchError_tree_9taxa_0.01_200sites[[14]]
BranchError_tree_9taxa_0.01_200sites_86per<-BranchError_tree_9taxa_0.01_200sites[[15]]
BranchError_tree_9taxa_0.01_200sites_85per<-BranchError_tree_9taxa_0.01_200sites[[16]]
BranchError_tree_9taxa_0.01_200sites_84per<-BranchError_tree_9taxa_0.01_200sites[[17]]
BranchError_tree_9taxa_0.01_200sites_83per<-BranchError_tree_9taxa_0.01_200sites[[18]]
BranchError_tree_9taxa_0.01_200sites_82per<-BranchError_tree_9taxa_0.01_200sites[[19]]
BranchError_tree_9taxa_0.01_200sites_81per<-BranchError_tree_9taxa_0.01_200sites[[20]]
BranchError_tree_9taxa_0.01_200sites_80per<-BranchError_tree_9taxa_0.01_200sites[[21]]

BranchError_tree_9taxa_0.01_200sites_79per<-BranchError_tree_9taxa_0.01_200sites[[22]]
BranchError_tree_9taxa_0.01_200sites_78per<-BranchError_tree_9taxa_0.01_200sites[[23]]
BranchError_tree_9taxa_0.01_200sites_77per<-BranchError_tree_9taxa_0.01_200sites[[24]]
BranchError_tree_9taxa_0.01_200sites_76per<-BranchError_tree_9taxa_0.01_200sites[[25]]
BranchError_tree_9taxa_0.01_200sites_75per<-BranchError_tree_9taxa_0.01_200sites[[26]]
BranchError_tree_9taxa_0.01_200sites_74per<-BranchError_tree_9taxa_0.01_200sites[[27]]
BranchError_tree_9taxa_0.01_200sites_73per<-BranchError_tree_9taxa_0.01_200sites[[28]]
BranchError_tree_9taxa_0.01_200sites_72per<-BranchError_tree_9taxa_0.01_200sites[[29]]
BranchError_tree_9taxa_0.01_200sites_71per<-BranchError_tree_9taxa_0.01_200sites[[30]]
BranchError_tree_9taxa_0.01_200sites_70per<-BranchError_tree_9taxa_0.01_200sites[[31]]

BranchError_tree_9taxa_0.01_200sites_69per<-BranchError_tree_9taxa_0.01_200sites[[32]]
BranchError_tree_9taxa_0.01_200sites_68per<-BranchError_tree_9taxa_0.01_200sites[[33]]
BranchError_tree_9taxa_0.01_200sites_67per<-BranchError_tree_9taxa_0.01_200sites[[34]]
BranchError_tree_9taxa_0.01_200sites_66per<-BranchError_tree_9taxa_0.01_200sites[[35]]
BranchError_tree_9taxa_0.01_200sites_65per<-BranchError_tree_9taxa_0.01_200sites[[36]]
BranchError_tree_9taxa_0.01_200sites_64per<-BranchError_tree_9taxa_0.01_200sites[[37]]
BranchError_tree_9taxa_0.01_200sites_63per<-BranchError_tree_9taxa_0.01_200sites[[38]]
BranchError_tree_9taxa_0.01_200sites_62per<-BranchError_tree_9taxa_0.01_200sites[[39]]
BranchError_tree_9taxa_0.01_200sites_61per<-BranchError_tree_9taxa_0.01_200sites[[40]]
BranchError_tree_9taxa_0.01_200sites_60per<-BranchError_tree_9taxa_0.01_200sites[[41]]

BranchError_tree_9taxa_0.01_200sites_59per<-BranchError_tree_9taxa_0.01_200sites[[42]]
BranchError_tree_9taxa_0.01_200sites_58per<-BranchError_tree_9taxa_0.01_200sites[[43]]
BranchError_tree_9taxa_0.01_200sites_57per<-BranchError_tree_9taxa_0.01_200sites[[44]]
BranchError_tree_9taxa_0.01_200sites_56per<-BranchError_tree_9taxa_0.01_200sites[[45]]
BranchError_tree_9taxa_0.01_200sites_55per<-BranchError_tree_9taxa_0.01_200sites[[46]]
BranchError_tree_9taxa_0.01_200sites_54per<-BranchError_tree_9taxa_0.01_200sites[[47]]
BranchError_tree_9taxa_0.01_200sites_53per<-BranchError_tree_9taxa_0.01_200sites[[48]]
BranchError_tree_9taxa_0.01_200sites_52per<-BranchError_tree_9taxa_0.01_200sites[[49]]
BranchError_tree_9taxa_0.01_200sites_51per<-BranchError_tree_9taxa_0.01_200sites[[50]]
BranchError_tree_9taxa_0.01_200sites_50per<-BranchError_tree_9taxa_0.01_200sites[[51]]

#################################################

# save
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites")

save(dist_ph85_tree_9taxa_0.01_200sites_100per,
     dist_ph85_tree_9taxa_0.01_200sites_99per,
     dist_ph85_tree_9taxa_0.01_200sites_98per,
     dist_ph85_tree_9taxa_0.01_200sites_97per,
     dist_ph85_tree_9taxa_0.01_200sites_96per,
     dist_ph85_tree_9taxa_0.01_200sites_95per,
     dist_ph85_tree_9taxa_0.01_200sites_94per,
     dist_ph85_tree_9taxa_0.01_200sites_93per,
     dist_ph85_tree_9taxa_0.01_200sites_92per,
     dist_ph85_tree_9taxa_0.01_200sites_91per,
     dist_ph85_tree_9taxa_0.01_200sites_90per,
     dist_ph85_tree_9taxa_0.01_200sites_89per,
     dist_ph85_tree_9taxa_0.01_200sites_88per,
     dist_ph85_tree_9taxa_0.01_200sites_87per,
     dist_ph85_tree_9taxa_0.01_200sites_86per,
     dist_ph85_tree_9taxa_0.01_200sites_85per,
     dist_ph85_tree_9taxa_0.01_200sites_84per,
     dist_ph85_tree_9taxa_0.01_200sites_83per,
     dist_ph85_tree_9taxa_0.01_200sites_82per,
     dist_ph85_tree_9taxa_0.01_200sites_81per,
     dist_ph85_tree_9taxa_0.01_200sites_80per,
     dist_ph85_tree_9taxa_0.01_200sites_79per,
     dist_ph85_tree_9taxa_0.01_200sites_78per,
     dist_ph85_tree_9taxa_0.01_200sites_77per,
     dist_ph85_tree_9taxa_0.01_200sites_76per,
     dist_ph85_tree_9taxa_0.01_200sites_75per,
     dist_ph85_tree_9taxa_0.01_200sites_74per,
     dist_ph85_tree_9taxa_0.01_200sites_73per,
     dist_ph85_tree_9taxa_0.01_200sites_72per,
     dist_ph85_tree_9taxa_0.01_200sites_71per,
     dist_ph85_tree_9taxa_0.01_200sites_70per,
     dist_ph85_tree_9taxa_0.01_200sites_69per,
     dist_ph85_tree_9taxa_0.01_200sites_68per,
     dist_ph85_tree_9taxa_0.01_200sites_67per,
     dist_ph85_tree_9taxa_0.01_200sites_66per,
     dist_ph85_tree_9taxa_0.01_200sites_65per,
     dist_ph85_tree_9taxa_0.01_200sites_64per,
     dist_ph85_tree_9taxa_0.01_200sites_63per,
     dist_ph85_tree_9taxa_0.01_200sites_62per,
     dist_ph85_tree_9taxa_0.01_200sites_61per,
     dist_ph85_tree_9taxa_0.01_200sites_60per,
     dist_ph85_tree_9taxa_0.01_200sites_59per,
     dist_ph85_tree_9taxa_0.01_200sites_58per,
     dist_ph85_tree_9taxa_0.01_200sites_57per,
     dist_ph85_tree_9taxa_0.01_200sites_56per,
     dist_ph85_tree_9taxa_0.01_200sites_55per,
     dist_ph85_tree_9taxa_0.01_200sites_54per,
     dist_ph85_tree_9taxa_0.01_200sites_53per,
     dist_ph85_tree_9taxa_0.01_200sites_52per,
     dist_ph85_tree_9taxa_0.01_200sites_51per,
     dist_ph85_tree_9taxa_0.01_200sites_50per,
     BranchError_tree_9taxa_0.01_200sites_100per,
     BranchError_tree_9taxa_0.01_200sites_99per,
     BranchError_tree_9taxa_0.01_200sites_98per,
     BranchError_tree_9taxa_0.01_200sites_97per,
     BranchError_tree_9taxa_0.01_200sites_96per,
     BranchError_tree_9taxa_0.01_200sites_95per,
     BranchError_tree_9taxa_0.01_200sites_94per,
     BranchError_tree_9taxa_0.01_200sites_93per,
     BranchError_tree_9taxa_0.01_200sites_92per,
     BranchError_tree_9taxa_0.01_200sites_91per,
     BranchError_tree_9taxa_0.01_200sites_90per,
     BranchError_tree_9taxa_0.01_200sites_89per,
     BranchError_tree_9taxa_0.01_200sites_88per,
     BranchError_tree_9taxa_0.01_200sites_87per,
     BranchError_tree_9taxa_0.01_200sites_86per,
     BranchError_tree_9taxa_0.01_200sites_85per,
     BranchError_tree_9taxa_0.01_200sites_84per,
     BranchError_tree_9taxa_0.01_200sites_83per,
     BranchError_tree_9taxa_0.01_200sites_82per,
     BranchError_tree_9taxa_0.01_200sites_81per,
     BranchError_tree_9taxa_0.01_200sites_80per,
     BranchError_tree_9taxa_0.01_200sites_79per,
     BranchError_tree_9taxa_0.01_200sites_78per,
     BranchError_tree_9taxa_0.01_200sites_77per,
     BranchError_tree_9taxa_0.01_200sites_76per,
     BranchError_tree_9taxa_0.01_200sites_75per,
     BranchError_tree_9taxa_0.01_200sites_74per,
     BranchError_tree_9taxa_0.01_200sites_73per,
     BranchError_tree_9taxa_0.01_200sites_72per,
     BranchError_tree_9taxa_0.01_200sites_71per,
     BranchError_tree_9taxa_0.01_200sites_70per,
     BranchError_tree_9taxa_0.01_200sites_69per,
     BranchError_tree_9taxa_0.01_200sites_68per,
     BranchError_tree_9taxa_0.01_200sites_67per,
     BranchError_tree_9taxa_0.01_200sites_66per,
     BranchError_tree_9taxa_0.01_200sites_65per,
     BranchError_tree_9taxa_0.01_200sites_64per,
     BranchError_tree_9taxa_0.01_200sites_63per,
     BranchError_tree_9taxa_0.01_200sites_62per,
     BranchError_tree_9taxa_0.01_200sites_61per,
     BranchError_tree_9taxa_0.01_200sites_60per,
     BranchError_tree_9taxa_0.01_200sites_59per,
     BranchError_tree_9taxa_0.01_200sites_58per,
     BranchError_tree_9taxa_0.01_200sites_57per,
     BranchError_tree_9taxa_0.01_200sites_56per,
     BranchError_tree_9taxa_0.01_200sites_55per,
     BranchError_tree_9taxa_0.01_200sites_54per,
     BranchError_tree_9taxa_0.01_200sites_53per,
     BranchError_tree_9taxa_0.01_200sites_52per,
     BranchError_tree_9taxa_0.01_200sites_51per,
     BranchError_tree_9taxa_0.01_200sites_50per,
     file="BE_PH85_tree_9taxa_0.01_200sites.Rdata")
##########################################################################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites")
load("BE_PH85_tree_9taxa_200sites.Rdata")

# Now calculate the average branch error and RF distances for each per.

avg_ph85_tree_9taxa_0.01_200sites_100per<-mean(dist_ph85_tree_9taxa_0.01_200sites_100per)
avg_ph85_tree_9taxa_0.01_200sites_99per<-mean(dist_ph85_tree_9taxa_0.01_200sites_99per)
avg_ph85_tree_9taxa_0.01_200sites_98per<-mean(dist_ph85_tree_9taxa_0.01_200sites_98per)
avg_ph85_tree_9taxa_0.01_200sites_97per<-mean(dist_ph85_tree_9taxa_0.01_200sites_97per)
avg_ph85_tree_9taxa_0.01_200sites_96per<-mean(dist_ph85_tree_9taxa_0.01_200sites_96per)
avg_ph85_tree_9taxa_0.01_200sites_95per<-mean(dist_ph85_tree_9taxa_0.01_200sites_95per)
avg_ph85_tree_9taxa_0.01_200sites_94per<-mean(dist_ph85_tree_9taxa_0.01_200sites_94per)
avg_ph85_tree_9taxa_0.01_200sites_93per<-mean(dist_ph85_tree_9taxa_0.01_200sites_93per)
avg_ph85_tree_9taxa_0.01_200sites_92per<-mean(dist_ph85_tree_9taxa_0.01_200sites_92per)
avg_ph85_tree_9taxa_0.01_200sites_91per<-mean(dist_ph85_tree_9taxa_0.01_200sites_91per)
avg_ph85_tree_9taxa_0.01_200sites_90per<-mean(dist_ph85_tree_9taxa_0.01_200sites_90per)
avg_ph85_tree_9taxa_0.01_200sites_89per<-mean(dist_ph85_tree_9taxa_0.01_200sites_89per)
avg_ph85_tree_9taxa_0.01_200sites_88per<-mean(dist_ph85_tree_9taxa_0.01_200sites_88per)
avg_ph85_tree_9taxa_0.01_200sites_87per<-mean(dist_ph85_tree_9taxa_0.01_200sites_87per)
avg_ph85_tree_9taxa_0.01_200sites_86per<-mean(dist_ph85_tree_9taxa_0.01_200sites_86per)
avg_ph85_tree_9taxa_0.01_200sites_85per<-mean(dist_ph85_tree_9taxa_0.01_200sites_85per)
avg_ph85_tree_9taxa_0.01_200sites_84per<-mean(dist_ph85_tree_9taxa_0.01_200sites_84per)
avg_ph85_tree_9taxa_0.01_200sites_83per<-mean(dist_ph85_tree_9taxa_0.01_200sites_83per)
avg_ph85_tree_9taxa_0.01_200sites_82per<-mean(dist_ph85_tree_9taxa_0.01_200sites_82per)
avg_ph85_tree_9taxa_0.01_200sites_81per<-mean(dist_ph85_tree_9taxa_0.01_200sites_81per)
avg_ph85_tree_9taxa_0.01_200sites_80per<-mean(dist_ph85_tree_9taxa_0.01_200sites_80per)

avg_ph85_tree_9taxa_0.01_200sites_79per<-mean(dist_ph85_tree_9taxa_0.01_200sites_79per)
avg_ph85_tree_9taxa_0.01_200sites_78per<-mean(dist_ph85_tree_9taxa_0.01_200sites_78per)
avg_ph85_tree_9taxa_0.01_200sites_77per<-mean(dist_ph85_tree_9taxa_0.01_200sites_77per)
avg_ph85_tree_9taxa_0.01_200sites_76per<-mean(dist_ph85_tree_9taxa_0.01_200sites_76per)
avg_ph85_tree_9taxa_0.01_200sites_75per<-mean(dist_ph85_tree_9taxa_0.01_200sites_75per)
avg_ph85_tree_9taxa_0.01_200sites_74per<-mean(dist_ph85_tree_9taxa_0.01_200sites_74per)
avg_ph85_tree_9taxa_0.01_200sites_73per<-mean(dist_ph85_tree_9taxa_0.01_200sites_73per)
avg_ph85_tree_9taxa_0.01_200sites_72per<-mean(dist_ph85_tree_9taxa_0.01_200sites_72per)
avg_ph85_tree_9taxa_0.01_200sites_71per<-mean(dist_ph85_tree_9taxa_0.01_200sites_71per)
avg_ph85_tree_9taxa_0.01_200sites_70per<-mean(dist_ph85_tree_9taxa_0.01_200sites_70per)

avg_ph85_tree_9taxa_0.01_200sites_69per<-mean(dist_ph85_tree_9taxa_0.01_200sites_69per)
avg_ph85_tree_9taxa_0.01_200sites_68per<-mean(dist_ph85_tree_9taxa_0.01_200sites_68per)
avg_ph85_tree_9taxa_0.01_200sites_67per<-mean(dist_ph85_tree_9taxa_0.01_200sites_67per)
avg_ph85_tree_9taxa_0.01_200sites_66per<-mean(dist_ph85_tree_9taxa_0.01_200sites_66per)
avg_ph85_tree_9taxa_0.01_200sites_65per<-mean(dist_ph85_tree_9taxa_0.01_200sites_65per)
avg_ph85_tree_9taxa_0.01_200sites_64per<-mean(dist_ph85_tree_9taxa_0.01_200sites_64per)
avg_ph85_tree_9taxa_0.01_200sites_63per<-mean(dist_ph85_tree_9taxa_0.01_200sites_63per)
avg_ph85_tree_9taxa_0.01_200sites_62per<-mean(dist_ph85_tree_9taxa_0.01_200sites_62per)
avg_ph85_tree_9taxa_0.01_200sites_61per<-mean(dist_ph85_tree_9taxa_0.01_200sites_61per)
avg_ph85_tree_9taxa_0.01_200sites_60per<-mean(dist_ph85_tree_9taxa_0.01_200sites_60per)

avg_ph85_tree_9taxa_0.01_200sites_59per<-mean(dist_ph85_tree_9taxa_0.01_200sites_59per)
avg_ph85_tree_9taxa_0.01_200sites_58per<-mean(dist_ph85_tree_9taxa_0.01_200sites_58per)
avg_ph85_tree_9taxa_0.01_200sites_57per<-mean(dist_ph85_tree_9taxa_0.01_200sites_57per)
avg_ph85_tree_9taxa_0.01_200sites_56per<-mean(dist_ph85_tree_9taxa_0.01_200sites_56per)
avg_ph85_tree_9taxa_0.01_200sites_55per<-mean(dist_ph85_tree_9taxa_0.01_200sites_55per)
avg_ph85_tree_9taxa_0.01_200sites_54per<-mean(dist_ph85_tree_9taxa_0.01_200sites_54per)
avg_ph85_tree_9taxa_0.01_200sites_53per<-mean(dist_ph85_tree_9taxa_0.01_200sites_53per)
avg_ph85_tree_9taxa_0.01_200sites_52per<-mean(dist_ph85_tree_9taxa_0.01_200sites_52per)
avg_ph85_tree_9taxa_0.01_200sites_51per<-mean(dist_ph85_tree_9taxa_0.01_200sites_51per)
avg_ph85_tree_9taxa_0.01_200sites_50per<-mean(dist_ph85_tree_9taxa_0.01_200sites_50per)



df_ph85_tree_9taxa_0.01_200sites<-rbind(avg_ph85_tree_9taxa_0.01_200sites_100per,
                                        avg_ph85_tree_9taxa_0.01_200sites_99per,
                                        avg_ph85_tree_9taxa_0.01_200sites_98per,
                                        avg_ph85_tree_9taxa_0.01_200sites_97per,
                                        avg_ph85_tree_9taxa_0.01_200sites_96per,
                                        avg_ph85_tree_9taxa_0.01_200sites_95per,
                                        avg_ph85_tree_9taxa_0.01_200sites_94per,
                                        avg_ph85_tree_9taxa_0.01_200sites_93per,
                                        avg_ph85_tree_9taxa_0.01_200sites_92per,
                                        avg_ph85_tree_9taxa_0.01_200sites_91per,
                                        avg_ph85_tree_9taxa_0.01_200sites_90per,
                                        avg_ph85_tree_9taxa_0.01_200sites_89per,
                                        avg_ph85_tree_9taxa_0.01_200sites_88per,
                                        avg_ph85_tree_9taxa_0.01_200sites_87per,
                                        avg_ph85_tree_9taxa_0.01_200sites_86per,
                                        avg_ph85_tree_9taxa_0.01_200sites_85per,
                                        avg_ph85_tree_9taxa_0.01_200sites_84per,
                                        avg_ph85_tree_9taxa_0.01_200sites_83per,
                                        avg_ph85_tree_9taxa_0.01_200sites_82per,
                                        avg_ph85_tree_9taxa_0.01_200sites_81per,
                                        avg_ph85_tree_9taxa_0.01_200sites_80per,
                                        avg_ph85_tree_9taxa_0.01_200sites_79per,
                                        avg_ph85_tree_9taxa_0.01_200sites_78per,
                                        avg_ph85_tree_9taxa_0.01_200sites_77per,
                                        avg_ph85_tree_9taxa_0.01_200sites_76per,
                                        avg_ph85_tree_9taxa_0.01_200sites_75per,
                                        avg_ph85_tree_9taxa_0.01_200sites_74per,
                                        avg_ph85_tree_9taxa_0.01_200sites_73per,
                                        avg_ph85_tree_9taxa_0.01_200sites_72per,
                                        avg_ph85_tree_9taxa_0.01_200sites_71per,
                                        avg_ph85_tree_9taxa_0.01_200sites_70per,
                                        avg_ph85_tree_9taxa_0.01_200sites_69per,
                                        avg_ph85_tree_9taxa_0.01_200sites_68per,
                                        avg_ph85_tree_9taxa_0.01_200sites_67per,
                                        avg_ph85_tree_9taxa_0.01_200sites_66per,
                                        avg_ph85_tree_9taxa_0.01_200sites_65per,
                                        avg_ph85_tree_9taxa_0.01_200sites_64per,
                                        avg_ph85_tree_9taxa_0.01_200sites_63per,
                                        avg_ph85_tree_9taxa_0.01_200sites_62per,
                                        avg_ph85_tree_9taxa_0.01_200sites_61per,
                                        avg_ph85_tree_9taxa_0.01_200sites_60per,
                                        avg_ph85_tree_9taxa_0.01_200sites_59per,
                                        avg_ph85_tree_9taxa_0.01_200sites_58per,
                                        avg_ph85_tree_9taxa_0.01_200sites_57per,
                                        avg_ph85_tree_9taxa_0.01_200sites_56per,
                                        avg_ph85_tree_9taxa_0.01_200sites_55per,
                                        avg_ph85_tree_9taxa_0.01_200sites_54per,
                                        avg_ph85_tree_9taxa_0.01_200sites_53per,
                                        avg_ph85_tree_9taxa_0.01_200sites_52per,
                                        avg_ph85_tree_9taxa_0.01_200sites_51per,
                                        avg_ph85_tree_9taxa_0.01_200sites_50per)
df_ph85_tree_9taxa_0.01_200sites<-as.data.frame(df_ph85_tree_9taxa_0.01_200sites)
colnames(df_ph85_tree_9taxa_0.01_200sites)<-"Avg_PH85"
df_ph85_tree_9taxa_0.01_200sites
#################################################################
##
# branch error
avg_BE_tree_9taxa_0.01_200sites_100per<-mean(BranchError_tree_9taxa_0.01_200sites_100per)
avg_BE_tree_9taxa_0.01_200sites_99per<-mean(BranchError_tree_9taxa_0.01_200sites_99per)
avg_BE_tree_9taxa_0.01_200sites_98per<-mean(BranchError_tree_9taxa_0.01_200sites_98per)
avg_BE_tree_9taxa_0.01_200sites_97per<-mean(BranchError_tree_9taxa_0.01_200sites_97per)
avg_BE_tree_9taxa_0.01_200sites_96per<-mean(BranchError_tree_9taxa_0.01_200sites_96per)
avg_BE_tree_9taxa_0.01_200sites_95per<-mean(BranchError_tree_9taxa_0.01_200sites_95per)
avg_BE_tree_9taxa_0.01_200sites_94per<-mean(BranchError_tree_9taxa_0.01_200sites_94per)
avg_BE_tree_9taxa_0.01_200sites_93per<-mean(BranchError_tree_9taxa_0.01_200sites_93per)
avg_BE_tree_9taxa_0.01_200sites_92per<-mean(BranchError_tree_9taxa_0.01_200sites_92per)
avg_BE_tree_9taxa_0.01_200sites_91per<-mean(BranchError_tree_9taxa_0.01_200sites_91per)
avg_BE_tree_9taxa_0.01_200sites_90per<-mean(BranchError_tree_9taxa_0.01_200sites_90per)
avg_BE_tree_9taxa_0.01_200sites_89per<-mean(BranchError_tree_9taxa_0.01_200sites_89per)
avg_BE_tree_9taxa_0.01_200sites_88per<-mean(BranchError_tree_9taxa_0.01_200sites_88per)
avg_BE_tree_9taxa_0.01_200sites_87per<-mean(BranchError_tree_9taxa_0.01_200sites_87per)
avg_BE_tree_9taxa_0.01_200sites_86per<-mean(BranchError_tree_9taxa_0.01_200sites_86per)
avg_BE_tree_9taxa_0.01_200sites_85per<-mean(BranchError_tree_9taxa_0.01_200sites_85per)
avg_BE_tree_9taxa_0.01_200sites_84per<-mean(BranchError_tree_9taxa_0.01_200sites_84per)
avg_BE_tree_9taxa_0.01_200sites_83per<-mean(BranchError_tree_9taxa_0.01_200sites_83per)
avg_BE_tree_9taxa_0.01_200sites_82per<-mean(BranchError_tree_9taxa_0.01_200sites_82per)
avg_BE_tree_9taxa_0.01_200sites_81per<-mean(BranchError_tree_9taxa_0.01_200sites_81per)
avg_BE_tree_9taxa_0.01_200sites_80per<-mean(BranchError_tree_9taxa_0.01_200sites_80per)

avg_BE_tree_9taxa_0.01_200sites_79per<-mean(BranchError_tree_9taxa_0.01_200sites_79per)
avg_BE_tree_9taxa_0.01_200sites_78per<-mean(BranchError_tree_9taxa_0.01_200sites_78per)
avg_BE_tree_9taxa_0.01_200sites_77per<-mean(BranchError_tree_9taxa_0.01_200sites_77per)
avg_BE_tree_9taxa_0.01_200sites_76per<-mean(BranchError_tree_9taxa_0.01_200sites_76per)
avg_BE_tree_9taxa_0.01_200sites_75per<-mean(BranchError_tree_9taxa_0.01_200sites_75per)
avg_BE_tree_9taxa_0.01_200sites_74per<-mean(BranchError_tree_9taxa_0.01_200sites_74per)
avg_BE_tree_9taxa_0.01_200sites_73per<-mean(BranchError_tree_9taxa_0.01_200sites_73per)
avg_BE_tree_9taxa_0.01_200sites_72per<-mean(BranchError_tree_9taxa_0.01_200sites_72per)
avg_BE_tree_9taxa_0.01_200sites_71per<-mean(BranchError_tree_9taxa_0.01_200sites_71per)
avg_BE_tree_9taxa_0.01_200sites_70per<-mean(BranchError_tree_9taxa_0.01_200sites_70per)

avg_BE_tree_9taxa_0.01_200sites_69per<-mean(BranchError_tree_9taxa_0.01_200sites_69per)
avg_BE_tree_9taxa_0.01_200sites_68per<-mean(BranchError_tree_9taxa_0.01_200sites_68per)
avg_BE_tree_9taxa_0.01_200sites_67per<-mean(BranchError_tree_9taxa_0.01_200sites_67per)
avg_BE_tree_9taxa_0.01_200sites_66per<-mean(BranchError_tree_9taxa_0.01_200sites_66per)
avg_BE_tree_9taxa_0.01_200sites_65per<-mean(BranchError_tree_9taxa_0.01_200sites_65per)
avg_BE_tree_9taxa_0.01_200sites_64per<-mean(BranchError_tree_9taxa_0.01_200sites_64per)
avg_BE_tree_9taxa_0.01_200sites_63per<-mean(BranchError_tree_9taxa_0.01_200sites_63per)
avg_BE_tree_9taxa_0.01_200sites_62per<-mean(BranchError_tree_9taxa_0.01_200sites_62per)
avg_BE_tree_9taxa_0.01_200sites_61per<-mean(BranchError_tree_9taxa_0.01_200sites_61per)
avg_BE_tree_9taxa_0.01_200sites_60per<-mean(BranchError_tree_9taxa_0.01_200sites_60per)

avg_BE_tree_9taxa_0.01_200sites_59per<-mean(BranchError_tree_9taxa_0.01_200sites_59per)
avg_BE_tree_9taxa_0.01_200sites_58per<-mean(BranchError_tree_9taxa_0.01_200sites_58per)
avg_BE_tree_9taxa_0.01_200sites_57per<-mean(BranchError_tree_9taxa_0.01_200sites_57per)
avg_BE_tree_9taxa_0.01_200sites_56per<-mean(BranchError_tree_9taxa_0.01_200sites_56per)
avg_BE_tree_9taxa_0.01_200sites_55per<-mean(BranchError_tree_9taxa_0.01_200sites_55per)
avg_BE_tree_9taxa_0.01_200sites_54per<-mean(BranchError_tree_9taxa_0.01_200sites_54per)
avg_BE_tree_9taxa_0.01_200sites_53per<-mean(BranchError_tree_9taxa_0.01_200sites_53per)
avg_BE_tree_9taxa_0.01_200sites_52per<-mean(BranchError_tree_9taxa_0.01_200sites_52per)
avg_BE_tree_9taxa_0.01_200sites_51per<-mean(BranchError_tree_9taxa_0.01_200sites_51per)
avg_BE_tree_9taxa_0.01_200sites_50per<-mean(BranchError_tree_9taxa_0.01_200sites_50per)

df_BE_tree_9taxa_0.01_200sites<-rbind(avg_BE_tree_9taxa_0.01_200sites_100per,
                                      avg_BE_tree_9taxa_0.01_200sites_99per,
                                      avg_BE_tree_9taxa_0.01_200sites_98per,
                                      avg_BE_tree_9taxa_0.01_200sites_97per,
                                      avg_BE_tree_9taxa_0.01_200sites_96per,
                                      avg_BE_tree_9taxa_0.01_200sites_95per,
                                      avg_BE_tree_9taxa_0.01_200sites_94per,
                                      avg_BE_tree_9taxa_0.01_200sites_93per,
                                      avg_BE_tree_9taxa_0.01_200sites_92per,
                                      avg_BE_tree_9taxa_0.01_200sites_91per,
                                      avg_BE_tree_9taxa_0.01_200sites_90per,
                                      avg_BE_tree_9taxa_0.01_200sites_89per,
                                      avg_BE_tree_9taxa_0.01_200sites_88per,
                                      avg_BE_tree_9taxa_0.01_200sites_87per,
                                      avg_BE_tree_9taxa_0.01_200sites_86per,
                                      avg_BE_tree_9taxa_0.01_200sites_85per,
                                      avg_BE_tree_9taxa_0.01_200sites_84per,
                                      avg_BE_tree_9taxa_0.01_200sites_83per,
                                      avg_BE_tree_9taxa_0.01_200sites_82per,
                                      avg_BE_tree_9taxa_0.01_200sites_81per,
                                      avg_BE_tree_9taxa_0.01_200sites_80per,
                                      avg_BE_tree_9taxa_0.01_200sites_79per,
                                      avg_BE_tree_9taxa_0.01_200sites_78per,
                                      avg_BE_tree_9taxa_0.01_200sites_77per,
                                      avg_BE_tree_9taxa_0.01_200sites_76per,
                                      avg_BE_tree_9taxa_0.01_200sites_75per,
                                      avg_BE_tree_9taxa_0.01_200sites_74per,
                                      avg_BE_tree_9taxa_0.01_200sites_73per,
                                      avg_BE_tree_9taxa_0.01_200sites_72per,
                                      avg_BE_tree_9taxa_0.01_200sites_71per,
                                      avg_BE_tree_9taxa_0.01_200sites_70per,
                                      avg_BE_tree_9taxa_0.01_200sites_69per,
                                      avg_BE_tree_9taxa_0.01_200sites_68per,
                                      avg_BE_tree_9taxa_0.01_200sites_67per,
                                      avg_BE_tree_9taxa_0.01_200sites_66per,
                                      avg_BE_tree_9taxa_0.01_200sites_65per,
                                      avg_BE_tree_9taxa_0.01_200sites_64per,
                                      avg_BE_tree_9taxa_0.01_200sites_63per,
                                      avg_BE_tree_9taxa_0.01_200sites_62per,
                                      avg_BE_tree_9taxa_0.01_200sites_61per,
                                      avg_BE_tree_9taxa_0.01_200sites_60per,
                                      avg_BE_tree_9taxa_0.01_200sites_59per,
                                      avg_BE_tree_9taxa_0.01_200sites_58per,
                                      avg_BE_tree_9taxa_0.01_200sites_57per,
                                      avg_BE_tree_9taxa_0.01_200sites_56per,
                                      avg_BE_tree_9taxa_0.01_200sites_55per,
                                      avg_BE_tree_9taxa_0.01_200sites_54per,
                                      avg_BE_tree_9taxa_0.01_200sites_53per,
                                      avg_BE_tree_9taxa_0.01_200sites_52per,
                                      avg_BE_tree_9taxa_0.01_200sites_51per,
                                      avg_BE_tree_9taxa_0.01_200sites_50per)

df_BE_tree_9taxa_0.01_200sites<-as.data.frame(df_BE_tree_9taxa_0.01_200sites)
colnames(df_BE_tree_9taxa_0.01_200sites)<-"Avg_BE"
df_BE_tree_9taxa_0.01_200sites
#################################################################################

# Assuming df_PH85 is your data frame
df_ph85_tree_9taxa_0.01_200sites_modify <- data.frame(
  Category = as.character(0:50),
  Average_Score = as.numeric(df_ph85_tree_9taxa_0.01_200sites$Avg_PH85)
)

custom_levels <- as.character(0:50)

# Convert Category to a factor with custom levels
df_ph85_tree_9taxa_0.01_200sites_modify$Category <- factor(df_ph85_tree_9taxa_0.01_200sites_modify$Category, levels = custom_levels)


# Assuming df_BE is your data frame
df_BE_tree_9taxa_0.01_200sites_modify <- data.frame(
  Category = as.character(0:50),
  Average_Score = as.numeric(df_BE_tree_9taxa_0.01_200sites$Avg_BE)
)
custom_levels <- as.character(0:50)

# Convert Category to a factor with custom levels
df_BE_tree_9taxa_0.01_200sites_modify$Category <- factor(df_BE_tree_9taxa_0.01_200sites_modify$Category, levels = custom_levels)

##########################################################################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites")
save(df_ph85_tree_9taxa_0.01_200sites,df_BE_tree_9taxa_0.01_200sites,
     df_ph85_tree_9taxa_0.01_200sites_modify,df_BE_tree_9taxa_0.01_200sites_modify,
     file = "figure_ph85_be_tree_9taxa_0.01_200sites.Rdata")


