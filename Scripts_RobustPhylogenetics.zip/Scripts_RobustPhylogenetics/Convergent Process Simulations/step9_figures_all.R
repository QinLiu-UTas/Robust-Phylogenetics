# This script is to create all figures for the convergent process simulations.

library(ggplot2)
library(dplyr)
library(tidyr)

# load all the figure data.
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites")
load("BE_MeanSE_9taxa_0.01_200sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.01_200sites_figures.Rdata")
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/300sites")
load("BE_MeanSE_9taxa_0.01_300sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.01_300sites_figures.Rdata")
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/500sites")
load("BE_MeanSE_9taxa_0.01_500sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.01_500sites_figures.Rdata")

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroThree/200sites")
load("BE_MeanSE_9taxa_0.03_200sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.03_200sites_figures.Rdata")
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroThree/300sites")
load("BE_MeanSE_9taxa_0.03_300sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.03_300sites_figures.Rdata")
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroThree/500sites")
load("BE_MeanSE_9taxa_0.03_500sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.03_500sites_figures.Rdata")

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroFive/200sites")
load("BE_MeanSE_9taxa_0.05_200sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.05_200sites_figures.Rdata")
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroFive/300sites")
load("BE_MeanSE_9taxa_0.05_300sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.05_300sites_figures.Rdata")
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroFive/500sites")
load("BE_MeanSE_9taxa_0.05_500sites_figures.Rdata")
load("RF_MeanSE_9taxa_0.05_500sites_figures.Rdata")
##################################################
#######################################################
y_min<-2
y_max<-10
# Data frame for plotting with means and SE for each simulation type
# Internal branch = 0.01
df_RF_0.01 <- data.frame(
  x_values = rep(x_values, 3),
  means = c(means_RF_9taxa_0.01_200sites, means_RF_9taxa_0.01_300sites, means_RF_9taxa_0.01_500sites),
  se = c(se_RF_9taxa_0.01_200sites, se_RF_9taxa_0.01_300sites, se_RF_9taxa_0.01_500sites),
  simulation = factor(rep(c("800JC-200GC", "700JC-300GC", "500JC-500GC"), each = length(x_values)))
)

# Calculate the maximum and minimum values for the y-axis limits
y_max_RF_0.01 <- max(df_RF_0.01$means)+0.3
y_min_RF_0.01 <- min(df_RF_0.01$means)-0.5
# Create the plot
ggplot(df_RF_0.01, aes(x = x_values, y = means, color = simulation, shape = simulation)) +
  geom_point(size =3.5) +  # Points with different shapes
  geom_line(linewidth = 0.5 ) +  # Make the line smaller
  geom_errorbar(aes(ymin = means - se, ymax = means + se, color = simulation),  # Map color to simulation
                width = 0, linewidth = 0.5) +
  
  scale_color_manual(values = c("#5ab4ac", "#d8b365", "#542788"),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(1,5, 4),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Shapes and labels for each simulation

  labs(x = "% of Sites Removed", y = "RF Distance", 
       color = "Simulation", shape = "Simulation") + # Adjust title and legend label
  ggtitle("Internal branch length = 0.01") + 
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  ) +
  #coord_cartesian(ylim = c(y_min_RF_0.01, y_max_RF_0.01))  # Manually set the y-axis limits
  coord_cartesian(ylim = c(y_min, y_max))

###########################################
# Data frame for plotting with means and SE for each simulation type
# Internal branch = 0.03
df_RF_0.03 <- data.frame(
  x_values = rep(x_values, 3),
  means = c(means_RF_9taxa_0.03_200sites, means_RF_9taxa_0.03_300sites, means_RF_9taxa_0.03_500sites),
  se = c(se_RF_9taxa_0.03_200sites, se_RF_9taxa_0.03_300sites, se_RF_9taxa_0.03_500sites),
  simulation = factor(rep(c("800JC-200GC", "700JC-300GC", "500JC-500GC"), each = length(x_values)))
)

# Calculate the maximum and minimum values for the y-axis limits
y_max_RF_0.03 <- max(df_RF_0.03$means)+0.45
y_min_RF_0.03 <- min(df_RF_0.03$means)-0.45
# Create the plot
ggplot(df_RF_0.03, aes(x = x_values, y = means, color = simulation, shape = simulation)) +
  geom_point(size =3) +  # Points with different shapes
  geom_line(linewidth = 0.5) +  # Make the line smaller
  geom_errorbar(aes(ymin = means - se, ymax = means + se), 
                width = 0.2, linewidth = 0.8) +  # Smaller error bar lines
  scale_color_manual(values = c("#5ab4ac", "#d8b365", "#542788"),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(1,5, 4),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Shapes and labels for each simulation
  
  labs(x = "% of Sites Removed", y = "RF Distance", 
       color = "Simulation", shape = "Simulation") + # Adjust title and legend label
  ggtitle("Internal branch length = 0.03") + 
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  ) +
  #coord_cartesian(ylim = c(y_min_RF_0.03, y_max_RF_0.03))  # Manually set the y-axis limits
  coord_cartesian(ylim = c(y_min, y_max))
###########################################
# Data frame for plotting with means and SE for each simulation type
# Internal branch = 0.05
df_RF_0.05 <- data.frame(
  x_values = rep(x_values, 3),
  means = c(means_RF_9taxa_0.05_200sites, means_RF_9taxa_0.05_300sites, means_RF_9taxa_0.05_500sites),
  se = c(se_RF_9taxa_0.05_200sites, se_RF_9taxa_0.05_300sites, se_RF_9taxa_0.05_500sites),
  simulation = factor(rep(c("800JC-200GC", "700JC-300GC", "500JC-500GC"), each = length(x_values)))
)

# Calculate the maximum and minimum values for the y-axis limits
y_max_RF_0.05 <- max(df_RF_0.05$means)+0.45
y_min_RF_0.05 <- min(df_RF_0.05$means)-0.45
# Create the plot
ggplot(df_RF_0.05, aes(x = x_values, y = means, color = simulation, shape = simulation)) +
  geom_point(size =3) +  # Points with different shapes
  geom_line(linewidth = 0.5) +  # Make the line smaller
  geom_errorbar(aes(ymin = means - se, ymax = means + se), 
                width = 0, linewidth = 0.8) +  # Smaller error bar lines
  scale_color_manual(values = c("#5ab4ac", "#d8b365", "#542788"),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(1,5, 4),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Shapes and labels for each simulation
  
  labs(x = "% of Sites Removed", y = "RF Distance", 
       color = "Simulation", shape = "Simulation") + # Adjust title and legend label
  ggtitle("Internal branch length = 0.05") + 
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  ) +
 # coord_cartesian(ylim = c(y_min_RF_0.05, y_max_RF_0.05))  # Manually set the y-axis limits
  coord_cartesian(ylim = c(y_min, y_max))
################################################


##############################################################
# Branch Score
y_min_BE<-0.62
y_max_BE<-1.55
# Data frame for plotting with means and SE for each simulation type
# Internal branch = 0.01
df_BE_0.01 <- data.frame(
  x_values = rep(x_values, 3),
  means = c(means_BE_9taxa_0.01_200sites, means_BE_9taxa_0.01_300sites, means_BE_9taxa_0.01_500sites),
  se = c(se_BE_9taxa_0.01_200sites, se_BE_9taxa_0.01_300sites, se_BE_9taxa_0.01_500sites),
  simulation = factor(rep(c("800JC-200GC", "700JC-300GC", "500JC-500GC"), each = length(x_values)))
)

# Create the plot
ggplot(df_BE_0.01, aes(x = x_values, y = means, color = simulation, shape = simulation)) +
  geom_point(size =3.5) +  # Points with different shapes
  geom_line(linewidth = 0.5 ) +  # Make the line smaller
  geom_errorbar(aes(ymin = means - se, ymax = means + se, color = simulation),  # Map color to simulation
                width = 0, linewidth = 0.5) +
  
  scale_color_manual(values = c("#5ab4ac", "#d8b365", "#542788"),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(1,5, 4),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Shapes and labels for each simulation
  
  labs(x = "% of Sites Removed", y = "BE Distance", 
       color = "Simulation", shape = "Simulation") + # Adjust title and legend label
  ggtitle("Internal branch length = 0.01") + 
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  ) +
  #coord_cartesian(ylim = c(y_min_BE_0.01, y_max_BE_0.01))  # Manually set the y-axis limits
  coord_cartesian(ylim = c(y_min_BE, y_max_BE))

###########################################
# Data frame for plotting with means and SE for each simulation type
# Internal branch = 0.03
df_BE_0.03 <- data.frame(
  x_values = rep(x_values, 3),
  means = c(means_BE_9taxa_0.03_200sites, means_BE_9taxa_0.03_300sites, means_BE_9taxa_0.03_500sites),
  se = c(se_BE_9taxa_0.03_200sites, se_BE_9taxa_0.03_300sites, se_BE_9taxa_0.03_500sites),
  simulation = factor(rep(c("800JC-200GC", "700JC-300GC", "500JC-500GC"), each = length(x_values)))
)

# Calculate the maximum and minimum values for the y-axis limits
#y_max_BE_0.03 <- max(df_BE_0.03$means)+0.45
#y_min_BE_0.03 <- min(df_BE_0.03$means)-0.45
# Create the plot
ggplot(df_BE_0.03, aes(x = x_values, y = means, color = simulation, shape = simulation)) +
  geom_point(size =3) +  # Points with different shapes
  geom_line(linewidth = 0.5) +  # Make the line smaller
  geom_errorbar(aes(ymin = means - se, ymax = means + se), 
                width = 0.2, linewidth = 0.8) +  # Smaller error bar lines
  scale_color_manual(values = c("#5ab4ac", "#d8b365", "#542788"),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(1,5, 4),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Shapes and labels for each simulation
  
  labs(x = "% of Sites Removed", y = "BE Distance", 
       color = "Simulation", shape = "Simulation") + # Adjust title and legend label
  ggtitle("Internal branch length = 0.03") + 
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  ) +
  #coord_cartesian(ylim = c(y_min_BE_0.03, y_max_BE_0.03))  # Manually set the y-axis limits
  coord_cartesian(ylim = c(y_min_BE, y_max_BE))
###########################################
# Data frame for plotting with means and SE for each simulation type
# Internal branch = 0.05
df_BE_0.05 <- data.frame(
  x_values = rep(x_values, 3),
  means = c(means_BE_9taxa_0.05_200sites, means_BE_9taxa_0.05_300sites, means_BE_9taxa_0.05_500sites),
  se = c(se_BE_9taxa_0.05_200sites, se_BE_9taxa_0.05_300sites, se_BE_9taxa_0.05_500sites),
  simulation = factor(rep(c("800JC-200GC", "700JC-300GC", "500JC-500GC"), each = length(x_values)))
)

# Calculate the maximum and minimum values for the y-axis limits
#y_max_BE_0.05 <- max(df_BE_0.05$means)+0.45
#y_min_BE_0.05 <- min(df_BE_0.05$means)-0.45
# Create the plot
ggplot(df_BE_0.05, aes(x = x_values, y = means, color = simulation, shape = simulation)) +
  geom_point(size =3) +  # Points with different shapes
  geom_line(linewidth = 0.5) +  # Make the line smaller
  geom_errorbar(aes(ymin = means - se, ymax = means + se), 
                width = 0, linewidth = 0.8) +  # Smaller error bar lines
  scale_color_manual(values = c("#5ab4ac", "#d8b365", "#542788"),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(1,5, 4),
                     labels = c("500JC-500GC", "700JC-300GC", "800JC-200GC")) +  # Shapes and labels for each simulation
  
  labs(x = "% of Sites Removed", y = "BE Distance", 
       color = "Simulation", shape = "Simulation") + # Adjust title and legend label
  ggtitle("Internal branch length = 0.05") + 
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  ) +
  # coord_cartesian(ylim = c(y_min_BE_0.05, y_max_BE_0.05))  # Manually set the y-axis limits
  coord_cartesian(ylim = c(y_min_BE, y_max_BE))

###########################################################
###########################################################
###########################################################
# Relative Risks:

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroFive")
load("figure_relativeRisk_0.05.rdata")

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroThree")
load("figure_relativeRisk_0.03.rdata")

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne")
load("figure_relativeRisk_0.01.rdata")

combined_rr_0.01$Type <- factor(combined_rr_0.01$Type, levels = c("800JC-200GC", "700JC-300GC", "500JC-500GC"))


ggplot(combined_rr_0.01, aes(x = Sites_Removed, y = Relative_Risk, color = Type, group = Type, shape = Type)) +
  geom_line(size = 0.5) +
  geom_point(size =4.5) +
  labs(x = "Number of Sites Removed",  # Remove the title
       y = "Relative Risk", title = "Internal Branch Length = 0.01") +
  scale_x_continuous(breaks = 1:50, expand = c(0.02, 0)) +  # Set breaks from 1 to 50
  scale_y_continuous(limits = c(0.8,1.4)) +  # Start y-axis at 1
  scale_color_manual(values = c("#542788", "#d8b365", "#5ab4ac"),
                     labels = c("800JC-200GC", "700JC-300GC", "500JC-500GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(4,5,1),
                     labels = c("800JC-200GC", "700JC-300GC", "500JC-500GC")) +  # Shapes and labels for each simulation
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    panel.grid.minor = element_blank(),
    panel.grid.minor.x = element_blank(),  # Remove minor grid lines on x-axis
    panel.grid.minor.y = element_blank(),
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  )  +
  scale_x_continuous(breaks = c(1, 5,10,15, 20,25, 30,35, 40,45, 50))  # Customize x-axis labels

 


combined_rr_0.03$Type <- factor(combined_rr_0.03$Type, levels = c("800JC-200GC", "700JC-300GC", "500JC-500GC"))


ggplot(combined_rr_0.03, aes(x = Sites_Removed, y = Relative_Risk, color = Type, group = Type, shape = Type)) +
  geom_line(size = 0.5) +
  geom_point(size = 4.5) +
  labs(x = "Number of Sites Removed",  # Remove the title
       y = "Relative Risk", title = "Internal Branch Length = 0.03") +
  scale_x_continuous(breaks = 1:50, expand = c(0.02, 0)) +  # Set breaks from 1 to 50
  scale_y_continuous(limits = c(0.8,1.4)) +  # Start y-axis at 1
  scale_color_manual(values = c("#542788", "#d8b365", "#5ab4ac"),
                     labels = c("800JC-200GC", "700JC-300GC", "500JC-500GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(4,5,1),
                     labels = c("800JC-200GC", "700JC-300GC", "500JC-500GC")) +  # Shapes and labels for each simulation
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    panel.grid.minor = element_blank(),
    panel.grid.minor.x = element_blank(),  # Remove minor grid lines on x-axis
    panel.grid.minor.y = element_blank(),
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  ) +
  scale_x_continuous(breaks = c(1, 5,10,15, 20,25, 30,35, 40,45, 50))  # Customize x-axis labels



combined_rr_0.05$Type <- factor(combined_rr_0.05$Type, levels = c("800JC-200GC", "700JC-300GC", "500JC-500GC"))

ggplot(combined_rr_0.05, aes(x = Sites_Removed, y = Relative_Risk, color = Type, group = Type, shape = Type)) +
  geom_line(size = 0.5) +
  geom_point(size = 4.5) +
  labs(x = "Number of Sites Removed",  # Remove the title
       y = "Relative Risk", title = "Internal Branch Length = 0.05") +
  scale_x_continuous(breaks = 1:50, expand = c(0.02, 0)) +  # Set breaks from 1 to 50
  scale_y_continuous(limits = c(0.8,1.4)) +  # Start y-axis at 1
  scale_color_manual(values = c("#542788", "#d8b365", "#5ab4ac"),
                     labels = c("800JC-200GC", "700JC-300GC", "500JC-500GC")) +  # Colors and labels for each simulation
  scale_shape_manual(values = c(4,5,1),
                     labels = c("800JC-200GC", "700JC-300GC", "500JC-500GC")) +  # Shapes and labels for each simulation
  theme_minimal(base_size = 10) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.60, 1),       # Position the legend in the top right corner
    legend.justification = c(1, 1),        # Ensure the legend is aligned properly
    legend.direction = "horizontal",       # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Use linewidth instead of size for the border
    panel.grid.minor = element_blank(),
    panel.grid.minor.x = element_blank(),  # Remove minor grid lines on x-axis
    panel.grid.minor.y = element_blank(),
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10))   # Add margin to y-axis labels
  ) +
  scale_x_continuous(breaks = c(1, 5,10,15, 20,25, 30,35, 40,45, 50))  # Customize x-axis labels
############################################################
# Look closely to the trees 
# investigate tree 6 for 200 sites
# This alignment without trimming RF=6, BE=1.28, trimmed 50%, RF=12, be=0.64
library(ape)
library(phangorn)

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites/50-per-results")
tree6_200sites_50per<-read.tree("50-1.treefile")

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne/200sites/100-per-results")
tree6_200sites_100per<-read.tree("100-1.treefile")


plot(tree6_200sites_100per,cex=3, edge.width = 3,col='black')
edgelabels(round(tree6_200sites_100per$edge.length, 2), col = "black", bg = "lightgray",frame = "rect",cex=0.7,adj = c(0.5, -0.5),  # Adjust y-position upwards
           offset = 0.02) 
cat(write.tree(tree6_200sites_100per))


plot(tree6_200sites_50per,cex=3, edge.width = 3,col='black')
edgelabels(round(tree6_200sites_50per$edge.length, 4), col = "black", bg = "lightgray",frame = "rect",cex=0.7,adj = c(0.5, -0.5),  # Adjust y-position upwards
           offset = 0.02) 
cat(write.tree(tree6_200sites_50per))

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/GC-rich/9taxa_OneThousandSites_14Feb25/ZeroPointZeroOne")

true_tree_9taxa<-read.tree("true_tree_9taxa.tre")
plot(true_tree_9taxa)
edgelabels(round(true_tree_9taxa$edge.length, 4), col = "black", bg = "lightgray",adj = c(0.9, 0.5),frame = "rect",cex=0.7)

is.rooted(true_tree_9taxa)
true_tree_9taxa<-unroot(true_tree_9taxa)
dist.topo(unroot(tree6_200sites_100per),unroot(true_tree_9taxa))
dist.topo(unroot(tree6_200sites_50per),unroot(true_tree_9taxa))

# KF.dist is correct.
KF.dist(unroot(tree6_200sites_100per),unroot(true_tree_9taxa))
KF.dist(unroot(tree6_200sites_50per),unroot(true_tree_9taxa))

RF.dist(unroot(tree6_200sites_100per),unroot(true_tree_9taxa))
RF.dist(unroot(tree6_200sites_50per),unroot(true_tree_9taxa))

