# This script is to create folders to store site log-likelihood files.


mkdir -p all_tree_sitelh_txt

for k in $(seq 50 1 100);
do
mkdir -p "all_tree_sitelh_txt/${k}-sitelh"
done
