# Use IQTREE2 to infer tree and apply the trimmed log-likelihood method, trimming from 1%, 2%, 3%, ...50%.
# --robust-phy 0.95 means trim 5% of the sites with the least LLK.
# -wsl means write site log-likelihood to .sitelh file in the TREE-PUZZLE format.
# -pre means specify a prefix for all output files.

# trimming from 1%, 2%, 3%, ...20%.
for Num in $(seq 1 1 100); 
do
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 1 -m JC -wsl -pre 100-$Num

iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.99 -m JC -wsl -pre 99-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.98 -m JC -wsl -pre 98-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.97 -m JC -wsl -pre 97-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.96 -m JC -wsl -pre 96-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.95 -m JC -wsl -pre 95-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.94 -m JC -wsl -pre 94-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.93 -m JC -wsl -pre 93-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.92 -m JC -wsl -pre 92-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.91 -m JC -wsl -pre 91-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.90 -m JC -wsl -pre 90-$Num

iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.89 -m JC -wsl -pre 89-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.88 -m JC -wsl -pre 88-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.87 -m JC -wsl -pre 87-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.86 -m JC -wsl -pre 86-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.85 -m JC -wsl -pre 85-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.84 -m JC -wsl -pre 84-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2-s $Num-sim.fst --robust-phy 0.83 -m JC -wsl -pre 83-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.82 -m JC -wsl -pre 82-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.81 -m JC -wsl -pre 81-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.80 -m JC -wsl -pre 80-$Num

iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.79 -m JC -wsl -pre 79-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.78 -m JC -wsl -pre 78-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.77 -m JC -wsl -pre 77-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.76 -m JC -wsl -pre 76-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.75 -m JC -wsl -pre 75-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.74 -m JC -wsl -pre 74-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.73 -m JC -wsl -pre 73-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.72 -m JC -wsl -pre 72-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.71 -m JC -wsl -pre 71-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.70 -m JC -wsl -pre 70-$Num

iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.69 -m JC -wsl -pre 69-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.68 -m JC -wsl -pre 68-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.67 -m JC -wsl -pre 67-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.66 -m JC -wsl -pre 66-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.65 -m JC -wsl -pre 65-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.64 -m JC -wsl -pre 64-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.63 -m JC -wsl -pre 63-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.62 -m JC -wsl -pre 62-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.61 -m JC -wsl -pre 61-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.60 -m JC -wsl -pre 60-$Num

iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.59 -m JC -wsl -pre 59-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.58 -m JC -wsl -pre 58-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.57 -m JC -wsl -pre 57-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.56 -m JC -wsl -pre 56-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.55 -m JC -wsl -pre 55-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.54 -m JC -wsl -pre 54-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.53 -m JC -wsl -pre 53-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.52 -m JC -wsl -pre 52-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.51 -m JC -wsl -pre 51-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.50 -m JC -wsl -pre 50-$Num
done
