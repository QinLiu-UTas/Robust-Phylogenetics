# This script is to produce the figures for the saturation simulations.

# load the packages
library(ape)
library(phangorn)
setwd("C:/Users/qliu4/Desktop/Study at UTas/PhD/allRscripts/robust_phylogenetics")
source("robust_phylo_functions.R")
library(TreeSim)
library("stringr")
library(dplyr)

setwd("C:/Users/qliu4/OneDrive - University of Tasmania/Desktop/Study at UTas/PhD/robust_phylogenetics/allRscripts/paper-simulation-ideas/cummins-2011-exact-22Apr")
load("PH85_consensus_figure.Rdata")

library(ggplot2)
# Assuming df_PH85_consensus is your data frame
df_PH85_consensus_modify <- data.frame(
  Category = as.character(0:50),
  Average_Score = as.numeric(df_PH85_consensus$dist_ph85_consensus)
)

custom_levels <- as.character(0:50)

# Convert Category to a factor with custom levels
df_PH85_consensus_modify$Category <- factor(df_PH85_consensus_modify$Category, levels = custom_levels)

# Plotting using ggplot

ggplot(data = df_PH85_consensus_modify, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  theme_bw() +
  labs(title = "Average RF Scores", y = "Average RF Score", x = "% of site removed") +
  scale_x_discrete(labels = df_PH85_consensus_modify$Category)


library(ggplot2)

# Define custom colors and shapes
custom_colors <- c("#CC79A7",  "#E69F00", "#0072B2")
custom_shapes <-c(18, 16, 17)#(16=circle, 17=triangle, 18=square)

# Plot with custom colors and shapes
ggplot(data = df_PH85_consensus_modify, aes(x = as.factor(Category), y = Average_Score, color = as.factor(Average_Score), shape = as.factor(Average_Score))) +
  geom_point(size = 8) +
  theme_bw() +
  labs(y = "Average RF Score", x = "% of site removed") +
  scale_color_manual(values = custom_colors) +
  scale_shape_manual(values = custom_shapes) +
  theme(
    text = element_text(size = 16),  # Adjust the overall text size
    axis.text.x = element_text(size = 20, angle = 90, vjust = 0.5, hjust = 1,color = "black"),  # Adjust x-axis text size
    axis.text.y = element_text(size = 20,color = "black"),  # Adjust y-axis text size
    axis.title.x = element_text(size = 25),  # Adjust x-axis title size
    axis.title.y = element_text(size = 25),  # Adjust y-axis title size
    plot.title = element_text(size = 16),
   # panel.grid.major = element_blank(),  # Remove major grid lines
   # panel.grid.minor = element_blank(),  # Remove minor grid lines
    legend.position = "none"  # Remove legend
  )
###########################################

###############################################################
# Error bars
vectors_RF<-list(
  dist_ph85_100per,
  dist_ph85_99per,
  dist_ph85_98per,
  dist_ph85_97per,
  dist_ph85_96per,
  dist_ph85_95per,
  dist_ph85_94per,
  dist_ph85_93per,
  dist_ph85_92per,
  dist_ph85_91per,
  dist_ph85_90per,
  dist_ph85_89per,
  dist_ph85_88per,
  dist_ph85_87per,
  dist_ph85_86per,
  dist_ph85_85per,
  dist_ph85_84per,
  dist_ph85_83per,
  dist_ph85_82per,
  dist_ph85_81per,
  dist_ph85_80per,
  dist_ph85_79per,
  dist_ph85_78per,
  dist_ph85_77per,
  dist_ph85_76per,
  dist_ph85_75per,
  dist_ph85_74per,
  dist_ph85_73per,
  dist_ph85_72per,
  dist_ph85_71per,
  dist_ph85_70per,
  dist_ph85_69per,
  dist_ph85_68per,
  dist_ph85_67per,
  dist_ph85_66per,
  dist_ph85_65per,
  dist_ph85_64per,
  dist_ph85_63per,
  dist_ph85_62per,
  dist_ph85_61per,
  dist_ph85_60per,
  dist_ph85_59per,
  dist_ph85_58per,
  dist_ph85_57per,
  dist_ph85_56per,
  dist_ph85_55per,
  dist_ph85_54per,
  dist_ph85_53per,
  dist_ph85_52per,
  dist_ph85_51per,
  dist_ph85_50per)
means_RF<-sapply(vectors_RF,mean)
sds_RF<-sapply(vectors_RF,sd)


x_values <-seq(0,51,length.out=length(sds_RF))

n_values<-100
se_RF <- sds_RF / sqrt(n_values)
########################################################
setwd("C:/Users/qliu4/OneDrive - University of Tasmania/Desktop/Study at UTas/PhD/robust_phylogenetics/allRscripts/paper-simulation-ideas/cummins-2011-exact-22Apr")
save(x_values,means_RF,sds_RF,
     vectors_RF,se_RF,
     file = "RF_MeanSE_figures.Rdata"
)
setwd("C:/Users/qliu4/OneDrive - University of Tasmania/Desktop/Study at UTas/PhD/robust_phylogenetics/allRscripts/paper-simulation-ideas/cummins-2011-exact-22Apr")
load("RF_MeanSE_figures.Rdata")

df_RF <- data.frame(x_values = x_values, means = means_RF, se = se_RF)
# Plot the mean values with different colors for each simulation
library(ggplot2)
library(grid)  # For 'element_rect()'

ggplot(df_RF, aes(x = x_values, y = means)) +
  geom_point(size = 6, color = "darkblue") +
  geom_line(linewidth = 1, color = "darkblue") +  # Replace size with linewidth
  geom_errorbar(aes(ymin = means - 2 * se, ymax = means + 2 * se), 
                width = 0.3, color = "gray40", size = 1.5) +
  scale_y_continuous(limits = range(df_RF$means - 2 * df_RF$se, 
                                    df_RF$means + 2 * df_RF$se)) +
  labs(y = "Mean ± 2*SE") +
  theme_minimal(base_size = 20) +
  theme(panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
        panel.border = element_rect(color = "black", fill = NA, linewidth = 1))  # Replace size with linewidth
