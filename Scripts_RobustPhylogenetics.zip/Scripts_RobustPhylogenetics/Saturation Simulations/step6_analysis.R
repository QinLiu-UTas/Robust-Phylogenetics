# This script is to analyse the restults for the saturation simulations.


# load the packages
library(ape)
library(phangorn)
setwd("C:/Users/qliu4/Desktop/Study at UTas/PhD/allRscripts/robust_phylogenetics")
source("robust_phylo_functions.R")
library(TreeSim)
library("stringr")
library(dplyr)

setwd("C:/Users/qliu4/OneDrive - University of Tasmania/Desktop/Study at UTas/PhD/robust_phylogenetics/allRscripts/paper-simulation-ideas/cummins-2011-exact-22Apr")
true_tree<-read.tree("t1.tre")
plot(true_tree)
edgelabels(round(true_tree$edge.length, 4), col = "black", bg = "lightgray",adj = c(0.9, 0.5),frame = "rect",cex=0.7)
is.rooted(true_tree)
cat(write.tree(true_tree))
plot(true_tree,type="cladogram")
edgelabels(round(true_tree$edge.length, 4), col = "black", bg = "lightgray",adj = c(0.9, 0.5),frame = "rect",cex=0.7)

cat(write.tree(true_tree))
#####################
# load the trees using the following functions

library(gtools)
# g.read_tree and g.read_tree_tre are very similar.
# g.read_tree reads the .treefile while g.read_tree_tre reads the .tre files
g.read_tree<-function(filedir_1){
  tree<-list()
  temp_list_tree_p1<-list()
  for (i in 1:length(filedir_1)){
    setwd(filedir_1[i])
    listtree_g <- dir(pattern = "*.treefile") 
    listtree_g <- mixedsort(listtree_g)
    listtree_g<-rev(listtree_g)
    list_all_g<-list()
    for (k in 1:length(listtree_g)){
      list_all_g[[k]] <-unroot(read.tree(listtree_g[k]))
    }
    tree[[i]]<-list_all_g
    setwd("..")
  }
  return(tree)
}

g.read_tree_tre <- function(filedir_1) {
  tree <- list()
  
  for (i in 1:length(filedir_1)) {
    setwd(filedir_1[i])
    listtree_g <- dir(pattern = "*.tre")
    
    # Sort the list of files by numeric values
    listtree_g <- mixedsort(listtree_g)
    listtree_g<-rev(listtree_g)
    
    list_all_g <- list()
    
    for (k in 1:length(listtree_g)) {
      list_all_g[[k]] <- unroot(read.tree(listtree_g[k]))
    }
    
    tree[[i]] <- list_all_g
    setwd("..")
  }
  
  return(tree)
}
####################################

setwd("C:/Users/qliu4/Desktop/Study at UTas/PhD/allRscripts/robust_phylogenetics/paper-simulation-ideas/cummins-2011-exact-22Apr")
dirfile_tree<-c("./100-per-results",
                "./99-per-results", "./98-per-results",
                "./97-per-results", "./96-per-results",
                "./95-per-results", "./94-per-results",
                "./93-per-results","./92-per-results",
                "./91-per-results", "./90-per-results",
                "./89-per-results", "./88-per-results",
                "./87-per-results", "./86-per-results",
                "./85-per-results", "./84-per-results",
                "./83-per-results","./82-per-results",
                "./81-per-results", "./80-per-results",
                "./79-per-results", "./78-per-results",
                "./77-per-results", "./76-per-results",
                "./75-per-results", "./74-per-results",
                "./73-per-results","./72-per-results",
                "./71-per-results", "./70-per-results",
                "./69-per-results", "./68-per-results",
                "./67-per-results", "./66-per-results",
                "./65-per-results", "./64-per-results",
                "./63-per-results","./62-per-results",
                "./61-per-results", "./60-per-results",
                "./59-per-results", "./58-per-results",
                "./57-per-results", "./56-per-results",
                "./55-per-results", "./54-per-results",
                "./53-per-results","./52-per-results",
                "./51-per-results", "./50-per-results")

tree_RP<-g.read_tree(dirfile_tree)
length(tree_RP)
tree_100per<-tree_RP[[1]]
tree_99per<-tree_RP[[2]]
tree_98per<-tree_RP[[3]]
tree_97per<-tree_RP[[4]]
tree_96per<-tree_RP[[5]]
tree_95per<-tree_RP[[6]]
tree_94per<-tree_RP[[7]]
tree_93per<-tree_RP[[8]]
tree_92per<-tree_RP[[9]]
tree_91per<-tree_RP[[10]]
tree_90per<-tree_RP[[11]]
tree_89per<-tree_RP[[12]]
tree_88per<-tree_RP[[13]]
tree_87per<-tree_RP[[14]]
tree_86per<-tree_RP[[15]]
tree_85per<-tree_RP[[16]]
tree_84per<-tree_RP[[17]]
tree_83per<-tree_RP[[18]]
tree_82per<-tree_RP[[19]]
tree_81per<-tree_RP[[20]]
tree_80per<-tree_RP[[21]]
tree_79per<-tree_RP[[22]]
tree_78per<-tree_RP[[23]]
tree_77per<-tree_RP[[24]]
tree_76per<-tree_RP[[25]]
tree_75per<-tree_RP[[26]]
tree_74per<-tree_RP[[27]]
tree_73per<-tree_RP[[28]]
tree_72per<-tree_RP[[29]]
tree_71per<-tree_RP[[30]]
tree_70per<-tree_RP[[31]]
tree_69per<-tree_RP[[32]]
tree_68per<-tree_RP[[33]]
tree_67per<-tree_RP[[34]]
tree_66per<-tree_RP[[35]]
tree_65per<-tree_RP[[36]]
tree_64per<-tree_RP[[37]]
tree_63per<-tree_RP[[38]]
tree_62per<-tree_RP[[39]]
tree_61per<-tree_RP[[40]]
tree_60per<-tree_RP[[41]]
tree_59per<-tree_RP[[42]]
tree_58per<-tree_RP[[43]]
tree_57per<-tree_RP[[44]]
tree_56per<-tree_RP[[45]]
tree_55per<-tree_RP[[46]]
tree_54per<-tree_RP[[47]]
tree_53per<-tree_RP[[48]]
tree_52per<-tree_RP[[49]]
tree_51per<-tree_RP[[50]]
tree_50per<-tree_RP[[51]]

#check,correct
cat(write.tree(tree_53per[[13]]))

###############################################################


setwd("C:/Users/qliu4/Desktop/Study at UTas/PhD/allRscripts/robust_phylogenetics/paper-simulation-ideas/cummins-2011-exact-22Apr")
save(tree_100per,
     tree_99per,tree_98per,
     tree_97per,tree_96per,
     tree_95per,tree_94per,
     tree_93per,tree_92per,
     tree_91per,tree_90per,
     tree_89per,tree_88per,
     tree_87per,tree_86per,
     tree_85per,tree_84per,
     tree_83per,tree_82per,
     tree_81per,tree_80per,
     tree_79per,tree_78per,
     tree_77per,tree_76per,
     tree_75per,tree_74per,
     tree_73per,tree_72per,
     tree_71per,tree_70per,
     tree_69per,tree_68per,
     tree_67per,tree_66per,
     tree_65per,tree_64per,
     tree_63per,tree_62per,
     tree_61per,tree_60per,
     tree_59per,tree_58per,
     tree_57per,tree_56per,
     tree_55per,tree_54per,
     tree_53per,tree_52per,
     tree_51per,tree_50per,
     true_tree,tree_RP,
     file="tree.Rdata")

#load("tree.Rdata")
######################################
# compare topologies and branch scores
is.rooted(tree_100per[[1]])
is.rooted(true_tree)

dist_ph85 <- list()

# Create and add empty vectors to the list
for (i in 1:1:length(tree_RP)) {
  # Create an empty numeric vector
  dist_ph85[[i]] <- rep(-1,length(tree_100per))   # Add the empty vector to the list
}

# tree_RP[[1]] stores 100per inferred trees, and tree_RP[[21]] stores 80per inferred trees

for (i in 1:length(tree_RP)){
  for (j in 1:length(tree_100per)){
    dist_ph85[[i]][[j]]<-dist.topo(true_tree, tree_RP[[i]][[j]])
  }
}
dist_ph85_100per<-dist_ph85[[1]]
dist_ph85_99per<-dist_ph85[[2]]
dist_ph85_98per<-dist_ph85[[3]]
dist_ph85_97per<-dist_ph85[[4]]
dist_ph85_96per<-dist_ph85[[5]]
dist_ph85_95per<-dist_ph85[[6]]
dist_ph85_94per<-dist_ph85[[7]]
dist_ph85_93per<-dist_ph85[[8]]
dist_ph85_92per<-dist_ph85[[9]]
dist_ph85_91per<-dist_ph85[[10]]
dist_ph85_90per<-dist_ph85[[11]]
dist_ph85_89per<-dist_ph85[[12]]
dist_ph85_88per<-dist_ph85[[13]]
dist_ph85_87per<-dist_ph85[[14]]
dist_ph85_86per<-dist_ph85[[15]]
dist_ph85_85per<-dist_ph85[[16]]
dist_ph85_84per<-dist_ph85[[17]]
dist_ph85_83per<-dist_ph85[[18]]
dist_ph85_82per<-dist_ph85[[19]]
dist_ph85_81per<-dist_ph85[[20]]
dist_ph85_80per<-dist_ph85[[21]]
dist_ph85_79per<-dist_ph85[[22]]
dist_ph85_78per<-dist_ph85[[23]]
dist_ph85_77per<-dist_ph85[[24]]
dist_ph85_76per<-dist_ph85[[25]]
dist_ph85_75per<-dist_ph85[[26]]
dist_ph85_74per<-dist_ph85[[27]]
dist_ph85_73per<-dist_ph85[[28]]
dist_ph85_72per<-dist_ph85[[29]]
dist_ph85_71per<-dist_ph85[[30]]
dist_ph85_70per<-dist_ph85[[31]]
dist_ph85_69per<-dist_ph85[[32]]
dist_ph85_68per<-dist_ph85[[33]]
dist_ph85_67per<-dist_ph85[[34]]
dist_ph85_66per<-dist_ph85[[35]]
dist_ph85_65per<-dist_ph85[[36]]
dist_ph85_64per<-dist_ph85[[37]]
dist_ph85_63per<-dist_ph85[[38]]
dist_ph85_62per<-dist_ph85[[39]]
dist_ph85_61per<-dist_ph85[[40]]
dist_ph85_60per<-dist_ph85[[41]]
dist_ph85_59per<-dist_ph85[[42]]
dist_ph85_58per<-dist_ph85[[43]]
dist_ph85_57per<-dist_ph85[[44]]
dist_ph85_56per<-dist_ph85[[45]]
dist_ph85_55per<-dist_ph85[[46]]
dist_ph85_54per<-dist_ph85[[47]]
dist_ph85_53per<-dist_ph85[[48]]
dist_ph85_52per<-dist_ph85[[49]]
dist_ph85_51per<-dist_ph85[[50]]
dist_ph85_50per<-dist_ph85[[51]]
###############################################
# Branch errors
# Initialize an empty list
dist_BE <- list()

# Create and add empty vectors to the list
for (i in 1:1:length(tree_100per)) {
  # Create an empty numeric vector
  dist_BE[[i]] <- rep(-1,length(tree_100per))   # Add the empty vector to the list
}

for (i in 1:length(tree_RP)){
  for (j in 1:length(tree_100per)){
    dist_BE[[i]][[j]]<-KF.dist(true_tree, tree_RP[[i]][[j]])
  }
}

BranchError_100per<-dist_BE[[1]]
BranchError_99per<-dist_BE[[2]]
BranchError_98per<-dist_BE[[3]]
BranchError_97per<-dist_BE[[4]]
BranchError_96per<-dist_BE[[5]]
BranchError_95per<-dist_BE[[6]]
BranchError_94per<-dist_BE[[7]]
BranchError_93per<-dist_BE[[8]]
BranchError_92per<-dist_BE[[9]]
BranchError_91per<-dist_BE[[10]]
BranchError_90per<-dist_BE[[11]]
BranchError_89per<-dist_BE[[12]]
BranchError_88per<-dist_BE[[13]]
BranchError_87per<-dist_BE[[14]]
BranchError_86per<-dist_BE[[15]]
BranchError_85per<-dist_BE[[16]]
BranchError_84per<-dist_BE[[17]]
BranchError_83per<-dist_BE[[18]]
BranchError_82per<-dist_BE[[19]]
BranchError_81per<-dist_BE[[20]]
BranchError_80per<-dist_BE[[21]]
BranchError_79per<-dist_BE[[22]]
BranchError_78per<-dist_BE[[23]]
BranchError_77per<-dist_BE[[24]]
BranchError_76per<-dist_BE[[25]]
BranchError_75per<-dist_BE[[26]]
BranchError_74per<-dist_BE[[27]]
BranchError_73per<-dist_BE[[28]]
BranchError_72per<-dist_BE[[29]]
BranchError_71per<-dist_BE[[30]]
BranchError_70per<-dist_BE[[31]]
BranchError_69per<-dist_BE[[32]]
BranchError_68per<-dist_BE[[33]]
BranchError_67per<-dist_BE[[34]]
BranchError_66per<-dist_BE[[35]]
BranchError_65per<-dist_BE[[36]]
BranchError_64per<-dist_BE[[37]]
BranchError_63per<-dist_BE[[38]]
BranchError_62per<-dist_BE[[39]]
BranchError_61per<-dist_BE[[40]]
BranchError_60per<-dist_BE[[41]]
BranchError_59per<-dist_BE[[42]]
BranchError_58per<-dist_BE[[43]]
BranchError_57per<-dist_BE[[44]]
BranchError_56per<-dist_BE[[45]]
BranchError_55per<-dist_BE[[46]]
BranchError_54per<-dist_BE[[47]]
BranchError_53per<-dist_BE[[48]]
BranchError_52per<-dist_BE[[49]]
BranchError_51per<-dist_BE[[50]]
BranchError_50per<-dist_BE[[51]]

#################################################
# save
setwd("C:/Users/qliu4/Desktop/Study at UTas/PhD/allRscripts/robust_phylogenetics/paper-simulation-ideas/cummins-2011-exact-22Apr")
save(dist_ph85_100per,
     dist_ph85_99per,
     dist_ph85_98per,
     dist_ph85_97per,
     dist_ph85_96per,
     dist_ph85_95per,
     dist_ph85_94per,
     dist_ph85_93per,
     dist_ph85_92per,
     dist_ph85_91per,
     dist_ph85_90per,
     dist_ph85_89per,
     dist_ph85_88per,
     dist_ph85_87per,
     dist_ph85_86per,
     dist_ph85_85per,
     dist_ph85_84per,
     dist_ph85_83per,
     dist_ph85_82per,
     dist_ph85_81per,
     dist_ph85_80per,
     dist_ph85_79per,
     dist_ph85_78per,
     dist_ph85_77per,
     dist_ph85_76per,
     dist_ph85_75per,
     dist_ph85_74per,
     dist_ph85_73per,
     dist_ph85_72per,
     dist_ph85_71per,
     dist_ph85_70per,
     dist_ph85_69per,
     dist_ph85_68per,
     dist_ph85_67per,
     dist_ph85_66per,
     dist_ph85_65per,
     dist_ph85_64per,
     dist_ph85_63per,
     dist_ph85_62per,
     dist_ph85_61per,
     dist_ph85_60per,
     dist_ph85_59per,
     dist_ph85_58per,
     dist_ph85_57per,
     dist_ph85_56per,
     dist_ph85_55per,
     dist_ph85_54per,
     dist_ph85_53per,
     dist_ph85_52per,
     dist_ph85_51per,
     dist_ph85_50per,
     BranchError_100per,
     BranchError_99per,
     BranchError_98per,
     BranchError_97per,
     BranchError_96per,
     BranchError_95per,
     BranchError_94per,
     BranchError_93per,
     BranchError_92per,
     BranchError_91per,
     BranchError_90per,
     BranchError_89per,
     BranchError_88per,
     BranchError_87per,
     BranchError_86per,
     BranchError_85per,
     BranchError_84per,
     BranchError_83per,
     BranchError_82per,
     BranchError_81per,
     BranchError_80per,
     BranchError_79per,
     BranchError_78per,
     BranchError_77per,
     BranchError_76per,
     BranchError_75per,
     BranchError_74per,
     BranchError_73per,
     BranchError_72per,
     BranchError_71per,
     BranchError_70per,
     BranchError_69per,
     BranchError_68per,
     BranchError_67per,
     BranchError_66per,
     BranchError_65per,
     BranchError_64per,
     BranchError_63per,
     BranchError_62per,
     BranchError_61per,
     BranchError_60per,
     BranchError_59per,
     BranchError_58per,
     BranchError_57per,
     BranchError_56per,
     BranchError_55per,
     BranchError_54per,
     BranchError_53per,
     BranchError_52per,
     BranchError_51per,
     BranchError_50per,
     file="BE_PH85.Rdata")
#######################
setwd("C:/Users/qliu4/OneDrive - University of Tasmania/Desktop/Study at UTas/PhD/robust_phylogenetics/allRscripts/paper-simulation-ideas/cummins-2011-exact-22Apr")

load("tree.Rdata")
load("BE_PH85.Rdata")
# Now calculate the average branch error and RF distances for each per.

avg_PH85_100per<-mean(dist_ph85_100per)
avg_PH85_99per<-mean(dist_ph85_99per)
avg_PH85_98per<-mean(dist_ph85_98per)
avg_PH85_97per<-mean(dist_ph85_97per)
avg_PH85_96per<-mean(dist_ph85_96per)
avg_PH85_95per<-mean(dist_ph85_95per)
avg_PH85_94per<-mean(dist_ph85_94per)
avg_PH85_93per<-mean(dist_ph85_93per)
avg_PH85_92per<-mean(dist_ph85_92per)
avg_PH85_91per<-mean(dist_ph85_91per)
avg_PH85_90per<-mean(dist_ph85_90per)
avg_PH85_89per<-mean(dist_ph85_89per)
avg_PH85_88per<-mean(dist_ph85_88per)
avg_PH85_87per<-mean(dist_ph85_87per)
avg_PH85_86per<-mean(dist_ph85_86per)
avg_PH85_85per<-mean(dist_ph85_85per)
avg_PH85_84per<-mean(dist_ph85_84per)
avg_PH85_83per<-mean(dist_ph85_83per)
avg_PH85_82per<-mean(dist_ph85_82per)
avg_PH85_81per<-mean(dist_ph85_81per)
avg_PH85_80per<-mean(dist_ph85_80per)
avg_PH85_79per<-mean(dist_ph85_79per)
avg_PH85_78per<-mean(dist_ph85_78per)
avg_PH85_77per<-mean(dist_ph85_77per)
avg_PH85_76per<-mean(dist_ph85_76per)
avg_PH85_75per<-mean(dist_ph85_75per)
avg_PH85_74per<-mean(dist_ph85_74per)
avg_PH85_73per<-mean(dist_ph85_73per)
avg_PH85_72per<-mean(dist_ph85_72per)
avg_PH85_71per<-mean(dist_ph85_71per)
avg_PH85_70per<-mean(dist_ph85_70per)
avg_PH85_69per<-mean(dist_ph85_69per)
avg_PH85_68per<-mean(dist_ph85_68per)
avg_PH85_67per<-mean(dist_ph85_67per)
avg_PH85_66per<-mean(dist_ph85_66per)
avg_PH85_65per<-mean(dist_ph85_65per)
avg_PH85_64per<-mean(dist_ph85_64per)
avg_PH85_63per<-mean(dist_ph85_63per)
avg_PH85_62per<-mean(dist_ph85_62per)
avg_PH85_61per<-mean(dist_ph85_61per)
avg_PH85_60per<-mean(dist_ph85_60per)
avg_PH85_59per<-mean(dist_ph85_59per)
avg_PH85_58per<-mean(dist_ph85_58per)
avg_PH85_57per<-mean(dist_ph85_57per)
avg_PH85_56per<-mean(dist_ph85_56per)
avg_PH85_55per<-mean(dist_ph85_55per)
avg_PH85_54per<-mean(dist_ph85_54per)
avg_PH85_53per<-mean(dist_ph85_53per)
avg_PH85_52per<-mean(dist_ph85_52per)
avg_PH85_51per<-mean(dist_ph85_51per)
avg_PH85_50per<-mean(dist_ph85_50per)

df_PH85<-rbind(avg_PH85_100per,
               avg_PH85_99per,
               avg_PH85_98per,
               avg_PH85_97per,
               avg_PH85_96per,
               avg_PH85_95per,
               avg_PH85_94per,
               avg_PH85_93per,
               avg_PH85_92per,
               avg_PH85_91per,
               avg_PH85_90per,
               avg_PH85_89per,
               avg_PH85_88per,
               avg_PH85_87per,
               avg_PH85_86per,
               avg_PH85_85per,
               avg_PH85_84per,
               avg_PH85_83per,
               avg_PH85_82per,
               avg_PH85_81per,
               avg_PH85_80per,
               avg_PH85_79per,
               avg_PH85_78per,
               avg_PH85_77per,
               avg_PH85_76per,
               avg_PH85_75per,
               avg_PH85_74per,
               avg_PH85_73per,
               avg_PH85_72per,
               avg_PH85_71per,
               avg_PH85_70per,
               avg_PH85_69per,
               avg_PH85_68per,
               avg_PH85_67per,
               avg_PH85_66per,
               avg_PH85_65per,
               avg_PH85_64per,
               avg_PH85_63per,
               avg_PH85_62per,
               avg_PH85_61per,
               avg_PH85_60per,
               avg_PH85_59per,
               avg_PH85_58per,
               avg_PH85_57per,
               avg_PH85_56per,
               avg_PH85_55per,
               avg_PH85_54per,
               avg_PH85_53per,
               avg_PH85_52per,
               avg_PH85_51per,
               avg_PH85_50per)
df_PH85<-as.data.frame(df_PH85)
colnames(df_PH85)<-"Avg_PH85"
df_PH85

##
# branch error
avg_BE_100per<-mean(BranchError_100per)
avg_BE_99per<-mean(BranchError_99per)
avg_BE_98per<-mean(BranchError_98per)
avg_BE_97per<-mean(BranchError_97per)
avg_BE_96per<-mean(BranchError_96per)
avg_BE_95per<-mean(BranchError_95per)
avg_BE_94per<-mean(BranchError_94per)
avg_BE_93per<-mean(BranchError_93per)
avg_BE_92per<-mean(BranchError_92per)
avg_BE_91per<-mean(BranchError_91per)
avg_BE_90per<-mean(BranchError_90per)
avg_BE_89per<-mean(BranchError_89per)
avg_BE_88per<-mean(BranchError_88per)
avg_BE_87per<-mean(BranchError_87per)
avg_BE_86per<-mean(BranchError_86per)
avg_BE_85per<-mean(BranchError_85per)
avg_BE_84per<-mean(BranchError_84per)
avg_BE_83per<-mean(BranchError_83per)
avg_BE_82per<-mean(BranchError_82per)
avg_BE_81per<-mean(BranchError_81per)
avg_BE_80per<-mean(BranchError_80per)
avg_BE_79per<-mean(BranchError_79per)
avg_BE_78per<-mean(BranchError_78per)
avg_BE_77per<-mean(BranchError_77per)
avg_BE_76per<-mean(BranchError_76per)
avg_BE_75per<-mean(BranchError_75per)
avg_BE_74per<-mean(BranchError_74per)
avg_BE_73per<-mean(BranchError_73per)
avg_BE_72per<-mean(BranchError_72per)
avg_BE_71per<-mean(BranchError_71per)
avg_BE_70per<-mean(BranchError_70per)
avg_BE_69per<-mean(BranchError_69per)
avg_BE_68per<-mean(BranchError_68per)
avg_BE_67per<-mean(BranchError_67per)
avg_BE_66per<-mean(BranchError_66per)
avg_BE_65per<-mean(BranchError_65per)
avg_BE_64per<-mean(BranchError_64per)
avg_BE_63per<-mean(BranchError_63per)
avg_BE_62per<-mean(BranchError_62per)
avg_BE_61per<-mean(BranchError_61per)
avg_BE_60per<-mean(BranchError_60per)
avg_BE_59per<-mean(BranchError_59per)
avg_BE_58per<-mean(BranchError_58per)
avg_BE_57per<-mean(BranchError_57per)
avg_BE_56per<-mean(BranchError_56per)
avg_BE_55per<-mean(BranchError_55per)
avg_BE_54per<-mean(BranchError_54per)
avg_BE_53per<-mean(BranchError_53per)
avg_BE_52per<-mean(BranchError_52per)
avg_BE_51per<-mean(BranchError_51per)
avg_BE_50per<-mean(BranchError_50per)

df_BE<-rbind(avg_BE_100per,
             avg_BE_99per,
             avg_BE_98per,
             avg_BE_97per,
             avg_BE_96per,
             avg_BE_95per,
             avg_BE_94per,
             avg_BE_93per,
             avg_BE_92per,
             avg_BE_91per,
             avg_BE_90per,
             avg_BE_89per,
             avg_BE_88per,
             avg_BE_87per,
             avg_BE_86per,
             avg_BE_85per,
             avg_BE_84per,
             avg_BE_83per,
             avg_BE_82per,
             avg_BE_81per,
             avg_BE_80per,
             avg_BE_79per,
             avg_BE_78per,
             avg_BE_77per,
             avg_BE_76per,
             avg_BE_75per,
             avg_BE_74per,
             avg_BE_73per,
             avg_BE_72per,
             avg_BE_71per,
             avg_BE_70per,
             avg_BE_69per,
             avg_BE_68per,
             avg_BE_67per,
             avg_BE_66per,
             avg_BE_65per,
             avg_BE_64per,
             avg_BE_63per,
             avg_BE_62per,
             avg_BE_61per,
             avg_BE_60per,
             avg_BE_59per,
             avg_BE_58per,
             avg_BE_57per,
             avg_BE_56per,
             avg_BE_55per,
             avg_BE_54per,
             avg_BE_53per,
             avg_BE_52per,
             avg_BE_51per,
             avg_BE_50per)


df_BE<-as.data.frame(df_BE)
colnames(df_BE)<-"Avg_BE"
df_BE
##########
##########
setwd("C:/Users/qliu4/OneDrive - University of Tasmania/Desktop/Study at UTas/PhD/robust_phylogenetics/allRscripts/paper-simulation-ideas/cummins-2011-exact-22Apr")
load("PH85_BE_figure.Rdata")
save(df_PH85, df_BE, file="PH85_BE_figure.Rdata")

library(ggplot2)
# Assuming df_PH85 is your data frame
df_PH85_modify <- data.frame(
  Category = as.character(0:50),
  Average_Score = as.numeric(df_PH85$Avg_PH85)
)

custom_levels <- as.character(0:50)

# Convert Category to a factor with custom levels
df_PH85_modify$Category <- factor(df_PH85_modify$Category, levels = custom_levels)

# Plotting using ggplot

ggplot(data = df_PH85_modify, aes(x = Category, y = Average_Score)) +
  geom_point(color = "#0072B2", size = 8) +
  theme_bw() +
  labs(y = "Average RF Score", x = "% of site removed") +
  scale_x_discrete(labels = df_PH85_modify$Category)+
  scale_shape_manual(values = c(18, 16)) +
  theme(
    text = element_text(size = 16),  # Adjust the overall text size
    axis.text.x = element_text(size = 16),  # Adjust x-axis text size
    axis.text.y = element_text(size = 16),  # Adjust y-axis text size
    axis.title.x = element_text(size = 25),  # Adjust x-axis title size
    axis.title.y = element_text(size = 25),  # Adjust y-axis title size
    plot.title = element_text(size = 30),  # Adjust plot title size
    plot.margin = margin(10, 10, 10, 10),  # Adjust plot margins
    panel.grid.major = element_line(size = 0.5, color = "grey"),  # Major grid lines
    panel.grid.minor = element_blank(),  # Remove minor grid lines
    legend.position = "bottom"  # Position the legend at the bottom
  )




# Assuming df_BE is your data frame
df_BE_modify <- data.frame(
  Category = as.character(0:50),
  Average_Score = as.numeric(df_BE$Avg_BE)
)
custom_levels <- as.character(0:50)

# Convert Category to a factor with custom levels
df_BE_modify$Category <- factor(df_BE_modify$Category, levels = custom_levels)
# Create a point plot using ggplot2 with custom x-axis labels
ggplot(df_BE_modify, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  labs(title = "Average Branch Error Scores", y = "Average BE Score", x = "% of site removed") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ylim(min(df_BE_modify$Average_Score) - 0.001, max(df_BE_modify$Average_Score) + 0.001) +
  scale_x_discrete(labels = df_BE_modify$Category)
###########################################################################
# Consensus tree

consensus_tree_100per<-consensus(tree_100per, p=0.5, check.labels = TRUE)
plot(consensus_tree_100per)

consensus_tree_99per<-consensus(tree_99per, p=0.5, check.labels = TRUE)
consensus_tree_98per<-consensus(tree_98per, p=0.5, check.labels = TRUE)
consensus_tree_97per<-consensus(tree_97per, p=0.5, check.labels = TRUE)
consensus_tree_96per<-consensus(tree_96per, p=0.5, check.labels = TRUE)
consensus_tree_95per<-consensus(tree_95per, p=0.5, check.labels = TRUE)
consensus_tree_94per<-consensus(tree_94per, p=0.5, check.labels = TRUE)
consensus_tree_93per<-consensus(tree_93per, p=0.5, check.labels = TRUE)
consensus_tree_92per<-consensus(tree_92per, p=0.5, check.labels = TRUE)
consensus_tree_91per<-consensus(tree_91per, p=0.5, check.labels = TRUE)
consensus_tree_90per<-consensus(tree_90per, p=0.5, check.labels = TRUE)

consensus_tree_89per<-consensus(tree_89per, p=0.5, check.labels = TRUE)
consensus_tree_88per<-consensus(tree_88per, p=0.5, check.labels = TRUE)
consensus_tree_87per<-consensus(tree_87per, p=0.5, check.labels = TRUE)
consensus_tree_86per<-consensus(tree_86per, p=0.5, check.labels = TRUE)
consensus_tree_85per<-consensus(tree_85per, p=0.5, check.labels = TRUE)
consensus_tree_84per<-consensus(tree_84per, p=0.5, check.labels = TRUE)
consensus_tree_83per<-consensus(tree_83per, p=0.5, check.labels = TRUE)
consensus_tree_82per<-consensus(tree_82per, p=0.5, check.labels = TRUE)
consensus_tree_81per<-consensus(tree_81per, p=0.5, check.labels = TRUE)
consensus_tree_80per<-consensus(tree_80per, p=0.5, check.labels = TRUE)

consensus_tree_79per<-consensus(tree_79per, p=0.5, check.labels = TRUE)
consensus_tree_78per<-consensus(tree_78per, p=0.5, check.labels = TRUE)
consensus_tree_77per<-consensus(tree_77per, p=0.5, check.labels = TRUE)
consensus_tree_76per<-consensus(tree_76per, p=0.5, check.labels = TRUE)
consensus_tree_75per<-consensus(tree_75per, p=0.5, check.labels = TRUE)
consensus_tree_74per<-consensus(tree_74per, p=0.5, check.labels = TRUE)
consensus_tree_73per<-consensus(tree_73per, p=0.5, check.labels = TRUE)
consensus_tree_72per<-consensus(tree_72per, p=0.5, check.labels = TRUE)
consensus_tree_71per<-consensus(tree_71per, p=0.5, check.labels = TRUE)
consensus_tree_70per<-consensus(tree_70per, p=0.5, check.labels = TRUE)

consensus_tree_69per<-consensus(tree_69per, p=0.5, check.labels = TRUE)
consensus_tree_68per<-consensus(tree_68per, p=0.5, check.labels = TRUE)
consensus_tree_67per<-consensus(tree_67per, p=0.5, check.labels = TRUE)
consensus_tree_66per<-consensus(tree_66per, p=0.5, check.labels = TRUE)
consensus_tree_65per<-consensus(tree_65per, p=0.5, check.labels = TRUE)
consensus_tree_64per<-consensus(tree_64per, p=0.5, check.labels = TRUE)
consensus_tree_63per<-consensus(tree_63per, p=0.5, check.labels = TRUE)
consensus_tree_62per<-consensus(tree_62per, p=0.5, check.labels = TRUE)
consensus_tree_61per<-consensus(tree_61per, p=0.5, check.labels = TRUE)
consensus_tree_60per<-consensus(tree_60per, p=0.5, check.labels = TRUE)

consensus_tree_59per<-consensus(tree_59per, p=0.5, check.labels = TRUE)
consensus_tree_58per<-consensus(tree_58per, p=0.5, check.labels = TRUE)
consensus_tree_57per<-consensus(tree_57per, p=0.5, check.labels = TRUE)
consensus_tree_56per<-consensus(tree_56per, p=0.5, check.labels = TRUE)
consensus_tree_55per<-consensus(tree_55per, p=0.5, check.labels = TRUE)
consensus_tree_54per<-consensus(tree_54per, p=0.5, check.labels = TRUE)
consensus_tree_53per<-consensus(tree_53per, p=0.5, check.labels = TRUE)
consensus_tree_52per<-consensus(tree_52per, p=0.5, check.labels = TRUE)
consensus_tree_51per<-consensus(tree_51per, p=0.5, check.labels = TRUE)
consensus_tree_50per<-consensus(tree_50per, p=0.5, check.labels = TRUE)
######################
# save consensus tree

setwd("C:/Users/qliu4/OneDrive - University of Tasmania/Desktop/Study at UTas/PhD/robust_phylogenetics/allRscripts/paper-simulation-ideas/cummins-2011-exact-22Apr")
save(consensus_tree_100per,
     consensus_tree_99per,consensus_tree_98per,
     consensus_tree_97per,consensus_tree_96per,
     consensus_tree_95per,consensus_tree_94per,
     consensus_tree_93per,consensus_tree_92per,
     consensus_tree_91per,consensus_tree_90per,
     consensus_tree_89per,consensus_tree_88per,
     consensus_tree_87per,consensus_tree_86per,
     consensus_tree_85per,consensus_tree_84per,
     consensus_tree_83per,consensus_tree_82per,
     consensus_tree_81per,consensus_tree_80per,
     consensus_tree_79per,consensus_tree_78per,
     consensus_tree_77per,consensus_tree_76per,
     consensus_tree_75per,consensus_tree_74per,
     consensus_tree_73per,consensus_tree_72per,
     consensus_tree_71per,consensus_tree_70per,
     consensus_tree_69per,consensus_tree_68per,
     consensus_tree_67per,consensus_tree_66per,
     consensus_tree_65per,consensus_tree_64per,
     consensus_tree_63per,consensus_tree_62per,
     consensus_tree_61per,consensus_tree_60per,
     consensus_tree_59per,consensus_tree_58per,
     consensus_tree_57per,consensus_tree_56per,
     consensus_tree_55per,consensus_tree_54per,
     consensus_tree_53per,consensus_tree_52per,
     consensus_tree_51per,consensus_tree_50per,
     file="consensus_tree.Rdata")
load("consensus_tree.Rdata")

# Set the plotting area into 3 rows and 1 column
par(mfrow = c(1, 1), mar = c(4, 4, 2, 1),cex.main = 1.5)  # Adjust margins as needed
plot(consensus_tree_100per)

#################

dist_ph85_consensus_100per<-dist.topo(true_tree, consensus_tree_100per)

dist_ph85_consensus_99per<-dist.topo(true_tree, consensus_tree_99per)
dist_ph85_consensus_98per<-dist.topo(true_tree, consensus_tree_98per)
dist_ph85_consensus_97per<-dist.topo(true_tree, consensus_tree_97per)
dist_ph85_consensus_96per<-dist.topo(true_tree, consensus_tree_96per)
dist_ph85_consensus_95per<-dist.topo(true_tree, consensus_tree_95per)
dist_ph85_consensus_94per<-dist.topo(true_tree, consensus_tree_94per)
dist_ph85_consensus_93per<-dist.topo(true_tree, consensus_tree_93per)
dist_ph85_consensus_92per<-dist.topo(true_tree, consensus_tree_92per)
dist_ph85_consensus_91per<-dist.topo(true_tree, consensus_tree_91per)
dist_ph85_consensus_90per<-dist.topo(true_tree, consensus_tree_90per)

dist_ph85_consensus_89per<-dist.topo(true_tree, consensus_tree_89per)
dist_ph85_consensus_88per<-dist.topo(true_tree, consensus_tree_88per)
dist_ph85_consensus_87per<-dist.topo(true_tree, consensus_tree_87per)
dist_ph85_consensus_86per<-dist.topo(true_tree, consensus_tree_86per)
dist_ph85_consensus_85per<-dist.topo(true_tree, consensus_tree_85per)
dist_ph85_consensus_84per<-dist.topo(true_tree, consensus_tree_84per)
dist_ph85_consensus_83per<-dist.topo(true_tree, consensus_tree_83per)
dist_ph85_consensus_82per<-dist.topo(true_tree, consensus_tree_82per)
dist_ph85_consensus_81per<-dist.topo(true_tree, consensus_tree_81per)
dist_ph85_consensus_80per<-dist.topo(true_tree, consensus_tree_80per)

dist_ph85_consensus_79per<-dist.topo(true_tree, consensus_tree_79per)
dist_ph85_consensus_78per<-dist.topo(true_tree, consensus_tree_78per)
dist_ph85_consensus_77per<-dist.topo(true_tree, consensus_tree_77per)
dist_ph85_consensus_76per<-dist.topo(true_tree, consensus_tree_76per)
dist_ph85_consensus_75per<-dist.topo(true_tree, consensus_tree_75per)
dist_ph85_consensus_74per<-dist.topo(true_tree, consensus_tree_74per)
dist_ph85_consensus_73per<-dist.topo(true_tree, consensus_tree_73per)
dist_ph85_consensus_72per<-dist.topo(true_tree, consensus_tree_72per)
dist_ph85_consensus_71per<-dist.topo(true_tree, consensus_tree_71per)
dist_ph85_consensus_70per<-dist.topo(true_tree, consensus_tree_70per)

dist_ph85_consensus_69per<-dist.topo(true_tree, consensus_tree_69per)
dist_ph85_consensus_68per<-dist.topo(true_tree, consensus_tree_68per)
dist_ph85_consensus_67per<-dist.topo(true_tree, consensus_tree_67per)
dist_ph85_consensus_66per<-dist.topo(true_tree, consensus_tree_66per)
dist_ph85_consensus_65per<-dist.topo(true_tree, consensus_tree_65per)
dist_ph85_consensus_64per<-dist.topo(true_tree, consensus_tree_64per)
dist_ph85_consensus_63per<-dist.topo(true_tree, consensus_tree_63per)
dist_ph85_consensus_62per<-dist.topo(true_tree, consensus_tree_62per)
dist_ph85_consensus_61per<-dist.topo(true_tree, consensus_tree_61per)
dist_ph85_consensus_60per<-dist.topo(true_tree, consensus_tree_60per)

dist_ph85_consensus_59per<-dist.topo(true_tree, consensus_tree_59per)
dist_ph85_consensus_58per<-dist.topo(true_tree, consensus_tree_58per)
dist_ph85_consensus_57per<-dist.topo(true_tree, consensus_tree_57per)
dist_ph85_consensus_56per<-dist.topo(true_tree, consensus_tree_56per)
dist_ph85_consensus_55per<-dist.topo(true_tree, consensus_tree_55per)
dist_ph85_consensus_54per<-dist.topo(true_tree, consensus_tree_54per)
dist_ph85_consensus_53per<-dist.topo(true_tree, consensus_tree_53per)
dist_ph85_consensus_52per<-dist.topo(true_tree, consensus_tree_52per)
dist_ph85_consensus_51per<-dist.topo(true_tree, consensus_tree_51per)
dist_ph85_consensus_50per<-dist.topo(true_tree, consensus_tree_50per)
###
# save
setwd("C:/Users/qliu4/Desktop/Study at UTas/PhD/allRscripts/robust_phylogenetics/paper-simulation-ideas/cummins-2011-exact-22Apr")
save(dist_ph85_consensus_100per,
     dist_ph85_consensus_99per,
     dist_ph85_consensus_98per,
     dist_ph85_consensus_97per,
     dist_ph85_consensus_96per,
     dist_ph85_consensus_95per,
     dist_ph85_consensus_94per,
     dist_ph85_consensus_93per,
     dist_ph85_consensus_92per,
     dist_ph85_consensus_91per,
     dist_ph85_consensus_90per,
     dist_ph85_consensus_89per,
     dist_ph85_consensus_88per,
     dist_ph85_consensus_87per,
     dist_ph85_consensus_86per,
     dist_ph85_consensus_85per,
     dist_ph85_consensus_84per,
     dist_ph85_consensus_83per,
     dist_ph85_consensus_82per,
     dist_ph85_consensus_81per,
     dist_ph85_consensus_80per,
     dist_ph85_consensus_79per,
     dist_ph85_consensus_78per,
     dist_ph85_consensus_77per,
     dist_ph85_consensus_76per,
     dist_ph85_consensus_75per,
     dist_ph85_consensus_74per,
     dist_ph85_consensus_73per,
     dist_ph85_consensus_72per,
     dist_ph85_consensus_71per,
     dist_ph85_consensus_70per,
     dist_ph85_consensus_69per,
     dist_ph85_consensus_68per,
     dist_ph85_consensus_67per,
     dist_ph85_consensus_66per,
     dist_ph85_consensus_65per,
     dist_ph85_consensus_64per,
     dist_ph85_consensus_63per,
     dist_ph85_consensus_62per,
     dist_ph85_consensus_61per,
     dist_ph85_consensus_60per,
     dist_ph85_consensus_59per,
     dist_ph85_consensus_58per,
     dist_ph85_consensus_57per,
     dist_ph85_consensus_56per,
     dist_ph85_consensus_55per,
     dist_ph85_consensus_54per,
     dist_ph85_consensus_53per,
     dist_ph85_consensus_52per,
     dist_ph85_consensus_51per,
     dist_ph85_consensus_50per,
     file="PH85_consensus.Rdata")

df_PH85_consensus<-rbind(dist_ph85_consensus_100per,
                         dist_ph85_consensus_99per,
                         dist_ph85_consensus_98per,
                         dist_ph85_consensus_97per,
                         dist_ph85_consensus_96per,
                         dist_ph85_consensus_95per,
                         dist_ph85_consensus_94per,
                         dist_ph85_consensus_93per,
                         dist_ph85_consensus_92per,
                         dist_ph85_consensus_91per,
                         dist_ph85_consensus_90per,
                         dist_ph85_consensus_89per,
                         dist_ph85_consensus_88per,
                         dist_ph85_consensus_87per,
                         dist_ph85_consensus_86per,
                         dist_ph85_consensus_85per,
                         dist_ph85_consensus_84per,
                         dist_ph85_consensus_83per,
                         dist_ph85_consensus_82per,
                         dist_ph85_consensus_81per,
                         dist_ph85_consensus_80per,
                         dist_ph85_consensus_79per,
                         dist_ph85_consensus_78per,
                         dist_ph85_consensus_77per,
                         dist_ph85_consensus_76per,
                         dist_ph85_consensus_75per,
                         dist_ph85_consensus_74per,
                         dist_ph85_consensus_73per,
                         dist_ph85_consensus_72per,
                         dist_ph85_consensus_71per,
                         dist_ph85_consensus_70per,
                         dist_ph85_consensus_69per,
                         dist_ph85_consensus_68per,
                         dist_ph85_consensus_67per,
                         dist_ph85_consensus_66per,
                         dist_ph85_consensus_65per,
                         dist_ph85_consensus_64per,
                         dist_ph85_consensus_63per,
                         dist_ph85_consensus_62per,
                         dist_ph85_consensus_61per,
                         dist_ph85_consensus_60per,
                         dist_ph85_consensus_59per,
                         dist_ph85_consensus_58per,
                         dist_ph85_consensus_57per,
                         dist_ph85_consensus_56per,
                         dist_ph85_consensus_55per,
                         dist_ph85_consensus_54per,
                         dist_ph85_consensus_53per,
                         dist_ph85_consensus_52per,
                         dist_ph85_consensus_51per,
                         dist_ph85_consensus_50per)
df_PH85_consensus<-as.data.frame(df_PH85_consensus)
colnames(df_PH85_consensus)<-"dist_ph85_consensus"
df_PH85_consensus

setwd("C:/Users/qliu4/OneDrive - University of Tasmania/Desktop/Study at UTas/PhD/robust_phylogenetics/allRscripts/paper-simulation-ideas/cummins-2011-exact-22Apr")
save(df_PH85_consensus,file="PH85_consensus_figure.Rdata")

load("PH85_consensus_figure.Rdata")

library(ggplot2)
# Assuming df_PH85_consensus is your data frame
df_PH85_consensus_modify <- data.frame(
  Category = as.character(0:50),
  Average_Score = as.numeric(df_PH85_consensus$dist_ph85_consensus)
)

custom_levels <- as.character(0:50)

# Convert Category to a factor with custom levels
df_PH85_consensus_modify$Category <- factor(df_PH85_consensus_modify$Category, levels = custom_levels)

# Plotting using ggplot

ggplot(data = df_PH85_consensus_modify, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  theme_bw() +
  labs(title = "Average RF Scores", y = "Average RF Score", x = "% of site removed") +
  scale_x_discrete(labels = df_PH85_consensus_modify$Category)

# consensus RF =3
plot(consensus_tree_99per)
# consensus RF=4
plot(consensus_tree_90per)
# consensus RF=2
plot(consensus_tree_81per)
