
# store results

  for i in $(seq 50 1 100);
  do
    mkdir -p $i-per-results
  done



  for i in $(seq 50 1 100);
  do
     for Num in $(seq 1 1 100); 
     do
        mv $i-$Num.bionj $i-per-results
        mv $i-$Num.mldist $i-per-results
        mv $i-$Num.ckp.gz $i-per-results
        mv $i-$Num.iqtree $i-per-results
        mv $i-$Num.log $i-per-results
        mv $i-$Num.sitelh $i-per-results
        mv $i-$Num.treefile $i-per-results
     done
  done

