# This script is to generate the tree for the saturation simulation.

# load the packages
library(ape)
library(phangorn)
setwd("C:/Users/qliu4/Desktop/Study at UTas/PhD/allRscripts/robust_phylogenetics")
source("robust_phylo_functions.R")
library(TreeSim)


true_tree<-read.tree(text="((((A:0.5,B:0.5):0.5,(C:0.5,D:0.5):0.5):0.5,E:1.5):0.0,F:1.5,G:1.6);")
plot(true_tree)
edgelabels(round(true_tree$edge.length, 4), col = "black", bg = "lightgray",adj = c(0.9, 0.5),frame = "rect",cex=0.7)


setwd("C:/Users/qliu4/Desktop/Study at UTas/PhD/allRscripts/robust_phylogenetics/paper-simulation-ideas/cummins-2011-exact-22Apr")
write.tree(true_tree,file ="t1.tre")
