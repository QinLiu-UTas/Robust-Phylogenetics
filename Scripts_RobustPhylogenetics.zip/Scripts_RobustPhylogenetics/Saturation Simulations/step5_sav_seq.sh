# save a copy of the sequences


mkdir sequence

for Num in $(seq 1 1 100); 
do
mv $Num-sim.fst sequence
done

