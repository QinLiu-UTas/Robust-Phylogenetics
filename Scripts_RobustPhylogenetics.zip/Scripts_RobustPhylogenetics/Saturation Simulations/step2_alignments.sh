# Simulate a alignment under the t1.tree and a JC model.
# -mHKY + omitting the -t option + omitting the -f option = JC model.

for Num in $(seq 1 1 100); 
do
seq-gen -mHKY -z20240422$Num -l999 -n1 <t1.tre>  $Num-sim.fst
done
