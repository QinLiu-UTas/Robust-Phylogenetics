################################# g.ib ########################################
#' This function return the two nodes for each internal branch (start node and end node of each branch). 
#' @param list_nnitree A list containing all the NNI trees.
#' @param tree The tree (a phylo object) from which the NNI trees were inferred.
#' @return A data frame containing the index of the NNI tree, and the corresponding nodes for the internal edges.

g.ib<-function(tree,list_nnitree) {
  # Create a data frame storing the information of which NNI tree was inferred by fixing which internal edge.
  df_ib<- as.data.frame(matrix(data=NA, nrow=length(list_nnitree),ncol = 3))
  # node1 and node2 shows the fixed internal branch for a particular NNI tree.
  colnames(df_ib)<-c("NNI_tree","node1","node2")
  # Try to find which rows are the same. Each row represent an edge (internal edges or terminal edges)
  for (i in 1:length(list_nnitree)){
    x_tree<-transform(data.frame(t(apply(tree$edge, 1, sort))), row = 1:nrow(tree$edge))
    y_nni<-data.frame(t(apply(list_nnitree[[i]]$edge, 1, sort)))

    # same rows are shown in the dataframe row_common$row
    row_common<-merge(x_tree, y_nni)
    
    # Find which rows are different
    tree_row<-c(1:nrow(tree$edge))
    
    # vec_diff shows the different rows. I think and I hope it is always 2 rows.
    vec_diff<-setdiff(tree_row,row_common$row)
    df_ib$NNI_tree[i]<- i
    # the index of the internal node is stored in the first column of the tree$edge, we just need to find the correct row.
    #vec_diff[1] shows the first different row, vec_diff[2] shows the second different row. 
    df_ib$node1[i]<-tree$edge[vec_diff[1],1]
    df_ib$node2[i]<-tree$edge[vec_diff[2],1]
  }
  return (df_ib)
}


