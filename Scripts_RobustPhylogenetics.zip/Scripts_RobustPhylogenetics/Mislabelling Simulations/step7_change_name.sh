# Change a file name of the mislabelling alignments

# Set the old and new filenames

for Num in $(seq 1 1 400); 
do
old_filename="$Num-simc1c2.fst"
new_filename="$Num-simc1c2-swap.fst"

# Rename the file
mv "$old_filename" "$new_filename"

done
