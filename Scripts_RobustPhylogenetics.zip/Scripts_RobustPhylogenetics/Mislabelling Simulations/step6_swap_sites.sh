# This step is to swap characters between two randomly chosen tips. The tips were chosen randomly using two files:
# "randnum_num_first.txt"
# "randnum_num_second.txt"
# For example, for the first alignment, the first tip was chosen based on the first number in the first txt file.
# the second tip was chosen based on the first number in the second txt file.
# These random numbers in the txt files above were generated using R.

############################################
#####################################################
# Set the paths to your files
random_num_first_file="$HOME/Documents/Robust_Phylogenetics/swap_labels_simulation/swap-leaves-short/random_num_first.txt"
random_num_second_file="$HOME/Documents/Robust_Phylogenetics/swap_labels_simulation/swap-leaves-short/random_num_second.txt"

# Read the contents of the text files into arrays
IFS=$'\n' arrayc1five=($(cat "$random_num_first_file"))
IFS=$'\n' arrayc2five=($(cat "$random_num_second_file"))


# Define the start and end columns
start_col=811
end_col=1010

# Loop through files from 1 to 400
for Num in $(seq 1 400); do
  file_path="$HOME/Documents/Robust_Phylogenetics/swap_labels_simulation/swap-leaves-short/$Num-simc1c2.fst"

  # Define the file path
  file_path=$(eval echo "$file_path")

  # The numbers in each file all has an unknown character behind, need to get rid of it.
  x=$(echo "${arrayc1five[$((Num-1))]}" | sed -e 's/[^0-9]*$//')
  y=$(echo "${arrayc2five[$((Num-1))]}" | sed -e 's/[^0-9]*$//')
  # Loop through columns for swapping
  for ((col=$start_col; col<=$end_col; col++)); do
    # Extract the characters to be swapped from line1 and line2
    char1=$(sed -n "${x}p" "$file_path" | cut -c "$col")
    char2=$(sed -n "${y}p" "$file_path" | cut -c "$col")

    # Replace the characters in their respective lines and columns
    sed -i "${x}s/./${char2}/$col" "$file_path"
    sed -i "${y}s/./${char1}/$col" "$file_path"
  done
done
