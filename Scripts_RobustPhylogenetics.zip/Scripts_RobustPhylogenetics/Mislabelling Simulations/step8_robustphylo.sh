# Use IQTREE2 to infer tree and use the trimmed log-likelihood method to remove sites from 1%, 2%, 3%, ...20%.
#--robust-phy 0.95 means trim 5% of the sites with the least LLK.
# -wsl means write site log-likelihood to .sitelh file in the TREE-PUZZLE format.
# -pre means specify a prefix for all output files.

for Num in $(seq 1 1 400); 
do
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 1 -m JC -wsl -pre 100-$Num

iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.99 -m JC -wsl -pre 99-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.98 -m JC -wsl -pre 98-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.97 -m JC -wsl -pre 97-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.96 -m JC -wsl -pre 96-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.95 -m JC -wsl -pre 95-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.94 -m JC -wsl -pre 94-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.93 -m JC -wsl -pre 93-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.92 -m JC -wsl -pre 92-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.91 -m JC -wsl -pre 91-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.90 -m JC -wsl -pre 90-$Num

iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.89 -m JC -wsl -pre 89-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.88 -m JC -wsl -pre 88-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.87 -m JC -wsl -pre 87-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.86 -m JC -wsl -pre 86-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.85 -m JC -wsl -pre 85-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.84 -m JC -wsl -pre 84-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2-s $Num-sim.fst --robust-phy 0.83 -m JC -wsl -pre 83-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.82 -m JC -wsl -pre 82-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.81 -m JC -wsl -pre 81-$Num
iqtree-2.2.2.5-Linux/bin/iqtree2 -s $Num-sim.fst --robust-phy 0.80 -m JC -wsl -pre 80-$Num
done
