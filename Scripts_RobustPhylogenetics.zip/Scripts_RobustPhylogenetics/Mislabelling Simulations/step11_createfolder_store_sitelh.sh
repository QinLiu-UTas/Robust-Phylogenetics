# This script is to make folders to store site log-likelihood files.

mkdir -p all_tree_sitelh_txt

for k in $(seq 80 1 100);
do
mkdir -p "all_tree_sitelh_txt/${k}-sitelh"
done
