# Save a copy of the sequences
mkdir sequence
for Num in $(seq 1 1 400); 
do
cp $Num-simc1c2.fst sequence
done
