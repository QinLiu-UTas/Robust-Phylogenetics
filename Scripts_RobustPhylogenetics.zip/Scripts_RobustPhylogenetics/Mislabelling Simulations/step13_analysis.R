# This script is to analyse the results from IQTREE2.
# This script is for the Short branch length simulations. The scripts for the other branch length simulations are similar.

# Load packages:
library(ape)
library(phangorn)
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation")
source("robust_phylo_functions.R")

library(gtools)
# g.read_tree and g.read_tree_tre are very similar.
# g.read_tree reads the .treefile while g.read_tree_tre reads the .tre files
g.read_tree<-function(filedir_1){
  tree<-list()
  temp_list_tree_p1<-list()
  for (i in 1:length(filedir_1)){
    setwd(filedir_1[i])
    listtree_g <- dir(pattern = "*.treefile") 
    listtree_g <- mixedsort(listtree_g)
    listtree_g<-rev(listtree_g)
    list_all_g<-list()
    for (k in 1:length(listtree_g)){
      list_all_g[[k]] <-unroot(read.tree(listtree_g[k]))
    }
    tree[[i]]<-list_all_g
    setwd("..")
  }
  return(tree)
}

g.read_tree_tre <- function(filedir_1) {
  tree <- list()
  
  for (i in 1:length(filedir_1)) {
    setwd(filedir_1[i])
    listtree_g <- dir(pattern = "*.tre")
    
    # Sort the list of files by numeric values
    listtree_g <- mixedsort(listtree_g)
    listtree_g<-rev(listtree_g)
    
    list_all_g <- list()
    
    for (k in 1:length(listtree_g)) {
      list_all_g[[k]] <- unroot(read.tree(listtree_g[k]))
    }
    
    tree[[i]] <- list_all_g
    setwd("..")
  }
  
  return(tree)
}
####################################

###################################################################
# short
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short")
# Now read in the inferred trees.
dirfile_tree<-c("./100-per-results",
                "./99-per-results", "./98-per-results",
                "./97-per-results", "./96-per-results",
                "./95-per-results", "./94-per-results",
                "./93-per-results","./92-per-results",
                "./91-per-results", "./90-per-results",
                "./89-per-results", "./88-per-results",
                "./87-per-results", "./86-per-results",
                "./85-per-results", "./84-per-results",
                "./83-per-results","./82-per-results",
                "./81-per-results", "./80-per-results")

tree_RP_short<-g.read_tree(dirfile_tree)


tree_100per_short<-tree_RP_short[[1]]
tree_99per_short<-tree_RP_short[[2]]
tree_98per_short<-tree_RP_short[[3]]
tree_97per_short<-tree_RP_short[[4]]
tree_96per_short<-tree_RP_short[[5]]
tree_95per_short<-tree_RP_short[[6]]
tree_94per_short<-tree_RP_short[[7]]
tree_93per_short<-tree_RP_short[[8]]
tree_92per_short<-tree_RP_short[[9]]
tree_91per_short<-tree_RP_short[[10]]
tree_90per_short<-tree_RP_short[[11]]
tree_89per_short<-tree_RP_short[[12]]
tree_88per_short<-tree_RP_short[[13]]
tree_87per_short<-tree_RP_short[[14]]
tree_86per_short<-tree_RP_short[[15]]
tree_85per_short<-tree_RP_short[[16]]
tree_84per_short<-tree_RP_short[[17]]
tree_83per_short<-tree_RP_short[[18]]
tree_82per_short<-tree_RP_short[[19]]
tree_81per_short<-tree_RP_short[[20]]
tree_80per_short<-tree_RP_short[[21]]

#check,correct
cat(write.tree(tree_80per_short[[1]]))
##################
# Read in true tree
###########################
############################
# Read in the true trees
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short")

dirfile_tree<-c("./trees")

tree_true_short<-g.read_tree_tre(dirfile_tree)


tree_true_list_short<-tree_true_short[[1]]


cat(write.tree(tree_true_list_short[[9]]))

##################################
##################################
# Look at these sequences
# How many unique sites and hoa many sites are constant sites?
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation")

source("proj2_function.r")
library("stringr")
library(dplyr)
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short/sequence")


list_fst<-dir(pattern = "*.fst")

n=400
list_seq_short<-list()
vec_const_short<-rep(0,n)
vec_unqsite_short<-rep(0,n)
for (i in 1:n){
  list_seq_short[[i]]<-read.dna(list_fst[i])
  list_seq_short[[i]]<-as.phyDat(list_seq_short[[i]])
  seq1_pattern<-g.sitepattern_df(list_seq_short[[i]])
  seq1_pattern$freq<-as.numeric(as.character(seq1_pattern$freq))
  
  vec_const_short[i]<- sum(seq1_pattern$freq[1:4])
  vec_unqsite_short[i]<-length(seq1_pattern$freq)
}


hist(vec_const_short, main = "Number of constant sites for the simulated sequences",
     xlab = "Number of constant sites")

hist(vec_unqsite_short, main = "Number of unique sites for the simulated sequences",
     xlab = "Number of unique sites")


setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short")
save(vec_const_short,vec_unqsite_short,list_seq_short,
     file="seq_information_short.rData")
###############################################################
################
################

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short")

save(tree_100per_short,
     tree_99per_short,tree_98per_short,
     tree_97per_short,tree_96per_short,
     tree_95per_short,tree_94per_short,
     tree_93per_short,tree_92per_short,
     tree_91per_short,tree_90per_short,
     tree_89per_short,tree_88per_short,
     tree_87per_short,tree_86per_short,
     tree_85per_short,tree_84per_short,
     tree_83per_short,tree_82per_short,
     tree_81per_short,tree_80per_short,
     tree_true_list_short,tree_RP_short,
     file="tree_short.Rdata")
######################################
######################################
# compare topologies and branch scores
is.rooted(tree_100per_short[[1]])
is.rooted(tree_true_list_short[[1]])

PH85_topo<-function(true_tree, infer_tree){
  # Initialize an empty list
  dist_ph85 <- list()
  
  # Create and add empty vectors to the list
  for (i in 1:1:length(infer_tree)) {
    # Create an empty numeric vector
    dist_ph85[[i]] <- rep(-1,length(true_tree))   # Add the empty vector to the list
  }
  
  for (i in 1:length(infer_tree)){
    for (j in 1:length(infer_tree[[i]])){
      dist_ph85[[i]][[j]]<-as.vector(dist.topo(true_tree[[j]],infer_tree[[i]][[j]],method = "PH85"))
    }
  }
  return(dist_ph85)
}

dist_ph85_topo_short<-PH85_topo(tree_true_list_short,tree_RP_short)

dist_ph85_100per_short<-dist_ph85_topo_short[[1]]
dist_ph85_99per_short<-dist_ph85_topo_short[[2]]
dist_ph85_98per_short<-dist_ph85_topo_short[[3]]
dist_ph85_97per_short<-dist_ph85_topo_short[[4]]
dist_ph85_96per_short<-dist_ph85_topo_short[[5]]
dist_ph85_95per_short<-dist_ph85_topo_short[[6]]
dist_ph85_94per_short<-dist_ph85_topo_short[[7]]
dist_ph85_93per_short<-dist_ph85_topo_short[[8]]
dist_ph85_92per_short<-dist_ph85_topo_short[[9]]
dist_ph85_91per_short<-dist_ph85_topo_short[[10]]
dist_ph85_90per_short<-dist_ph85_topo_short[[11]]
dist_ph85_89per_short<-dist_ph85_topo_short[[12]]
dist_ph85_88per_short<-dist_ph85_topo_short[[13]]
dist_ph85_87per_short<-dist_ph85_topo_short[[14]]
dist_ph85_86per_short<-dist_ph85_topo_short[[15]]
dist_ph85_85per_short<-dist_ph85_topo_short[[16]]
dist_ph85_84per_short<-dist_ph85_topo_short[[17]]
dist_ph85_83per_short<-dist_ph85_topo_short[[18]]
dist_ph85_82per_short<-dist_ph85_topo_short[[19]]
dist_ph85_81per_short<-dist_ph85_topo_short[[20]]
dist_ph85_80per_short<-dist_ph85_topo_short[[21]]

######################################
# branch error

KF_BE<-function(true_tree, infer_tree){
  # Initialize an empty list
  dist_KF <- list()
  
  # Create and add empty vectors to the list
  for (i in 1:1:length(infer_tree)) {
    # Create an empty numeric vector
    dist_KF[[i]] <- rep(-1,length(true_tree))   # Add the empty vector to the list
  }
  
  for (i in 1:length(infer_tree)){
    for (j in 1:length(infer_tree[[i]])){
      dist_KF[[i]][[j]]<-KF.dist(true_tree[[j]],infer_tree[[i]][[j]])
    }
  }
  return(dist_KF)
}

BranchError_topo_short<-KF_BE(tree_true_list_short,tree_RP_short)

BranchError_100per_short<-BranchError_topo_short[[1]]
BranchError_99per_short<-BranchError_topo_short[[2]]
BranchError_98per_short<-BranchError_topo_short[[3]]
BranchError_97per_short<-BranchError_topo_short[[4]]
BranchError_96per_short<-BranchError_topo_short[[5]]
BranchError_95per_short<-BranchError_topo_short[[6]]
BranchError_94per_short<-BranchError_topo_short[[7]]
BranchError_93per_short<-BranchError_topo_short[[8]]
BranchError_92per_short<-BranchError_topo_short[[9]]
BranchError_91per_short<-BranchError_topo_short[[10]]
BranchError_90per_short<-BranchError_topo_short[[11]]
BranchError_89per_short<-BranchError_topo_short[[12]]
BranchError_88per_short<-BranchError_topo_short[[13]]
BranchError_87per_short<-BranchError_topo_short[[14]]
BranchError_86per_short<-BranchError_topo_short[[15]]
BranchError_85per_short<-BranchError_topo_short[[16]]
BranchError_84per_short<-BranchError_topo_short[[17]]
BranchError_83per_short<-BranchError_topo_short[[18]]
BranchError_82per_short<-BranchError_topo_short[[19]]
BranchError_81per_short<-BranchError_topo_short[[20]]
BranchError_80per_short<-BranchError_topo_short[[21]]
# save
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")
save(dist_ph85_100per_short,
     dist_ph85_99per_short,
     dist_ph85_98per_short,
     dist_ph85_97per_short,
     dist_ph85_96per_short,
     dist_ph85_95per_short,
     dist_ph85_94per_short,
     dist_ph85_93per_short,
     dist_ph85_92per_short,
     dist_ph85_91per_short,
     dist_ph85_90per_short,
     dist_ph85_89per_short,
     dist_ph85_88per_short,
     dist_ph85_87per_short,
     dist_ph85_86per_short,
     dist_ph85_85per_short,
     dist_ph85_84per_short,
     dist_ph85_83per_short,
     dist_ph85_82per_short,
     dist_ph85_81per_short,
     dist_ph85_80per_short,
     BranchError_100per_short,
     BranchError_99per_short,
     BranchError_98per_short,
     BranchError_97per_short,
     BranchError_96per_short,
     BranchError_95per_short,
     BranchError_94per_short,
     BranchError_93per_short,
     BranchError_92per_short,
     BranchError_91per_short,
     BranchError_90per_short,
     BranchError_89per_short,
     BranchError_88per_short,
     BranchError_87per_short,
     BranchError_86per_short,
     BranchError_85per_short,
     BranchError_84per_short,
     BranchError_83per_short,
     BranchError_82per_short,
     BranchError_81per_short,
     BranchError_80per_short,
     file="BE_PH85_short.Rdata")
########################################################################
#######################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short")
load("tree_short.Rdata.Rdata")
load("BE_PH85_short.Rdata.Rdata")
# Now calculate the average branch error and RF distances for each per.

avg_PH85_100per_short<-mean(dist_ph85_100per_short)
avg_PH85_99per_short<-mean(dist_ph85_99per_short)
avg_PH85_98per_short<-mean(dist_ph85_98per_short)
avg_PH85_97per_short<-mean(dist_ph85_97per_short)
avg_PH85_96per_short<-mean(dist_ph85_96per_short)
avg_PH85_95per_short<-mean(dist_ph85_95per_short)
avg_PH85_94per_short<-mean(dist_ph85_94per_short)
avg_PH85_93per_short<-mean(dist_ph85_93per_short)
avg_PH85_92per_short<-mean(dist_ph85_92per_short)
avg_PH85_91per_short<-mean(dist_ph85_91per_short)
avg_PH85_90per_short<-mean(dist_ph85_90per_short)
avg_PH85_89per_short<-mean(dist_ph85_89per_short)
avg_PH85_88per_short<-mean(dist_ph85_88per_short)
avg_PH85_87per_short<-mean(dist_ph85_87per_short)
avg_PH85_86per_short<-mean(dist_ph85_86per_short)
avg_PH85_85per_short<-mean(dist_ph85_85per_short)
avg_PH85_84per_short<-mean(dist_ph85_84per_short)
avg_PH85_83per_short<-mean(dist_ph85_83per_short)
avg_PH85_82per_short<-mean(dist_ph85_82per_short)
avg_PH85_81per_short<-mean(dist_ph85_81per_short)
avg_PH85_80per_short<-mean(dist_ph85_80per_short)

df_PH85_short<-rbind(avg_PH85_100per_short,
               avg_PH85_99per_short,
               avg_PH85_98per_short,
               avg_PH85_97per_short,
               avg_PH85_96per_short,
               avg_PH85_95per_short,
               avg_PH85_94per_short,
               avg_PH85_93per_short,
               avg_PH85_92per_short,
               avg_PH85_91per_short,
               avg_PH85_90per_short,
               avg_PH85_89per_short,
               avg_PH85_88per_short,
               avg_PH85_87per_short,
               avg_PH85_86per_short,
               avg_PH85_85per_short,
               avg_PH85_84per_short,
               avg_PH85_83per_short,
               avg_PH85_82per_short,
               avg_PH85_81per_short,
               avg_PH85_80per_short)
df_PH85_short<-as.data.frame(df_PH85_short)
colnames(df_PH85_short)<-"Avg_PH85"
df_PH85_short

##
# branch error
avg_BE_100per_short<-mean(BranchError_100per_short)
avg_BE_99per_short<-mean(BranchError_99per_short)
avg_BE_98per_short<-mean(BranchError_98per_short)
avg_BE_97per_short<-mean(BranchError_97per_short)
avg_BE_96per_short<-mean(BranchError_96per_short)
avg_BE_95per_short<-mean(BranchError_95per_short)
avg_BE_94per_short<-mean(BranchError_94per_short)
avg_BE_93per_short<-mean(BranchError_93per_short)
avg_BE_92per_short<-mean(BranchError_92per_short)
avg_BE_91per_short<-mean(BranchError_91per_short)
avg_BE_90per_short<-mean(BranchError_90per_short)
avg_BE_89per_short<-mean(BranchError_89per_short)
avg_BE_88per_short<-mean(BranchError_88per_short)
avg_BE_87per_short<-mean(BranchError_87per_short)
avg_BE_86per_short<-mean(BranchError_86per_short)
avg_BE_85per_short<-mean(BranchError_85per_short)
avg_BE_84per_short<-mean(BranchError_84per_short)
avg_BE_83per_short<-mean(BranchError_83per_short)
avg_BE_82per_short<-mean(BranchError_82per_short)
avg_BE_81per_short<-mean(BranchError_81per_short)
avg_BE_80per_short<-mean(BranchError_80per_short)

df_BE_short<-rbind(avg_BE_100per_short,
             avg_BE_99per_short,
             avg_BE_98per_short,
             avg_BE_97per_short,
             avg_BE_96per_short,
             avg_BE_95per_short,
             avg_BE_94per_short,
             avg_BE_93per_short,
             avg_BE_92per_short,
             avg_BE_91per_short,
             avg_BE_90per_short,
             avg_BE_89per_short,
             avg_BE_88per_short,
             avg_BE_87per_short,
             avg_BE_86per_short,
             avg_BE_85per_short,
             avg_BE_84per_short,
             avg_BE_83per_short,
             avg_BE_82per_short,
             avg_BE_81per_short,
             avg_BE_80per_short)

df_BE_short<-as.data.frame(df_BE_short)
colnames(df_BE_short)<-"Avg_BE"
df_BE_short
##########
# Plot the average scores


library(ggplot2)
# Assuming df_PH85 is your data frame
df_PH85_modify_short <- data.frame(
  Category = as.character(0:20),
  Average_Score = as.numeric(df_PH85_short$Avg_PH85)
)

custom_levels <- as.character(0:20)

# Convert Category to a factor with custom levels
df_PH85_modify_short$Category <- factor(df_PH85_modify_short$Category, levels = custom_levels)

# Assuming df_BE is your data frame
df_BE_modify_short <- data.frame(
  Category = as.character(0:20),
  Average_Score = as.numeric(df_BE_short$Avg_BE)
)
custom_levels <- as.character(0:20)

# Convert Category to a factor with custom levels
df_BE_modify_short$Category <- factor(df_BE_modify_short$Category, levels = custom_levels)

###########################
# save
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")
save(df_PH85_modify_short,df_BE_modify_short, file ="figure_short.rdata")

# Plotting using ggplot

ggplot(data = df_PH85_modify_short, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  theme_bw() +
  labs(title = "Average RF Scores", y = "Average RF Score", x = "% of site removed") +
  scale_x_discrete(labels = paste0(df_PH85_modify_short$Category, "%"))





# Create a point plot using ggplot2 with custom x-axis labels
ggplot(df_BE_modify_short, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  labs(title = "Average Branch Error Scores", y = "Average BE Score", x = "% of site removed") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ylim(min(df_BE_modify_short$Average_Score) - 0.001, max(df_BE_modify_short$Average_Score) + 0.001) +
  scale_x_discrete(labels = paste0(df_BE_modify_short$Category, "%"))
################
#####################################################################################
# Now let's see what proportion of sites (or how many of the bottom 200 sites) from the bottom 200 
# sites were removed for each analysis.

#################
# Now put it together.

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short/all_tree_sitelh_txt")

dirfile_sitelh<-c("./100-sitelh",
                  "./99-sitelh", "./98-sitelh",
                  "./97-sitelh", "./96-sitelh",
                  "./95-sitelh", "./94-sitelh",
                  "./93-sitelh","./92-sitelh",
                  "./91-sitelh", "./90-sitelh",
                  "./89-sitelh", "./88-sitelh",
                  "./87-sitelh", "./86-sitelh",
                  "./85-sitelh", "./84-sitelh",
                  "./83-sitelh","./82-sitelh",
                  "./81-sitelh", "./80-sitelh")

# g.read_tree and g.read_tree_tre are very similar.
# g.read_tree reads the .treefile while g.read_tree_tre reads the .tre files
library(gtools)
g.read_sitelh_txt<-function(filedir_1){
  sitelh<-list()
  temp_sitelh<-list()
  for (i in 1:length(filedir_1)){
    setwd(filedir_1[i])
    list_directory <- dir(pattern = "*.txt") 
    # order: 1,2,3,4,5,...,100, instead of 1,10,11,12,13,...2,20,...
    list_directory <- mixedsort(list_directory)
    list_directory<-rev(list_directory)
    for (k in 1:length(list_directory)){
      temp_sitelh[[k]] <-read.table(list_directory[k])
    }
    sitelh[[i]]<-temp_sitelh
    setwd("..")
  }
  return(sitelh)
}

sitelh_list_short<-g.read_sitelh_txt(dirfile_sitelh)
length(sitelh_list_short)

################################################################################
# There are 400 txt file storing in 100per list.
site_lh_100per_short<-sitelh_list_short[[1]]
site_lh_99per_short<-sitelh_list_short[[2]]
site_lh_98per_short<-sitelh_list_short[[3]]
site_lh_97per_short<-sitelh_list_short[[4]]
site_lh_96per_short<-sitelh_list_short[[5]]
site_lh_95per_short<-sitelh_list_short[[6]]
site_lh_94per_short<-sitelh_list_short[[7]]
site_lh_93per_short<-sitelh_list_short[[8]]
site_lh_92per_short<-sitelh_list_short[[9]]
site_lh_91per_short<-sitelh_list_short[[10]]
site_lh_90per_short<-sitelh_list_short[[11]]
site_lh_89per_short<-sitelh_list_short[[12]]
site_lh_88per_short<-sitelh_list_short[[13]]
site_lh_87per_short<-sitelh_list_short[[14]]
site_lh_86per_short<-sitelh_list_short[[15]]
site_lh_85per_short<-sitelh_list_short[[16]]
site_lh_84per_short<-sitelh_list_short[[17]]
site_lh_83per_short<-sitelh_list_short[[18]]
site_lh_82per_short<-sitelh_list_short[[19]]
site_lh_81per_short<-sitelh_list_short[[20]]
site_lh_80per_short<-sitelh_list_short[[21]]

# each list contains 100 vectors (or dataframes) recording the 1000 site likelihoods.
# m is the number of sites removed
g.count_site<-function(list,m){
  n=1000
  count_sites_greater_than_nsubtractm<-rep(0,length(list))
  for (i in 1:length(list)){
    df<-unlist(t(list[[i]]))
    df<-as.data.frame(df)
    colnames(df)<- "sitelh"
    df$site<- c(1:n)
    
    library(dplyr)
    # Rank the site likelihood
    # df <- df %>%
    #   mutate(order = rank(-sitelh))
    
    
    df <- df %>%
      arrange(desc(sitelh))
    
    df$rank<-c(1:n)
    
    subset_df <- df %>%
      filter(rank > ((n-m+1)))
    
    # hard coding 799 here, since we messed up the last 200 sites (1000-200=800, 801-1000)
    # So we want to find out how many removed sites were in the last 200 sites
    # Therefore, site number =>800 or site number >800
    count_sites_greater_than_nsubtractm[i] <- sum(subset_df$site >800)
    
  }
  return(count_sites_greater_than_nsubtractm)
  
}
###################################
vec_99per_removed_1per_short<-g.count_site(site_lh_99per_short,m=10)
# Out of the 10 sites removed, how many sites were in the position of 801-1000?
vec_99per_removed_1per_short

vec_98per_removed_2per_short<-g.count_site(site_lh_98per_short,m=20)
# Out of the 20 sites removed, how many sites were in the position of 801-1000?
vec_98per_removed_2per_short

vec_97per_removed_3per_short<-g.count_site(site_lh_97per_short,m=30)
# Out of the 30 sites removed, how many sites were in the position of 801-1000?
vec_97per_removed_3per_short

vec_96per_removed_4per_short<-g.count_site(site_lh_96per_short,m=40)
# Out of the 40 sites removed, how many sites were in the position of 801-1000?
vec_96per_removed_4per_short

vec_95per_removed_5per_short<-g.count_site(site_lh_95per_short,m=50)
# Out of the 50 sites removed, how many sites were in the position of 801-1000?
vec_95per_removed_5per_short

vec_94per_removed_6per_short<-g.count_site(site_lh_94per_short,m=60)
# Out of the 60 sites removed, how many sites were in the position of 801-1000?
vec_94per_removed_6per_short

vec_93per_removed_7per_short<-g.count_site(site_lh_93per_short,m=70)
# Out of the 70 sites removed, how many sites were in the position of 801-1000?
vec_93per_removed_7per_short

vec_92per_removed_8per_short<-g.count_site(site_lh_92per_short,m=80)
# Out of the 80 sites removed, how many sites were in the position of 801-1000?
vec_92per_removed_8per_short

vec_91per_removed_9per_short<-g.count_site(site_lh_91per_short,m=90)
# Out of the 90 sites removed, how many sites were in the position of 801-1000?
vec_91per_removed_9per_short

vec_90per_removed_10per_short<-g.count_site(site_lh_90per_short,m=100)
# Out of the 100 sites removed, how many sites were in the position of 801-1000?
vec_90per_removed_10per_short

vec_89per_removed_11per_short<-g.count_site(site_lh_89per_short,m=110)
# Out of the 110 sites removed, how many sites were in the position of 801-1000?
vec_89per_removed_11per_short

vec_88per_removed_12per_short<-g.count_site(site_lh_88per_short,m=120)
# Out of the 120 sites removed, how many sites were in the position of 801-1000?
vec_88per_removed_12per_short


vec_87per_removed_13per_short<-g.count_site(site_lh_87per_short,m=130)
# Out of the 130 sites removed, how many sites were in the position of 801-1000?
vec_87per_removed_13per_short

vec_86per_removed_14per_short<-g.count_site(site_lh_86per_short,m=140)
# Out of the 140 sites removed, how many sites were in the position of 801-1000?
vec_86per_removed_14per_short

vec_85per_removed_15per_short<-g.count_site(site_lh_85per_short,m=150)
# Out of the 150 sites removed, how many sites were in the position of 801-1000?
vec_85per_removed_15per_short

vec_84per_removed_16per_short<-g.count_site(site_lh_84per_short,m=160)
# Out of the 160 sites removed, how many sites were in the position of 801-1000?
vec_84per_removed_16per_short

vec_83per_removed_17per_short<-g.count_site(site_lh_83per_short,m=170)
# Out of the 170 sites removed, how many sites were in the position of 801-1000?
vec_83per_removed_17per_short

vec_82per_removed_18per_short<-g.count_site(site_lh_82per_short,m=180)
# Out of the 180 sites removed, how many sites were in the position of 801-1000?
vec_82per_removed_18per_short

vec_81per_removed_19per_short<-g.count_site(site_lh_81per_short,m=190)
# Out of the 190 sites removed, how many sites were in the position of 801-1000?
vec_81per_removed_19per_short

vec_80per_removed_20per_short<-g.count_site(site_lh_80per_short,m=200)
# Out of the 200 sites removed, how many sites were in the position of 801-1000?
vec_80per_removed_20per_short
##################################
# combine

df_removed_short<-cbind(vec_99per_removed_1per_short,
                  vec_98per_removed_2per_short,
                  vec_97per_removed_3per_short,
                  vec_96per_removed_4per_short,
                  vec_95per_removed_5per_short,
                  vec_94per_removed_6per_short,
                  vec_93per_removed_7per_short,
                  vec_92per_removed_8per_short,
                  vec_91per_removed_9per_short,
                  vec_90per_removed_10per_short,
                  vec_89per_removed_11per_short,
                  vec_88per_removed_12per_short,
                  vec_87per_removed_13per_short,
                  vec_86per_removed_14per_short,
                  vec_85per_removed_15per_short,
                  vec_84per_removed_16per_short,
                  vec_83per_removed_17per_short,
                  vec_82per_removed_18per_short,
                  vec_81per_removed_19per_short,
                  vec_80per_removed_20per_short)

colnames(df_removed_short)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                        "removed_5per","removed_6per","removed_7per","removed_8per",
                        "removed_9per","removed_10per","removed_11per","removed_12per",
                        "removed_13per","removed_14per","removed_15per","removed_16per",
                        "removed_17per","removed_18per","removed_19per","removed_20per")

df_mean_removed_short<-round(colMeans(df_removed_short),digits=4)

mean(df_removed_short[,1])

df_mean_removed_short<-as.data.frame(df_mean_removed_short)
is.data.frame(df_mean_removed_short)


rownames(df_mean_removed_short)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                             "removed_5per","removed_6per","removed_7per","removed_8per",
                             "removed_9per","removed_10per","removed_11per","removed_12per",
                             "removed_13per","removed_14per","removed_15per","removed_16per",
                             "removed_17per","removed_18per","removed_19per","removed_20per")
colnames(df_mean_removed_short)<-"Mean_Num_sites_In800To1000_removed"


df_mean_removed_short

for (i in 1:nrow(df_mean_removed_short)){
  df_mean_removed_short$proption[i]<-round(df_mean_removed_short$Mean_Num_sites_In800To1000_removed[i]/(i*10),2)
}

df_mean_removed_short

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(df_removed_short,df_mean_removed_short, file="info_site_removed_short.rdata")


# Plot proportion of sites removed.
plot(df_mean_removed_short$proption, main = "Proportion of sites in the positions of 800-1000 removed (Short)",
     ylab = "Proportion", xlab = "% Site (positions 800-1000) Removed", xaxt = "n",
     ylim = c(min(df_mean_removed_short$proption), max(df_mean_removed_short$proption)),
     cex.lab = 1.6, cex.main = 2, cex.axis = 1.5, pch = 19, col =  "blue", cex = 2)
axis(1, cex = 1.2, at = 1:21, labels = c("0%", "1%", "2%", "3%", "4%", "5%", "6%", "7%", "8%",
                                         "9%", "10%", "11%", "12%", "13%", "14%", "15%", "16%", "17%",
                                         "18%", "19%", "20%"))
#################################################################################################################################
##############################################################################################################################
# Medium
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-medium")
# Now read in the inferred trees.
dirfile_tree<-c("./100-per-results",
                "./99-per-results", "./98-per-results",
                "./97-per-results", "./96-per-results",
                "./95-per-results", "./94-per-results",
                "./93-per-results","./92-per-results",
                "./91-per-results", "./90-per-results",
                "./89-per-results", "./88-per-results",
                "./87-per-results", "./86-per-results",
                "./85-per-results", "./84-per-results",
                "./83-per-results","./82-per-results",
                "./81-per-results", "./80-per-results")

tree_RP_medium<-g.read_tree(dirfile_tree)


tree_100per_medium<-tree_RP_medium[[1]]
tree_99per_medium<-tree_RP_medium[[2]]
tree_98per_medium<-tree_RP_medium[[3]]
tree_97per_medium<-tree_RP_medium[[4]]
tree_96per_medium<-tree_RP_medium[[5]]
tree_95per_medium<-tree_RP_medium[[6]]
tree_94per_medium<-tree_RP_medium[[7]]
tree_93per_medium<-tree_RP_medium[[8]]
tree_92per_medium<-tree_RP_medium[[9]]
tree_91per_medium<-tree_RP_medium[[10]]
tree_90per_medium<-tree_RP_medium[[11]]
tree_89per_medium<-tree_RP_medium[[12]]
tree_88per_medium<-tree_RP_medium[[13]]
tree_87per_medium<-tree_RP_medium[[14]]
tree_86per_medium<-tree_RP_medium[[15]]
tree_85per_medium<-tree_RP_medium[[16]]
tree_84per_medium<-tree_RP_medium[[17]]
tree_83per_medium<-tree_RP_medium[[18]]
tree_82per_medium<-tree_RP_medium[[19]]
tree_81per_medium<-tree_RP_medium[[20]]
tree_80per_medium<-tree_RP_medium[[21]]

#check,correct
cat(write.tree(tree_80per_medium[[1]]))
##################
# Read in true tree
###########################
############################
# Read in the true trees
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-medium")
dirfile_tree<-c("./trees")

tree_true_medium<-g.read_tree_tre(dirfile_tree)


tree_true_list_medium<-tree_true_medium[[1]]


cat(write.tree(tree_true_list_medium[[9]]))

##################################
##################################
# Look at these sequences
# How many unique sites and hoa many sites are constant sites?
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-medium/sequence")

list_fst<-dir(pattern = "*.fst")

n=400
list_seq_medium<-list()
vec_const_medium<-rep(0,n)
vec_unqsite_medium<-rep(0,n)
for (i in 1:n){
  list_seq_medium[[i]]<-read.dna(list_fst[i])
  list_seq_medium[[i]]<-as.phyDat(list_seq_medium[[i]])
  seq1_pattern<-g.sitepattern_df(list_seq_medium[[i]])
  seq1_pattern$freq<-as.numeric(as.character(seq1_pattern$freq))
  
  vec_const_medium[i]<- sum(seq1_pattern$freq[1:4])
  vec_unqsite_medium[i]<-length(seq1_pattern$freq)
}


hist(vec_const_medium, main = "Number of constant sites for the simulated sequences",
     xlab = "Number of constant sites")

hist(vec_unqsite_medium, main = "Number of unique sites for the simulated sequences",
     xlab = "Number of unique sites")


setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-medium")

save(vec_const_medium,vec_unqsite_medium,list_seq_medium,
     file="seq_information_medium.rData")
###############################################################
################
################

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/")

save(tree_100per_medium,
     tree_99per_medium,tree_98per_medium,
     tree_97per_medium,tree_96per_medium,
     tree_95per_medium,tree_94per_medium,
     tree_93per_medium,tree_92per_medium,
     tree_91per_medium,tree_90per_medium,
     tree_89per_medium,tree_88per_medium,
     tree_87per_medium,tree_86per_medium,
     tree_85per_medium,tree_84per_medium,
     tree_83per_medium,tree_82per_medium,
     tree_81per_medium,tree_80per_medium,
     tree_true_list_medium,tree_RP_medium,
     file="tree_medium.Rdata")
######################################
######################################
# compare topologies and branch scores
is.rooted(tree_100per_medium[[1]])
is.rooted(tree_true_list_medium[[1]])


dist_ph85_topo_medium<-PH85_topo(tree_true_list_medium,tree_RP_medium)

dist_ph85_100per_medium<-dist_ph85_topo_medium[[1]]
dist_ph85_99per_medium<-dist_ph85_topo_medium[[2]]
dist_ph85_98per_medium<-dist_ph85_topo_medium[[3]]
dist_ph85_97per_medium<-dist_ph85_topo_medium[[4]]
dist_ph85_96per_medium<-dist_ph85_topo_medium[[5]]
dist_ph85_95per_medium<-dist_ph85_topo_medium[[6]]
dist_ph85_94per_medium<-dist_ph85_topo_medium[[7]]
dist_ph85_93per_medium<-dist_ph85_topo_medium[[8]]
dist_ph85_92per_medium<-dist_ph85_topo_medium[[9]]
dist_ph85_91per_medium<-dist_ph85_topo_medium[[10]]
dist_ph85_90per_medium<-dist_ph85_topo_medium[[11]]
dist_ph85_89per_medium<-dist_ph85_topo_medium[[12]]
dist_ph85_88per_medium<-dist_ph85_topo_medium[[13]]
dist_ph85_87per_medium<-dist_ph85_topo_medium[[14]]
dist_ph85_86per_medium<-dist_ph85_topo_medium[[15]]
dist_ph85_85per_medium<-dist_ph85_topo_medium[[16]]
dist_ph85_84per_medium<-dist_ph85_topo_medium[[17]]
dist_ph85_83per_medium<-dist_ph85_topo_medium[[18]]
dist_ph85_82per_medium<-dist_ph85_topo_medium[[19]]
dist_ph85_81per_medium<-dist_ph85_topo_medium[[20]]
dist_ph85_80per_medium<-dist_ph85_topo_medium[[21]]

######################################
# branch error


BranchError_topo_medium<-KF_BE(tree_true_list_medium,tree_RP_medium)

BranchError_100per_medium<-BranchError_topo_medium[[1]]
BranchError_99per_medium<-BranchError_topo_medium[[2]]
BranchError_98per_medium<-BranchError_topo_medium[[3]]
BranchError_97per_medium<-BranchError_topo_medium[[4]]
BranchError_96per_medium<-BranchError_topo_medium[[5]]
BranchError_95per_medium<-BranchError_topo_medium[[6]]
BranchError_94per_medium<-BranchError_topo_medium[[7]]
BranchError_93per_medium<-BranchError_topo_medium[[8]]
BranchError_92per_medium<-BranchError_topo_medium[[9]]
BranchError_91per_medium<-BranchError_topo_medium[[10]]
BranchError_90per_medium<-BranchError_topo_medium[[11]]
BranchError_89per_medium<-BranchError_topo_medium[[12]]
BranchError_88per_medium<-BranchError_topo_medium[[13]]
BranchError_87per_medium<-BranchError_topo_medium[[14]]
BranchError_86per_medium<-BranchError_topo_medium[[15]]
BranchError_85per_medium<-BranchError_topo_medium[[16]]
BranchError_84per_medium<-BranchError_topo_medium[[17]]
BranchError_83per_medium<-BranchError_topo_medium[[18]]
BranchError_82per_medium<-BranchError_topo_medium[[19]]
BranchError_81per_medium<-BranchError_topo_medium[[20]]
BranchError_80per_medium<-BranchError_topo_medium[[21]]
# save
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")
save(dist_ph85_100per_medium,
     dist_ph85_99per_medium,
     dist_ph85_98per_medium,
     dist_ph85_97per_medium,
     dist_ph85_96per_medium,
     dist_ph85_95per_medium,
     dist_ph85_94per_medium,
     dist_ph85_93per_medium,
     dist_ph85_92per_medium,
     dist_ph85_91per_medium,
     dist_ph85_90per_medium,
     dist_ph85_89per_medium,
     dist_ph85_88per_medium,
     dist_ph85_87per_medium,
     dist_ph85_86per_medium,
     dist_ph85_85per_medium,
     dist_ph85_84per_medium,
     dist_ph85_83per_medium,
     dist_ph85_82per_medium,
     dist_ph85_81per_medium,
     dist_ph85_80per_medium,
     BranchError_100per_medium,
     BranchError_99per_medium,
     BranchError_98per_medium,
     BranchError_97per_medium,
     BranchError_96per_medium,
     BranchError_95per_medium,
     BranchError_94per_medium,
     BranchError_93per_medium,
     BranchError_92per_medium,
     BranchError_91per_medium,
     BranchError_90per_medium,
     BranchError_89per_medium,
     BranchError_88per_medium,
     BranchError_87per_medium,
     BranchError_86per_medium,
     BranchError_85per_medium,
     BranchError_84per_medium,
     BranchError_83per_medium,
     BranchError_82per_medium,
     BranchError_81per_medium,
     BranchError_80per_medium,
     file="BE_PH85_medium.Rdata")
########################################################################
#######################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")
load("tree_medium.Rdata.Rdata")
load("BE_PH85_medium.Rdata.Rdata")
# Now calculate the average branch error and RF distances for each per.

avg_PH85_100per_medium<-mean(dist_ph85_100per_medium)
avg_PH85_99per_medium<-mean(dist_ph85_99per_medium)
avg_PH85_98per_medium<-mean(dist_ph85_98per_medium)
avg_PH85_97per_medium<-mean(dist_ph85_97per_medium)
avg_PH85_96per_medium<-mean(dist_ph85_96per_medium)
avg_PH85_95per_medium<-mean(dist_ph85_95per_medium)
avg_PH85_94per_medium<-mean(dist_ph85_94per_medium)
avg_PH85_93per_medium<-mean(dist_ph85_93per_medium)
avg_PH85_92per_medium<-mean(dist_ph85_92per_medium)
avg_PH85_91per_medium<-mean(dist_ph85_91per_medium)
avg_PH85_90per_medium<-mean(dist_ph85_90per_medium)
avg_PH85_89per_medium<-mean(dist_ph85_89per_medium)
avg_PH85_88per_medium<-mean(dist_ph85_88per_medium)
avg_PH85_87per_medium<-mean(dist_ph85_87per_medium)
avg_PH85_86per_medium<-mean(dist_ph85_86per_medium)
avg_PH85_85per_medium<-mean(dist_ph85_85per_medium)
avg_PH85_84per_medium<-mean(dist_ph85_84per_medium)
avg_PH85_83per_medium<-mean(dist_ph85_83per_medium)
avg_PH85_82per_medium<-mean(dist_ph85_82per_medium)
avg_PH85_81per_medium<-mean(dist_ph85_81per_medium)
avg_PH85_80per_medium<-mean(dist_ph85_80per_medium)

df_PH85_medium<-rbind(avg_PH85_100per_medium,
                      avg_PH85_99per_medium,
                      avg_PH85_98per_medium,
                      avg_PH85_97per_medium,
                      avg_PH85_96per_medium,
                      avg_PH85_95per_medium,
                      avg_PH85_94per_medium,
                      avg_PH85_93per_medium,
                      avg_PH85_92per_medium,
                      avg_PH85_91per_medium,
                      avg_PH85_90per_medium,
                      avg_PH85_89per_medium,
                      avg_PH85_88per_medium,
                      avg_PH85_87per_medium,
                      avg_PH85_86per_medium,
                      avg_PH85_85per_medium,
                      avg_PH85_84per_medium,
                      avg_PH85_83per_medium,
                      avg_PH85_82per_medium,
                      avg_PH85_81per_medium,
                      avg_PH85_80per_medium)
df_PH85_medium<-as.data.frame(df_PH85_medium)
colnames(df_PH85_medium)<-"Avg_PH85"
df_PH85_medium

##
# branch error
avg_BE_100per_medium<-mean(BranchError_100per_medium)
avg_BE_99per_medium<-mean(BranchError_99per_medium)
avg_BE_98per_medium<-mean(BranchError_98per_medium)
avg_BE_97per_medium<-mean(BranchError_97per_medium)
avg_BE_96per_medium<-mean(BranchError_96per_medium)
avg_BE_95per_medium<-mean(BranchError_95per_medium)
avg_BE_94per_medium<-mean(BranchError_94per_medium)
avg_BE_93per_medium<-mean(BranchError_93per_medium)
avg_BE_92per_medium<-mean(BranchError_92per_medium)
avg_BE_91per_medium<-mean(BranchError_91per_medium)
avg_BE_90per_medium<-mean(BranchError_90per_medium)
avg_BE_89per_medium<-mean(BranchError_89per_medium)
avg_BE_88per_medium<-mean(BranchError_88per_medium)
avg_BE_87per_medium<-mean(BranchError_87per_medium)
avg_BE_86per_medium<-mean(BranchError_86per_medium)
avg_BE_85per_medium<-mean(BranchError_85per_medium)
avg_BE_84per_medium<-mean(BranchError_84per_medium)
avg_BE_83per_medium<-mean(BranchError_83per_medium)
avg_BE_82per_medium<-mean(BranchError_82per_medium)
avg_BE_81per_medium<-mean(BranchError_81per_medium)
avg_BE_80per_medium<-mean(BranchError_80per_medium)

df_BE_medium<-rbind(avg_BE_100per_medium,
                    avg_BE_99per_medium,
                    avg_BE_98per_medium,
                    avg_BE_97per_medium,
                    avg_BE_96per_medium,
                    avg_BE_95per_medium,
                    avg_BE_94per_medium,
                    avg_BE_93per_medium,
                    avg_BE_92per_medium,
                    avg_BE_91per_medium,
                    avg_BE_90per_medium,
                    avg_BE_89per_medium,
                    avg_BE_88per_medium,
                    avg_BE_87per_medium,
                    avg_BE_86per_medium,
                    avg_BE_85per_medium,
                    avg_BE_84per_medium,
                    avg_BE_83per_medium,
                    avg_BE_82per_medium,
                    avg_BE_81per_medium,
                    avg_BE_80per_medium)

df_BE_medium<-as.data.frame(df_BE_medium)
colnames(df_BE_medium)<-"Avg_BE"
df_BE_medium
##########
# Plot the average scores


library(ggplot2)
# Assuming df_PH85 is your data frame
df_PH85_modify_medium <- data.frame(
  Category = as.character(0:20),
  Average_Score = as.numeric(df_PH85_medium$Avg_PH85)
)

custom_levels <- as.character(0:20)

# Convert Category to a factor with custom levels
df_PH85_modify_medium$Category <- factor(df_PH85_modify_medium$Category, levels = custom_levels)



# Plotting using ggplot

ggplot(data = df_PH85_modify_medium, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  theme_bw() +
  labs(title = "Average RF Scores", y = "Average RF Score", x = "% of site removed") +
  scale_x_discrete(labels = paste0(df_PH85_modify_medium$Category, "%"))




# Assuming df_BE is your data frame
df_BE_modify_medium <- data.frame(
  Category = as.character(0:20),
  Average_Score = as.numeric(df_BE_medium$Avg_BE)
)
custom_levels <- as.character(0:20)

# Convert Category to a factor with custom levels
df_BE_modify_medium$Category <- factor(df_BE_modify_medium$Category, levels = custom_levels)
# Create a point plot using ggplot2 with custom x-axis labels
ggplot(df_BE_modify_medium, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  labs(title = "Average Branch Error Scores", y = "Average BE Score", x = "% of site removed") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ylim(min(df_BE_modify_medium$Average_Score) - 0.001, max(df_BE_modify_medium$Average_Score) + 0.001) +
  scale_x_discrete(labels = paste0(df_BE_modify_medium$Category, "%"))
################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(df_PH85_modify_medium,df_BE_modify_medium, file ="figure_medium.rdata")
#####################################################################################
# Now let's see what proportion of sites (or how many of the bottom 200 sites) from the bottom 200 
# sites were removed for each analysis.

#################
# Now put it together.

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-medium/all_tree_sitelh_txt")
dirfile_sitelh<-c("./100-sitelh",
                  "./99-sitelh", "./98-sitelh",
                  "./97-sitelh", "./96-sitelh",
                  "./95-sitelh", "./94-sitelh",
                  "./93-sitelh","./92-sitelh",
                  "./91-sitelh", "./90-sitelh",
                  "./89-sitelh", "./88-sitelh",
                  "./87-sitelh", "./86-sitelh",
                  "./85-sitelh", "./84-sitelh",
                  "./83-sitelh","./82-sitelh",
                  "./81-sitelh", "./80-sitelh")

# g.read_tree and g.read_tree_tre are very similar.
# g.read_tree reads the .treefile while g.read_tree_tre reads the .tre files

sitelh_list_medium<-g.read_sitelh_txt(dirfile_sitelh)
length(sitelh_list_medium)

################################################################################
# There are 100 txt file storing in 100per list.
site_lh_100per_medium<-sitelh_list_medium[[1]]
site_lh_99per_medium<-sitelh_list_medium[[2]]
site_lh_98per_medium<-sitelh_list_medium[[3]]
site_lh_97per_medium<-sitelh_list_medium[[4]]
site_lh_96per_medium<-sitelh_list_medium[[5]]
site_lh_95per_medium<-sitelh_list_medium[[6]]
site_lh_94per_medium<-sitelh_list_medium[[7]]
site_lh_93per_medium<-sitelh_list_medium[[8]]
site_lh_92per_medium<-sitelh_list_medium[[9]]
site_lh_91per_medium<-sitelh_list_medium[[10]]
site_lh_90per_medium<-sitelh_list_medium[[11]]
site_lh_89per_medium<-sitelh_list_medium[[12]]
site_lh_88per_medium<-sitelh_list_medium[[13]]
site_lh_87per_medium<-sitelh_list_medium[[14]]
site_lh_86per_medium<-sitelh_list_medium[[15]]
site_lh_85per_medium<-sitelh_list_medium[[16]]
site_lh_84per_medium<-sitelh_list_medium[[17]]
site_lh_83per_medium<-sitelh_list_medium[[18]]
site_lh_82per_medium<-sitelh_list_medium[[19]]
site_lh_81per_medium<-sitelh_list_medium[[20]]
site_lh_80per_medium<-sitelh_list_medium[[21]]


###################################
vec_99per_removed_1per_medium<-g.count_site(site_lh_99per_medium,m=10)
# Out of the 10 sites removed, how many sites were in the position of 800-1000?
vec_99per_removed_1per_medium

vec_98per_removed_2per_medium<-g.count_site(site_lh_98per_medium,m=20)
# Out of the 20 sites removed, how many sites were in the position of 800-1000?
vec_98per_removed_2per_medium

vec_97per_removed_3per_medium<-g.count_site(site_lh_97per_medium,m=30)
# Out of the 30 sites removed, how many sites were in the position of 800-1000?
vec_97per_removed_3per_medium

vec_96per_removed_4per_medium<-g.count_site(site_lh_96per_medium,m=40)
# Out of the 40 sites removed, how many sites were in the position of 800-1000?
vec_96per_removed_4per_medium

vec_95per_removed_5per_medium<-g.count_site(site_lh_95per_medium,m=50)
# Out of the 50 sites removed, how many sites were in the position of 800-1000?
vec_95per_removed_5per_medium

vec_94per_removed_6per_medium<-g.count_site(site_lh_94per_medium,m=60)
# Out of the 60 sites removed, how many sites were in the position of 800-1000?
vec_94per_removed_6per_medium

vec_93per_removed_7per_medium<-g.count_site(site_lh_93per_medium,m=70)
# Out of the 70 sites removed, how many sites were in the position of 800-1000?
vec_93per_removed_7per_medium

vec_92per_removed_8per_medium<-g.count_site(site_lh_92per_medium,m=80)
# Out of the 80 sites removed, how many sites were in the position of 800-1000?
vec_92per_removed_8per_medium

vec_91per_removed_9per_medium<-g.count_site(site_lh_91per_medium,m=90)
# Out of the 90 sites removed, how many sites were in the position of 800-1000?
vec_91per_removed_9per_medium

vec_90per_removed_10per_medium<-g.count_site(site_lh_90per_medium,m=100)
# Out of the 100 sites removed, how many sites were in the position of 800-1000?
vec_90per_removed_10per_medium

vec_89per_removed_11per_medium<-g.count_site(site_lh_89per_medium,m=110)
# Out of the 110 sites removed, how many sites were in the position of 800-1000?
vec_89per_removed_11per_medium

vec_88per_removed_12per_medium<-g.count_site(site_lh_88per_medium,m=120)
# Out of the 120 sites removed, how many sites were in the position of 800-1000?
vec_88per_removed_12per_medium


vec_87per_removed_13per_medium<-g.count_site(site_lh_87per_medium,m=130)
# Out of the 130 sites removed, how many sites were in the position of 800-1000?
vec_87per_removed_13per_medium

vec_86per_removed_14per_medium<-g.count_site(site_lh_86per_medium,m=140)
# Out of the 140 sites removed, how many sites were in the position of 800-1000?
vec_86per_removed_14per_medium

vec_85per_removed_15per_medium<-g.count_site(site_lh_85per_medium,m=150)
# Out of the 150 sites removed, how many sites were in the position of 800-1000?
vec_85per_removed_15per_medium

vec_84per_removed_16per_medium<-g.count_site(site_lh_84per_medium,m=160)
# Out of the 160 sites removed, how many sites were in the position of 800-1000?
vec_84per_removed_16per_medium

vec_83per_removed_17per_medium<-g.count_site(site_lh_83per_medium,m=170)
# Out of the 170 sites removed, how many sites were in the position of 800-1000?
vec_83per_removed_17per_medium

vec_82per_removed_18per_medium<-g.count_site(site_lh_82per_medium,m=180)
# Out of the 180 sites removed, how many sites were in the position of 800-1000?
vec_82per_removed_18per_medium

vec_81per_removed_19per_medium<-g.count_site(site_lh_81per_medium,m=190)
# Out of the 190 sites removed, how many sites were in the position of 800-1000?
vec_81per_removed_19per_medium

vec_80per_removed_20per_medium<-g.count_site(site_lh_80per_medium,m=200)
# Out of the 200 sites removed, how many sites were in the position of 800-1000?
vec_80per_removed_20per_medium
##################################
# combine

df_removed_medium<-cbind(vec_99per_removed_1per_medium,
                         vec_98per_removed_2per_medium,
                         vec_97per_removed_3per_medium,
                         vec_96per_removed_4per_medium,
                         vec_95per_removed_5per_medium,
                         vec_94per_removed_6per_medium,
                         vec_93per_removed_7per_medium,
                         vec_92per_removed_8per_medium,
                         vec_91per_removed_9per_medium,
                         vec_90per_removed_10per_medium,
                         vec_89per_removed_11per_medium,
                         vec_88per_removed_12per_medium,
                         vec_87per_removed_13per_medium,
                         vec_86per_removed_14per_medium,
                         vec_85per_removed_15per_medium,
                         vec_84per_removed_16per_medium,
                         vec_83per_removed_17per_medium,
                         vec_82per_removed_18per_medium,
                         vec_81per_removed_19per_medium,
                         vec_80per_removed_20per_medium)

colnames(df_removed_medium)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                               "removed_5per","removed_6per","removed_7per","removed_8per",
                               "removed_9per","removed_10per","removed_11per","removed_12per",
                               "removed_13per","removed_14per","removed_15per","removed_16per",
                               "removed_17per","removed_18per","removed_19per","removed_20per")

df_mean_removed_medium<-round(colMeans(df_removed_medium),digits=4)

df_mean_removed_medium<-as.data.frame(df_mean_removed_medium)
is.data.frame(df_mean_removed_medium)


rownames(df_mean_removed_medium)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                                    "removed_5per","removed_6per","removed_7per","removed_8per",
                                    "removed_9per","removed_10per","removed_11per","removed_12per",
                                    "removed_13per","removed_14per","removed_15per","removed_16per",
                                    "removed_17per","removed_18per","removed_19per","removed_20per")
colnames(df_mean_removed_medium)<-"Mean_Num_sites_In800To1000_removed"


df_mean_removed_medium

for (i in 1:nrow(df_mean_removed_medium)){
  df_mean_removed_medium$proption[i]<-round(df_mean_removed_medium$Mean_Num_sites_In800To1000_removed[i]/(i*10),2)
}

df_mean_removed_medium

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(df_removed_medium,df_mean_removed_medium, file="info_site_removed_medium.rdata")

# Plot proportion of sites removed.
plot(df_mean_removed_medium$proption, main = "Proportion of sites in the positions of 800-1000 removed (medium)",
     ylab = "Proportion", xlab = "% Site (positions 800-1000) Removed", xaxt = "n",
     ylim = c(min(df_mean_removed_medium$proption), max(df_mean_removed_medium$proption)),
     cex.lab = 1.6, cex.main = 2, cex.axis = 1.5, pch = 19, col =  "blue", cex = 2)
axis(1, cex = 1.2, at = 1:21, labels = c("0%", "1%", "2%", "3%", "4%", "5%", "6%", "7%", "8%",
                                         "9%", "10%", "11%", "12%", "13%", "14%", "15%", "16%", "17%",
                                         "18%", "19%", "20%"))

#################################################################################################################################
##############################################################################################################################
# long
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-long")
# Now read in the inferred trees.
dirfile_tree<-c("./100-per-results",
                "./99-per-results", "./98-per-results",
                "./97-per-results", "./96-per-results",
                "./95-per-results", "./94-per-results",
                "./93-per-results","./92-per-results",
                "./91-per-results", "./90-per-results",
                "./89-per-results", "./88-per-results",
                "./87-per-results", "./86-per-results",
                "./85-per-results", "./84-per-results",
                "./83-per-results","./82-per-results",
                "./81-per-results", "./80-per-results")

tree_RP_long<-g.read_tree(dirfile_tree)


tree_100per_long<-tree_RP_long[[1]]
tree_99per_long<-tree_RP_long[[2]]
tree_98per_long<-tree_RP_long[[3]]
tree_97per_long<-tree_RP_long[[4]]
tree_96per_long<-tree_RP_long[[5]]
tree_95per_long<-tree_RP_long[[6]]
tree_94per_long<-tree_RP_long[[7]]
tree_93per_long<-tree_RP_long[[8]]
tree_92per_long<-tree_RP_long[[9]]
tree_91per_long<-tree_RP_long[[10]]
tree_90per_long<-tree_RP_long[[11]]
tree_89per_long<-tree_RP_long[[12]]
tree_88per_long<-tree_RP_long[[13]]
tree_87per_long<-tree_RP_long[[14]]
tree_86per_long<-tree_RP_long[[15]]
tree_85per_long<-tree_RP_long[[16]]
tree_84per_long<-tree_RP_long[[17]]
tree_83per_long<-tree_RP_long[[18]]
tree_82per_long<-tree_RP_long[[19]]
tree_81per_long<-tree_RP_long[[20]]
tree_80per_long<-tree_RP_long[[21]]

#check,correct
cat(write.tree(tree_80per_long[[1]]))
##################
# Read in true tree
###########################
############################
# Read in the true trees
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-long")

dirfile_tree<-c("./trees")

tree_true_long<-g.read_tree_tre(dirfile_tree)


tree_true_list_long<-tree_true_long[[1]]


cat(write.tree(tree_true_list_long[[9]]))

##################################
##################################
# Look at these sequences
# How many unique sites and hoa many sites are constant sites?
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-long/sequence")


list_fst<-dir(pattern = "*.fst")

n=400
list_seq_long<-list()
vec_const_long<-rep(0,n)
vec_unqsite_long<-rep(0,n)
for (i in 1:n){
  list_seq_long[[i]]<-read.dna(list_fst[i])
  list_seq_long[[i]]<-as.phyDat(list_seq_long[[i]])
  seq1_pattern<-g.sitepattern_df(list_seq_long[[i]])
  seq1_pattern$freq<-as.numeric(as.character(seq1_pattern$freq))
  
  vec_const_long[i]<- sum(seq1_pattern$freq[1:4])
  vec_unqsite_long[i]<-length(seq1_pattern$freq)
}


hist(vec_const_long, main = "Number of constant sites for the simulated sequences",
     xlab = "Number of constant sites")

hist(vec_unqsite_long, main = "Number of unique sites for the simulated sequences",
     xlab = "Number of unique sites")


setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-long/")
save(vec_const_long,vec_unqsite_long,list_seq_long,
     file="seq_information_long.rData")
###############################################################
################
################

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(tree_100per_long,
     tree_99per_long,tree_98per_long,
     tree_97per_long,tree_96per_long,
     tree_95per_long,tree_94per_long,
     tree_93per_long,tree_92per_long,
     tree_91per_long,tree_90per_long,
     tree_89per_long,tree_88per_long,
     tree_87per_long,tree_86per_long,
     tree_85per_long,tree_84per_long,
     tree_83per_long,tree_82per_long,
     tree_81per_long,tree_80per_long,
     tree_true_list_long,tree_RP_long,
     file="tree_long.Rdata")
######################################
######################################
# compare topologies and branch scores
is.rooted(tree_100per_long[[1]])
is.rooted(tree_true_list_long[[1]])


dist_ph85_topo_long<-PH85_topo(tree_true_list_long,tree_RP_long)

dist_ph85_100per_long<-dist_ph85_topo_long[[1]]
dist_ph85_99per_long<-dist_ph85_topo_long[[2]]
dist_ph85_98per_long<-dist_ph85_topo_long[[3]]
dist_ph85_97per_long<-dist_ph85_topo_long[[4]]
dist_ph85_96per_long<-dist_ph85_topo_long[[5]]
dist_ph85_95per_long<-dist_ph85_topo_long[[6]]
dist_ph85_94per_long<-dist_ph85_topo_long[[7]]
dist_ph85_93per_long<-dist_ph85_topo_long[[8]]
dist_ph85_92per_long<-dist_ph85_topo_long[[9]]
dist_ph85_91per_long<-dist_ph85_topo_long[[10]]
dist_ph85_90per_long<-dist_ph85_topo_long[[11]]
dist_ph85_89per_long<-dist_ph85_topo_long[[12]]
dist_ph85_88per_long<-dist_ph85_topo_long[[13]]
dist_ph85_87per_long<-dist_ph85_topo_long[[14]]
dist_ph85_86per_long<-dist_ph85_topo_long[[15]]
dist_ph85_85per_long<-dist_ph85_topo_long[[16]]
dist_ph85_84per_long<-dist_ph85_topo_long[[17]]
dist_ph85_83per_long<-dist_ph85_topo_long[[18]]
dist_ph85_82per_long<-dist_ph85_topo_long[[19]]
dist_ph85_81per_long<-dist_ph85_topo_long[[20]]
dist_ph85_80per_long<-dist_ph85_topo_long[[21]]

######################################
# branch error


BranchError_topo_long<-KF_BE(tree_true_list_long,tree_RP_long)

BranchError_100per_long<-BranchError_topo_long[[1]]
BranchError_99per_long<-BranchError_topo_long[[2]]
BranchError_98per_long<-BranchError_topo_long[[3]]
BranchError_97per_long<-BranchError_topo_long[[4]]
BranchError_96per_long<-BranchError_topo_long[[5]]
BranchError_95per_long<-BranchError_topo_long[[6]]
BranchError_94per_long<-BranchError_topo_long[[7]]
BranchError_93per_long<-BranchError_topo_long[[8]]
BranchError_92per_long<-BranchError_topo_long[[9]]
BranchError_91per_long<-BranchError_topo_long[[10]]
BranchError_90per_long<-BranchError_topo_long[[11]]
BranchError_89per_long<-BranchError_topo_long[[12]]
BranchError_88per_long<-BranchError_topo_long[[13]]
BranchError_87per_long<-BranchError_topo_long[[14]]
BranchError_86per_long<-BranchError_topo_long[[15]]
BranchError_85per_long<-BranchError_topo_long[[16]]
BranchError_84per_long<-BranchError_topo_long[[17]]
BranchError_83per_long<-BranchError_topo_long[[18]]
BranchError_82per_long<-BranchError_topo_long[[19]]
BranchError_81per_long<-BranchError_topo_long[[20]]
BranchError_80per_long<-BranchError_topo_long[[21]]
# save
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(dist_ph85_100per_long,
     dist_ph85_99per_long,
     dist_ph85_98per_long,
     dist_ph85_97per_long,
     dist_ph85_96per_long,
     dist_ph85_95per_long,
     dist_ph85_94per_long,
     dist_ph85_93per_long,
     dist_ph85_92per_long,
     dist_ph85_91per_long,
     dist_ph85_90per_long,
     dist_ph85_89per_long,
     dist_ph85_88per_long,
     dist_ph85_87per_long,
     dist_ph85_86per_long,
     dist_ph85_85per_long,
     dist_ph85_84per_long,
     dist_ph85_83per_long,
     dist_ph85_82per_long,
     dist_ph85_81per_long,
     dist_ph85_80per_long,
     BranchError_100per_long,
     BranchError_99per_long,
     BranchError_98per_long,
     BranchError_97per_long,
     BranchError_96per_long,
     BranchError_95per_long,
     BranchError_94per_long,
     BranchError_93per_long,
     BranchError_92per_long,
     BranchError_91per_long,
     BranchError_90per_long,
     BranchError_89per_long,
     BranchError_88per_long,
     BranchError_87per_long,
     BranchError_86per_long,
     BranchError_85per_long,
     BranchError_84per_long,
     BranchError_83per_long,
     BranchError_82per_long,
     BranchError_81per_long,
     BranchError_80per_long,
     file="BE_PH85_long.Rdata")
########################################################################
#######################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

load("tree_long.Rdata.Rdata")
load("BE_PH85_long.Rdata.Rdata")
# Now calculate the average branch error and RF distances for each per.

avg_PH85_100per_long<-mean(dist_ph85_100per_long)
avg_PH85_99per_long<-mean(dist_ph85_99per_long)
avg_PH85_98per_long<-mean(dist_ph85_98per_long)
avg_PH85_97per_long<-mean(dist_ph85_97per_long)
avg_PH85_96per_long<-mean(dist_ph85_96per_long)
avg_PH85_95per_long<-mean(dist_ph85_95per_long)
avg_PH85_94per_long<-mean(dist_ph85_94per_long)
avg_PH85_93per_long<-mean(dist_ph85_93per_long)
avg_PH85_92per_long<-mean(dist_ph85_92per_long)
avg_PH85_91per_long<-mean(dist_ph85_91per_long)
avg_PH85_90per_long<-mean(dist_ph85_90per_long)
avg_PH85_89per_long<-mean(dist_ph85_89per_long)
avg_PH85_88per_long<-mean(dist_ph85_88per_long)
avg_PH85_87per_long<-mean(dist_ph85_87per_long)
avg_PH85_86per_long<-mean(dist_ph85_86per_long)
avg_PH85_85per_long<-mean(dist_ph85_85per_long)
avg_PH85_84per_long<-mean(dist_ph85_84per_long)
avg_PH85_83per_long<-mean(dist_ph85_83per_long)
avg_PH85_82per_long<-mean(dist_ph85_82per_long)
avg_PH85_81per_long<-mean(dist_ph85_81per_long)
avg_PH85_80per_long<-mean(dist_ph85_80per_long)

df_PH85_long<-rbind(avg_PH85_100per_long,
                    avg_PH85_99per_long,
                    avg_PH85_98per_long,
                    avg_PH85_97per_long,
                    avg_PH85_96per_long,
                    avg_PH85_95per_long,
                    avg_PH85_94per_long,
                    avg_PH85_93per_long,
                    avg_PH85_92per_long,
                    avg_PH85_91per_long,
                    avg_PH85_90per_long,
                    avg_PH85_89per_long,
                    avg_PH85_88per_long,
                    avg_PH85_87per_long,
                    avg_PH85_86per_long,
                    avg_PH85_85per_long,
                    avg_PH85_84per_long,
                    avg_PH85_83per_long,
                    avg_PH85_82per_long,
                    avg_PH85_81per_long,
                    avg_PH85_80per_long)
df_PH85_long<-as.data.frame(df_PH85_long)
colnames(df_PH85_long)<-"Avg_PH85"
df_PH85_long

##
# branch error
avg_BE_100per_long<-mean(BranchError_100per_long)
avg_BE_99per_long<-mean(BranchError_99per_long)
avg_BE_98per_long<-mean(BranchError_98per_long)
avg_BE_97per_long<-mean(BranchError_97per_long)
avg_BE_96per_long<-mean(BranchError_96per_long)
avg_BE_95per_long<-mean(BranchError_95per_long)
avg_BE_94per_long<-mean(BranchError_94per_long)
avg_BE_93per_long<-mean(BranchError_93per_long)
avg_BE_92per_long<-mean(BranchError_92per_long)
avg_BE_91per_long<-mean(BranchError_91per_long)
avg_BE_90per_long<-mean(BranchError_90per_long)
avg_BE_89per_long<-mean(BranchError_89per_long)
avg_BE_88per_long<-mean(BranchError_88per_long)
avg_BE_87per_long<-mean(BranchError_87per_long)
avg_BE_86per_long<-mean(BranchError_86per_long)
avg_BE_85per_long<-mean(BranchError_85per_long)
avg_BE_84per_long<-mean(BranchError_84per_long)
avg_BE_83per_long<-mean(BranchError_83per_long)
avg_BE_82per_long<-mean(BranchError_82per_long)
avg_BE_81per_long<-mean(BranchError_81per_long)
avg_BE_80per_long<-mean(BranchError_80per_long)

df_BE_long<-rbind(avg_BE_100per_long,
                  avg_BE_99per_long,
                  avg_BE_98per_long,
                  avg_BE_97per_long,
                  avg_BE_96per_long,
                  avg_BE_95per_long,
                  avg_BE_94per_long,
                  avg_BE_93per_long,
                  avg_BE_92per_long,
                  avg_BE_91per_long,
                  avg_BE_90per_long,
                  avg_BE_89per_long,
                  avg_BE_88per_long,
                  avg_BE_87per_long,
                  avg_BE_86per_long,
                  avg_BE_85per_long,
                  avg_BE_84per_long,
                  avg_BE_83per_long,
                  avg_BE_82per_long,
                  avg_BE_81per_long,
                  avg_BE_80per_long)

df_BE_long<-as.data.frame(df_BE_long)
colnames(df_BE_long)<-"Avg_BE"
df_BE_long
##########
# Plot the average scores


library(ggplot2)
# Assuming df_PH85 is your data frame
df_PH85_modify_long <- data.frame(
  Category = as.character(0:20),
  Average_Score = as.numeric(df_PH85_long$Avg_PH85)
)

custom_levels <- as.character(0:20)

# Convert Category to a factor with custom levels
df_PH85_modify_long$Category <- factor(df_PH85_modify_long$Category, levels = custom_levels)



# Plotting using ggplot

ggplot(data = df_PH85_modify_long, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  theme_bw() +
  labs(title = "Average RF Scores", y = "Average RF Score", x = "% of site removed") +
  scale_x_discrete(labels = paste0(df_PH85_modify_long$Category, "%"))




# Assuming df_BE is your data frame
df_BE_modify_long <- data.frame(
  Category = as.character(0:20),
  Average_Score = as.numeric(df_BE_long$Avg_BE)
)
custom_levels <- as.character(0:20)

# Convert Category to a factor with custom levels
df_BE_modify_long$Category <- factor(df_BE_modify_long$Category, levels = custom_levels)
# Create a point plot using ggplot2 with custom x-axis labels
ggplot(df_BE_modify_long, aes(x = Category, y = Average_Score)) +
  geom_point(color = "blue", size = 3) +
  labs(title = "Average Branch Error Scores", y = "Average BE Score", x = "% of site removed") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ylim(min(df_BE_modify_long$Average_Score) - 0.001, max(df_BE_modify_long$Average_Score) + 0.001) +
  scale_x_discrete(labels = paste0(df_BE_modify_long$Category, "%"))
################

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(df_PH85_modify_long,df_BE_modify_long, file ="figure_long.rdata")
#####################################################################################
# Now let's see what proportion of sites (or how many of the bottom 200 sites) from the bottom 200 
# sites were removed for each analysis.

#################
# Now put it together.

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-long/all_tree_sitelh_txt")
dirfile_sitelh<-c("./100-sitelh",
                  "./99-sitelh", "./98-sitelh",
                  "./97-sitelh", "./96-sitelh",
                  "./95-sitelh", "./94-sitelh",
                  "./93-sitelh","./92-sitelh",
                  "./91-sitelh", "./90-sitelh",
                  "./89-sitelh", "./88-sitelh",
                  "./87-sitelh", "./86-sitelh",
                  "./85-sitelh", "./84-sitelh",
                  "./83-sitelh","./82-sitelh",
                  "./81-sitelh", "./80-sitelh")

# g.read_tree and g.read_tree_tre are very similar.
# g.read_tree reads the .treefile while g.read_tree_tre reads the .tre files

sitelh_list_long<-g.read_sitelh_txt(dirfile_sitelh)
length(sitelh_list_long)

################################################################################
# There are 100 txt file storing in 100per list.
site_lh_100per_long<-sitelh_list_long[[1]]
site_lh_99per_long<-sitelh_list_long[[2]]
site_lh_98per_long<-sitelh_list_long[[3]]
site_lh_97per_long<-sitelh_list_long[[4]]
site_lh_96per_long<-sitelh_list_long[[5]]
site_lh_95per_long<-sitelh_list_long[[6]]
site_lh_94per_long<-sitelh_list_long[[7]]
site_lh_93per_long<-sitelh_list_long[[8]]
site_lh_92per_long<-sitelh_list_long[[9]]
site_lh_91per_long<-sitelh_list_long[[10]]
site_lh_90per_long<-sitelh_list_long[[11]]
site_lh_89per_long<-sitelh_list_long[[12]]
site_lh_88per_long<-sitelh_list_long[[13]]
site_lh_87per_long<-sitelh_list_long[[14]]
site_lh_86per_long<-sitelh_list_long[[15]]
site_lh_85per_long<-sitelh_list_long[[16]]
site_lh_84per_long<-sitelh_list_long[[17]]
site_lh_83per_long<-sitelh_list_long[[18]]
site_lh_82per_long<-sitelh_list_long[[19]]
site_lh_81per_long<-sitelh_list_long[[20]]
site_lh_80per_long<-sitelh_list_long[[21]]


###################################
vec_99per_removed_1per_long<-g.count_site(site_lh_99per_long,m=10)
# Out of the 10 sites removed, how many sites were in the position of 800-1000?
vec_99per_removed_1per_long

vec_98per_removed_2per_long<-g.count_site(site_lh_98per_long,m=20)
# Out of the 20 sites removed, how many sites were in the position of 800-1000?
vec_98per_removed_2per_long

vec_97per_removed_3per_long<-g.count_site(site_lh_97per_long,m=30)
# Out of the 30 sites removed, how many sites were in the position of 800-1000?
vec_97per_removed_3per_long

vec_96per_removed_4per_long<-g.count_site(site_lh_96per_long,m=40)
# Out of the 40 sites removed, how many sites were in the position of 800-1000?
vec_96per_removed_4per_long

vec_95per_removed_5per_long<-g.count_site(site_lh_95per_long,m=50)
# Out of the 50 sites removed, how many sites were in the position of 800-1000?
vec_95per_removed_5per_long

vec_94per_removed_6per_long<-g.count_site(site_lh_94per_long,m=60)
# Out of the 60 sites removed, how many sites were in the position of 800-1000?
vec_94per_removed_6per_long

vec_93per_removed_7per_long<-g.count_site(site_lh_93per_long,m=70)
# Out of the 70 sites removed, how many sites were in the position of 800-1000?
vec_93per_removed_7per_long

vec_92per_removed_8per_long<-g.count_site(site_lh_92per_long,m=80)
# Out of the 80 sites removed, how many sites were in the position of 800-1000?
vec_92per_removed_8per_long

vec_91per_removed_9per_long<-g.count_site(site_lh_91per_long,m=90)
# Out of the 90 sites removed, how many sites were in the position of 800-1000?
vec_91per_removed_9per_long

vec_90per_removed_10per_long<-g.count_site(site_lh_90per_long,m=100)
# Out of the 100 sites removed, how many sites were in the position of 800-1000?
vec_90per_removed_10per_long

vec_89per_removed_11per_long<-g.count_site(site_lh_89per_long,m=110)
# Out of the 110 sites removed, how many sites were in the position of 800-1000?
vec_89per_removed_11per_long

vec_88per_removed_12per_long<-g.count_site(site_lh_88per_long,m=120)
# Out of the 120 sites removed, how many sites were in the position of 800-1000?
vec_88per_removed_12per_long


vec_87per_removed_13per_long<-g.count_site(site_lh_87per_long,m=130)
# Out of the 130 sites removed, how many sites were in the position of 800-1000?
vec_87per_removed_13per_long

vec_86per_removed_14per_long<-g.count_site(site_lh_86per_long,m=140)
# Out of the 140 sites removed, how many sites were in the position of 800-1000?
vec_86per_removed_14per_long

vec_85per_removed_15per_long<-g.count_site(site_lh_85per_long,m=150)
# Out of the 150 sites removed, how many sites were in the position of 800-1000?
vec_85per_removed_15per_long

vec_84per_removed_16per_long<-g.count_site(site_lh_84per_long,m=160)
# Out of the 160 sites removed, how many sites were in the position of 800-1000?
vec_84per_removed_16per_long

vec_83per_removed_17per_long<-g.count_site(site_lh_83per_long,m=170)
# Out of the 170 sites removed, how many sites were in the position of 800-1000?
vec_83per_removed_17per_long

vec_82per_removed_18per_long<-g.count_site(site_lh_82per_long,m=180)
# Out of the 180 sites removed, how many sites were in the position of 800-1000?
vec_82per_removed_18per_long

vec_81per_removed_19per_long<-g.count_site(site_lh_81per_long,m=190)
# Out of the 190 sites removed, how many sites were in the position of 800-1000?
vec_81per_removed_19per_long

vec_80per_removed_20per_long<-g.count_site(site_lh_80per_long,m=200)
# Out of the 200 sites removed, how many sites were in the position of 800-1000?
vec_80per_removed_20per_long
##################################
# combine

df_removed_long<-cbind(vec_99per_removed_1per_long,
                       vec_98per_removed_2per_long,
                       vec_97per_removed_3per_long,
                       vec_96per_removed_4per_long,
                       vec_95per_removed_5per_long,
                       vec_94per_removed_6per_long,
                       vec_93per_removed_7per_long,
                       vec_92per_removed_8per_long,
                       vec_91per_removed_9per_long,
                       vec_90per_removed_10per_long,
                       vec_89per_removed_11per_long,
                       vec_88per_removed_12per_long,
                       vec_87per_removed_13per_long,
                       vec_86per_removed_14per_long,
                       vec_85per_removed_15per_long,
                       vec_84per_removed_16per_long,
                       vec_83per_removed_17per_long,
                       vec_82per_removed_18per_long,
                       vec_81per_removed_19per_long,
                       vec_80per_removed_20per_long)

colnames(df_removed_long)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                             "removed_5per","removed_6per","removed_7per","removed_8per",
                             "removed_9per","removed_10per","removed_11per","removed_12per",
                             "removed_13per","removed_14per","removed_15per","removed_16per",
                             "removed_17per","removed_18per","removed_19per","removed_20per")

df_mean_removed_long<-round(colMeans(df_removed_long),digits=4)

df_mean_removed_long<-as.data.frame(df_mean_removed_long)
is.data.frame(df_mean_removed_long)


rownames(df_mean_removed_long)<-c("removed_1per","removed_2per","removed_3per","removed_4per",
                                  "removed_5per","removed_6per","removed_7per","removed_8per",
                                  "removed_9per","removed_10per","removed_11per","removed_12per",
                                  "removed_13per","removed_14per","removed_15per","removed_16per",
                                  "removed_17per","removed_18per","removed_19per","removed_20per")
colnames(df_mean_removed_long)<-"Mean_Num_sites_In800To1000_removed"


df_mean_removed_long

for (i in 1:nrow(df_mean_removed_long)){
  df_mean_removed_long$proption[i]<-round(df_mean_removed_long$Mean_Num_sites_In800To1000_removed[i]/(i*10),2)
}

df_mean_removed_long

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(df_removed_long,df_mean_removed_long, file="info_site_removed_long.rdata")

# Plot proportion of sites removed.
plot(df_mean_removed_long$proption, main = "Proportion of sites in the positions of 800-1000 removed (long)",
     ylab = "Proportion", xlab = "% Site (positions 800-1000) Removed", xaxt = "n",
     ylim = c(min(df_mean_removed_long$proption), max(df_mean_removed_long$proption)),
     cex.lab = 1.6, cex.main = 2, cex.axis = 1.5, pch = 19, col =  "blue", cex = 2)
axis(1, cex = 1.2, at = 1:21, labels = c("0%", "1%", "2%", "3%", "4%", "5%", "6%", "7%", "8%",
                                         "9%", "10%", "11%", "12%", "13%", "14%", "15%", "16%", "17%",
                                         "18%", "19%", "20%"))
################################################################################################
#####################################################################################################
# test significant
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

load("BE_PH85_short.Rdata")
load("BE_PH85_medium.Rdata")
load("BE_PH85_long.Rdata")

df_RF_short<-rbind(dist_ph85_100per_short,
                      dist_ph85_99per_short,
                      dist_ph85_98per_short,
                      dist_ph85_97per_short,
                      dist_ph85_96per_short,
                      dist_ph85_95per_short,
                      dist_ph85_94per_short,
                      dist_ph85_93per_short,
                      dist_ph85_92per_short,
                      dist_ph85_91per_short,
                      dist_ph85_90per_short,
                      dist_ph85_89per_short,
                      dist_ph85_88per_short,
                      dist_ph85_87per_short,
                      dist_ph85_86per_short,
                      dist_ph85_85per_short,
                      dist_ph85_84per_short,
                      dist_ph85_83per_short,
                      dist_ph85_82per_short,
                      dist_ph85_81per_short,
                      dist_ph85_80per_short)


df_BE_short<-rbind(BranchError_100per_short,
                      BranchError_99per_short,
                      BranchError_98per_short,
                      BranchError_97per_short,
                      BranchError_96per_short,
                      BranchError_95per_short,
                      BranchError_94per_short,
                      BranchError_93per_short,
                      BranchError_92per_short,
                      BranchError_91per_short,
                      BranchError_90per_short,
                      BranchError_89per_short,
                      BranchError_88per_short,
                      BranchError_87per_short,
                      BranchError_86per_short,
                      BranchError_85per_short,
                      BranchError_84per_short,
                      BranchError_83per_short,
                      BranchError_82per_short,
                      BranchError_81per_short,
                      BranchError_80per_short)



#setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

#save(df_RF_500sites, file ="df_RF_ANOVA_500sites.Rdata")

# Perform t-test
#t_test_result <- t.test(dist_ph85_tree_9taxa_100per, dist_ph85_tree_9taxa_91per)

# Print the results
#print(t_test_result)

# Load necessary libraries
library(tidyr)
library(dplyr)
# Assuming df_RF_500sites is a matrix
df_RF_short <- as.data.frame(t(df_RF_short))
str(df_RF_short)

# Now you can apply pivot_longer
df_long <- df_RF_short %>%
  pivot_longer(cols = everything(), names_to = "group", values_to = "value")



# Perform ANOVA
anova_result <- aov(value ~ group, data = df_long)

# Summary of the ANOVA results
summary(anova_result)
t.test(dist_ph85_93per_short,dist_ph85_100per_short)
t.test(dist_ph85_90per_short,dist_ph85_100per_short)

t.test(dist_ph85_95per_medium,dist_ph85_100per_medium)
t.test(dist_ph85_87per_medium,dist_ph85_100per_medium)

t.test(dist_ph85_85per_long,dist_ph85_100per_long)
t.test(dist_ph85_82per_long,dist_ph85_100per_long)

t.test(BranchError_83per_long,BranchError_100per_long)
t.test(BranchError_92per_medium,BranchError_100per_medium)
t.test(BranchError_95per_short,BranchError_100per_short)

table(dist_ph85_93per_short)
table(dist_ph85_100per_short)

table(dist_ph85_95per_medium)
table(dist_ph85_100per_medium)

table(dist_ph85_83per_long)
table(dist_ph85_100per_long)
