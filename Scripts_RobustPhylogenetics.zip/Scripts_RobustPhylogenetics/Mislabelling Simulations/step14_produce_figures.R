# This script is to produce figures using the short, medium, and long branch length simulations data.

# load data.

rm(list = ls())
library(ape)
library(phangorn)
library(stringr) # need to use this library for the "g.sitepattern_df" function.
library(ggplot2)

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")


load("figure_short.rdata")
load("figure_medium.rdata")
load("figure_long.rdata")
load("BE_PH85_short.Rdata")
load("BE_PH85_medium.Rdata")
load("BE_PH85_long.Rdata")


############
# Produce RF figure
#library(dplyr)


combined_PH85 <- rbind(
  transform(df_PH85_modify_short, Type = "Short"),
  transform(df_PH85_modify_medium, Type = "Medium"),
  transform(df_PH85_modify_long, Type = "Long")
)


# Combine the data frames
combined_BE <- rbind(
  transform(df_BE_modify_short, Type = "Short"),
  transform(df_BE_modify_medium, Type = "Medium"),
  transform(df_BE_modify_long, Type = "Long")
)


ggplot(data = combined_PH85, aes(x = Category, y = Average_Score, color = Type, shape = Type)) +
  geom_point(size = 6) +
  theme_bw() +
  labs(title = "Average RF Score", y = "Average RF Score", x = "% of site removed") +
  scale_x_discrete(labels = combined_PH85$Category) +
  scale_color_manual(values = c("Short" = "#0072B2", "Medium" = "#E69F00", "Long" = "#CC79A7")) +  # Set colors for each Type
  scale_shape_manual(values = c(18, 16, 17)) +  # Shape values as needed
  theme(
    text = element_text(size = 16),  # Adjust the overall text size
    axis.text.x = element_text(size = 16),  # Adjust x-axis text size
    axis.text.y = element_text(size = 16),  # Adjust y-axis text size
    axis.title.x = element_text(size = 25),  # Adjust x-axis title size
    axis.title.y = element_text(size = 25),  # Adjust y-axis title size
    plot.title = element_text(size = 30),  # Adjust plot title size
    plot.margin = margin(10, 10, 10, 10),
    panel.grid.major = element_line(size = 0.5, color = "grey"),  # Major grid lines
    panel.grid.minor = element_blank()  # Remove minor grid lines
  ) +
  coord_fixed(ratio = 15)  # Adjust the aspect ratio to make the plot "skinnier"


ggplot(data = combined_BE, aes(x = Category, y = Average_Score, color = Type, shape = Type)) +
  geom_point(size = 6) +
  theme_bw() +
  labs(title = "Average BE Scores", y = "Average BE Score", x = "% of site removed") +
  scale_x_discrete(labels = combined_BE$Category) +
  scale_color_manual(values = c("Short" = "#0072B2", "Medium" = "#E69F00", "Long" = "#CC79A7")) +  # Set colors for each Type
  scale_shape_manual(values = c(18, 16, 17)) +  # Shape values as needed
  theme(
    text = element_text(size = 16),  # Adjust the overall text size
    axis.text.x = element_text(size = 16),  # Adjust x-axis text size
    axis.text.y = element_text(size = 16),  # Adjust y-axis text size
    axis.title.x = element_text(size = 25),  # Adjust x-axis title size
    axis.title.y = element_text(size = 25),  # Adjust y-axis title size
    plot.title = element_text(size = 30),  # Adjust plot title size
    plot.margin = margin(10, 10, 10, 10),
    panel.grid.major = element_line(size = 0.5, color = "grey"),  # Major grid lines
    panel.grid.minor = element_blank()  # Remove minor grid lines
  ) +
  coord_fixed(ratio = 55)  # Adjust the aspect ratio to make the plot "skinnier"

#######################

ggplot(data = combined_PH85, aes(x = Category, y = Average_Score)) +
  geom_point(aes(color = Type), size = 4.5) +
  theme_bw() +
  labs(title = "Average RF Scores", y = "Average RF Score", x = "% of site removed") +
  scale_x_discrete(labels = combined_PH85$Category) +  
  facet_wrap(~Type, scales = "fixed") +  # Change to "fixed" to keep the same y-axis scale
  theme(
    text = element_text(size = 20),  # Adjust the overall text size
    axis.text.x = element_text(size = 12),  # Adjust x-axis text size
    axis.text.y = element_text(size = 15),  # Adjust y-axis text size
    axis.title.x = element_text(size = 25),  # Adjust x-axis title size
    axis.title.y = element_text(size = 25),  # Adjust y-axis title size
    plot.title = element_text(size = 30),  # Adjust plot title size
    legend.position = "none"  
  )+
  ylim(0, NA) 


ggplot(data = combined_BE, aes(x = Category, y = Average_Score)) +
  geom_point(aes(color = Type), size = 4.5) +
  theme_bw() +
  labs(title = "Average BE Scores", y = "Average BE Score", x = "% of site removed") +
  scale_x_discrete(labels = combined_BE$Category) +  
  facet_wrap(~Type, scales = "free_y")+
  theme(
    text = element_text(size = 20),  # Adjust the overall text size
    axis.text.x = element_text(size = 12),  # Adjust x-axis text size
    axis.text.y = element_text(size = 15),  # Adjust y-axis text size
    axis.title.x = element_text(size = 25),  # Adjust x-axis title size
    axis.title.y = element_text(size = 25),  # Adjust y-axis title size
    plot.title = element_text(size = 30)  # Adjust plot title size
  ) +
  guides(color = FALSE)  # Remove legend


ggplot(data = combined_BE, aes(x = Category, y = Average_Score)) +
  geom_point(aes(color = Type), size = 4.5) +
  theme_bw() +
  labs(title = "Average BE Scores", y = "Average BE Score", x = "% of site removed") +
  scale_x_discrete(labels = combined_BE$Category) +  
  facet_wrap(~Type, scales = "fixed")+
  theme(
    text = element_text(size = 20),  # Adjust the overall text size
    axis.text.x = element_text(size = 12),  # Adjust x-axis text size
    axis.text.y = element_text(size = 15),  # Adjust y-axis text size
    axis.title.x = element_text(size = 25),  # Adjust x-axis title size
    axis.title.y = element_text(size = 25),  # Adjust y-axis title size
    plot.title = element_text(size = 30)  # Adjust plot title size
  ) +
  guides(color = FALSE)  # Remove legend
###############################################################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

load("info_site_removed_short.rdata")
load("info_site_removed_medium.rdata")
load("info_site_removed_long.rdata")
df_removed_long
df_removed_medium
df_removed_short

df_mean_removed_short
df_mean_removed_short$remove_total<-c(10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200)
prop_removed_mislabel_short<-df_mean_removed_short[,1]/200
prop_removed_nonmislabel_short<-((df_mean_removed_short[,3]-df_mean_removed_short[,1])/800)

rr_short<-prop_removed_mislabel_short/prop_removed_nonmislabel_short


# Load the necessary library
library(ggplot2)

# Create a data frame with the vectors
proportion_short <- data.frame(
  sites_removed = seq_along(prop_removed_mislabel_short),  # Sequence for x-axis
  mislabel = prop_removed_mislabel_short,
  non_mislabel = prop_removed_nonmislabel_short
)

# Convert data to long format for ggplot
proportion_short_longdf <- reshape2::melt(proportion_short, id.vars = "sites_removed", 
                            variable.name = "Group", value.name = "Proportion")



#####################################################################
df_mean_removed_medium
df_mean_removed_medium$remove_total<-c(10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200)
prop_removed_mislabel_medium<-df_mean_removed_medium[,1]/200
prop_removed_nonmislabel_medium<-((df_mean_removed_medium[,3]-df_mean_removed_medium[,1])/800)

rr_medium<-prop_removed_mislabel_medium/prop_removed_nonmislabel_medium


# Create a data frame with the vectors
proportion_medium <- data.frame(
  sites_removed = seq_along(prop_removed_mislabel_medium),  # Sequence for x-axis
  mislabel = prop_removed_mislabel_medium,
  non_mislabel = prop_removed_nonmislabel_medium
)

# Convert data to long format for ggplot
proportion_medium_longdf <- reshape2::melt(proportion_medium, id.vars = "sites_removed", 
                                          variable.name = "Group", value.name = "Proportion")

###########################################################
#####################################################################
df_mean_removed_long
df_mean_removed_long$remove_total<-c(10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200)
prop_removed_mislabel_long<-df_mean_removed_long[,1]/200
prop_removed_nonmislabel_long<-((df_mean_removed_long[,3]-df_mean_removed_long[,1])/800)

rr_long<-prop_removed_mislabel_long/prop_removed_nonmislabel_long


# Create a data frame with the vectors
proportion_long <- data.frame(
  sites_removed = seq_along(prop_removed_mislabel_long),  # Sequence for x-axis
  mislabel = prop_removed_mislabel_long,
  non_mislabel = prop_removed_nonmislabel_long
)

# Convert data to long format for ggplot
proportion_long_longdf <- reshape2::melt(proportion_long, id.vars = "sites_removed", 
                                           variable.name = "Group", value.name = "Proportion")

# ###########################################################

library(dplyr)  # For data manipulation

# Add a 'Type' column to each dataframe
data_rr_short <- data_rr_short %>% mutate(Type = "Short")
data_rr_medium <- data_rr_medium %>% mutate(Type = "Medium")
data_rr_long <- data_rr_long %>% mutate(Type = "Long")

# Combine the dataframes
combined_rr <- bind_rows(data_rr_short, data_rr_medium, data_rr_long)


ggplot(combined_rr, aes(x = Sites_Removed, y = Relative_Risk, color = Type, linetype = Type, shape = Type)) +
  geom_line(size = 1.2) +
  geom_point(size = 4) +
  labs(title = "Relative Risk of Removed Sites by Type",
       x = "Number of Sites Removed",
       y = "Relative Risk") +
  scale_x_continuous(breaks = 1:20) +  # Set breaks from 1 to 20
  scale_y_continuous(limits = c(1, NA)) +  # Start y-axis at 1
  scale_shape_manual(values = c(1,5, 17)) +
  scale_linetype_manual(values = c("Short" = "dotted", "Medium" = "dashed", "Long" = "solid")) +
  scale_color_manual(values = c("Short" = "#0072B2", "Medium" =  "#CC79A7", "Long" ="#E69F00")) +  # Set colors for each Type
  theme_bw() +  # Black and white theme
  theme(
    text = element_text(size = 16),  # Adjust the overall text size
    axis.text.x = element_text(size = 16),  # Adjust x-axis text size
    axis.text.y = element_text(size = 16),  # Adjust y-axis text size
    axis.title.x = element_text(size = 25),  # Adjust x-axis title size
    axis.title.y = element_text(size = 25),  # Adjust y-axis title size
    plot.title = element_blank(),  # Adjust plot title size
    plot.margin = margin(10, 10, 10, 10),  # Adjust plot margins
    panel.grid.major = element_line(size = 0.5, color = "grey"),  # Major grid lines
    panel.grid.minor = element_blank(),  # Remove minor grid lines
    legend.position = c(0.8, 0.8),       # Position the legend inside the plot (values between 0 and 1)
    legend.justification = c(1, 1),      # Ensure the legend is aligned properly (right-top corner of legend box)
    legend.direction = "horizontal"
  )


##############################################
proportion_short_longdf
proportion_medium_longdf
proportion_long_longdf

# Add a Type column to each dataframe
proportion_short_longdf$Type <- "Short"
proportion_medium_longdf$Type <- "Medium"
proportion_long_longdf$Type <- "Long"

library(dplyr)

# Combine the three data frames into one
combined_df <- bind_rows(
  proportion_short_longdf %>% mutate(Type = "Short"),
  proportion_medium_longdf %>% mutate(Type = "Medium"),
  proportion_long_longdf %>% mutate(Type = "Long")
)

# Plot
ggplot(combined_df, aes(x = sites_removed, y = Proportion, color = Group)) +
  geom_line(size = 1.2) +
  facet_wrap(~ Type) +
  labs(title = "Proportion of Mislabeled vs Non-Mislabeled Sites by Type",
       x = "Number of Sites Removed",
       y = "Proportion") +
  theme_minimal() +
  theme(
    text = element_text(size = 16),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    plot.title = element_text(size = 24)
  )
#############################################################################################
# sd
mean(dist_ph85_100per_short)
sd(dist_ph85_100per_short)

mean(dist_ph85_99per_short)
sd(dist_ph85_99per_short)

mean(dist_ph85_98per_short)
sd(dist_ph85_98per_short)

mean(dist_ph85_97per_short)
sd(dist_ph85_97per_short)

mean(dist_ph85_96per_short)
sd(dist_ph85_96per_short)

mean(dist_ph85_95per_short)
sd(dist_ph85_95per_short)

mean(dist_ph85_94per_short)
sd(dist_ph85_94per_short)

mean(dist_ph85_93per_short)
sd(dist_ph85_93per_short)

mean(dist_ph85_92per_short)
sd(dist_ph85_92per_short)

mean(dist_ph85_91per_short)
sd(dist_ph85_91per_short)

mean(dist_ph85_90per_short)
sd(dist_ph85_90per_short)


mean(dist_ph85_89per_short)
sd(dist_ph85_89per_short)

mean(dist_ph85_88per_short)
sd(dist_ph85_88per_short)

mean(dist_ph85_87per_short)
sd(dist_ph85_87per_short)

mean(dist_ph85_86per_short)
sd(dist_ph85_86per_short)

mean(dist_ph85_85per_short)
sd(dist_ph85_85per_short)

mean(dist_ph85_84per_short)
sd(dist_ph85_84per_short)

mean(dist_ph85_83per_short)
sd(dist_ph85_83per_short)

mean(dist_ph85_82per_short)
sd(dist_ph85_82per_short)

mean(dist_ph85_81per_short)
sd(dist_ph85_81per_short)

mean(dist_ph85_80per_short)
sd(dist_ph85_80per_short)
########################################
vectors_list_short<-list(
                    dist_ph85_100per_short,
                    dist_ph85_99per_short,
                    dist_ph85_98per_short,
                    dist_ph85_97per_short,
                    dist_ph85_96per_short,
                    dist_ph85_95per_short,
                    dist_ph85_94per_short,
                    dist_ph85_93per_short,
                    dist_ph85_92per_short,
                    dist_ph85_91per_short,
                    dist_ph85_90per_short,
                    dist_ph85_89per_short,
                    dist_ph85_88per_short,
                    dist_ph85_87per_short,
                    dist_ph85_86per_short,
                    dist_ph85_85per_short,
                    dist_ph85_84per_short,
                    dist_ph85_83per_short,
                    dist_ph85_82per_short,
                    dist_ph85_81per_short,
                    dist_ph85_80per_short)
means_short<-sapply(vectors_list_short,mean)
sds_short<-sapply(vectors_list_short,sd)


x_values <-seq(0,20,length.out=length(vectors_list_short))

n_values<-400
se_short <- sds_short / sqrt(n_values)

########################################
vectors_list_medium<-list(
  dist_ph85_100per_medium,
  dist_ph85_99per_medium,
  dist_ph85_98per_medium,
  dist_ph85_97per_medium,
  dist_ph85_96per_medium,
  dist_ph85_95per_medium,
  dist_ph85_94per_medium,
  dist_ph85_93per_medium,
  dist_ph85_92per_medium,
  dist_ph85_91per_medium,
  dist_ph85_90per_medium,
  dist_ph85_89per_medium,
  dist_ph85_88per_medium,
  dist_ph85_87per_medium,
  dist_ph85_86per_medium,
  dist_ph85_85per_medium,
  dist_ph85_84per_medium,
  dist_ph85_83per_medium,
  dist_ph85_82per_medium,
  dist_ph85_81per_medium,
  dist_ph85_80per_medium)
means_medium<-sapply(vectors_list_medium,mean)
sds_medium<-sapply(vectors_list_medium,sd)



x_values <-seq(0,20,length.out=length(vectors_list_medium))
#n_values<-400
se_medium <- sds_medium / sqrt(n_values)



########################################
vectors_list_long<-list(
  dist_ph85_100per_long,
  dist_ph85_99per_long,
  dist_ph85_98per_long,
  dist_ph85_97per_long,
  dist_ph85_96per_long,
  dist_ph85_95per_long,
  dist_ph85_94per_long,
  dist_ph85_93per_long,
  dist_ph85_92per_long,
  dist_ph85_91per_long,
  dist_ph85_90per_long,
  dist_ph85_89per_long,
  dist_ph85_88per_long,
  dist_ph85_87per_long,
  dist_ph85_86per_long,
  dist_ph85_85per_long,
  dist_ph85_84per_long,
  dist_ph85_83per_long,
  dist_ph85_82per_long,
  dist_ph85_81per_long,
  dist_ph85_80per_long)
means_long<-sapply(vectors_list_long,mean)
sds_long<-sapply(vectors_list_long,sd)
x_values <-seq(0,20,length.out=length(vectors_list_long))
#n_values<-400
se_long <- sds_long / sqrt(n_values)




################################################
# branch error
############
# Short
vectors_branchError_list_short<-list(
  BranchError_100per_short,
  BranchError_99per_short,
  BranchError_98per_short,
  BranchError_97per_short,
  BranchError_96per_short,
  BranchError_95per_short,
  BranchError_94per_short,
  BranchError_93per_short,
  BranchError_92per_short,
  BranchError_91per_short,
  BranchError_90per_short,
  BranchError_89per_short,
  BranchError_88per_short,
  BranchError_87per_short,
  BranchError_86per_short,
  BranchError_85per_short,
  BranchError_84per_short,
  BranchError_83per_short,
  BranchError_82per_short,
  BranchError_81per_short,
  BranchError_80per_short)
means_short_branchError<-sapply(vectors_branchError_list_short,mean)
sds_short_branchError<-sapply(vectors_branchError_list_short,sd)


x_values <-seq(0,20,length.out=length(sds_short_branchError))

n_values<-400
se_short_branchError <- sds_short_branchError / sqrt(n_values)


############
# Medium
vectors_branchError_list_medium<-list(
  BranchError_100per_medium,
  BranchError_99per_medium,
  BranchError_98per_medium,
  BranchError_97per_medium,
  BranchError_96per_medium,
  BranchError_95per_medium,
  BranchError_94per_medium,
  BranchError_93per_medium,
  BranchError_92per_medium,
  BranchError_91per_medium,
  BranchError_90per_medium,
  BranchError_89per_medium,
  BranchError_88per_medium,
  BranchError_87per_medium,
  BranchError_86per_medium,
  BranchError_85per_medium,
  BranchError_84per_medium,
  BranchError_83per_medium,
  BranchError_82per_medium,
  BranchError_81per_medium,
  BranchError_80per_medium)
means_medium_branchError<-sapply(vectors_branchError_list_medium,mean)
sds_medium_branchError<-sapply(vectors_branchError_list_medium,sd)


x_values <-seq(0,20,length.out=length(sds_medium_branchError))

#n_values<-400
se_medium_branchError <- sds_medium_branchError / sqrt(n_values)



############
# long
vectors_branchError_list_long<-list(
  BranchError_100per_long,
  BranchError_99per_long,
  BranchError_98per_long,
  BranchError_97per_long,
  BranchError_96per_long,
  BranchError_95per_long,
  BranchError_94per_long,
  BranchError_93per_long,
  BranchError_92per_long,
  BranchError_91per_long,
  BranchError_90per_long,
  BranchError_89per_long,
  BranchError_88per_long,
  BranchError_87per_long,
  BranchError_86per_long,
  BranchError_85per_long,
  BranchError_84per_long,
  BranchError_83per_long,
  BranchError_82per_long,
  BranchError_81per_long,
  BranchError_80per_long)
means_long_branchError<-sapply(vectors_branchError_list_long,mean)
sds_long_branchError<-sapply(vectors_branchError_list_long,sd)


x_values <-seq(0,20,length.out=length(sds_long_branchError))

#n_values<-400
se_long_branchError <- sds_long_branchError / sqrt(n_values)





########################################################
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(x_values,means_long,se_long,
     means_medium,se_medium,
     means_short,se_short,
     means_short_branchError,se_short_branchError,
     means_medium_branchError,se_medium_branchError,
     means_long_branchError, se_long_branchError,
     file = "RFBranchError_MeanSE_figures.Rdata"
)
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

load("RFBranchError_MeanSE_figures.Rdata")
#############################################################
# Figures


library(ggplot2)

# Data frames for plotting
df_short <- data.frame(x_values = x_values, means = means_short, se = se_short)
df_medium <- data.frame(x_values = x_values, means = means_medium, se = se_medium)
df_long <- data.frame(x_values = x_values, means = means_long, se = se_long)


###############################
# combined

library(dplyr)

# Add a category column to each dataframe
df_short$category <- "short"
df_medium$category <- "medium"
df_long$category <- "long"

# Combine the dataframes into one
df_combined <- bind_rows(df_short, df_medium, df_long)

# Data frame for plotting with means and SE for each simulation type
df_RF <- data.frame(
  x_values = rep(x_values, 3),
  means = c(means_short, means_medium, means_long),
  se = c(se_short, se_medium, se_long),
  simulation = factor(rep(c("Short", "Medium", "Long"), each = length(x_values)))
)

ggplot(df_RF, aes(x = x_values, y = means, color = simulation, shape = simulation)) +
  geom_point(size = 4) +  # Points with different shapes, same size as df_branchError
  geom_line(aes(linetype = simulation), linewidth = 0.8) +  # Thinner lines with different line types for each category
  geom_errorbar(aes(ymin = means - se, ymax = means + se, color = simulation),  # Ensure error bars use the same color as the points and lines
                width = 0.3, linewidth = 1) +  # Error bars with the same color, unaffected by line types
  scale_color_manual(values = c("Short" ="#0072B2", "Medium" = "#CC79A7" , "Long" = "#E69F00")) +  # Custom colors
  scale_shape_manual(values = c(1, 5, 17)) +  # Shapes for each category (circle, triangle, square)
  scale_linetype_manual(values = c("solid", "solid","dashed")) +  # Different line types for the lines only
  labs(x = "Percentage", y = "Mean ± 1*SE", 
       title = "Mean and ±1 SE of Combined Data", color = "simulation", shape = "simulation", linetype = "simulation") +  # Adjust title and labels
  theme_minimal(base_size = 20) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.8, 1),       # Position the legend inside the plot
    legend.justification = c(1, 1),    # Align the legend to the top-right corner
    legend.direction = "horizontal",   # Horizontal legend items
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Border for plot
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10)),   # Add margin to y-axis labels
    plot.title = element_blank()
  ) +
  coord_cartesian(ylim = range(df_combined$means - df_combined$se, df_combined$means + df_combined$se))  # Manually set the y-axis limits



#############################################
# Plot the mean values with different colors for each simulation
library(ggplot2)
library(grid)  # For 'element_rect()'

# Data frame for plotting with means and SE for each simulation type
df_branchError <- data.frame(
  x_values = rep(x_values, 3),
  means = c(means_short_branchError, means_medium_branchError, means_long_branchError),
  se = c(se_short_branchError, se_medium_branchError, se_long_branchError),
  simulation = factor(rep(c("Short", "Medium", "Long"), each = length(x_values)))
)

# Calculate the maximum and minimum values for the y-axis limits
y_max <- max(df_branchError$means)+0.04
y_min <- min(df_branchError$means)


ggplot(df_branchError, aes(x = x_values, y = means, color = simulation, shape = simulation)) +
  geom_point(size = 3.5) +  # Points with different shapes
  geom_line(aes(linetype = simulation), linewidth = 0.8) +  # Lines with different line types
  geom_errorbar(aes(ymin = means - se, ymax = means + se), 
                width = 0.3, linewidth = 1, linetype = "solid") +  # Solid error bar lines with the same color
  scale_color_manual(values =c("Short" ="#0072B2", "Medium" = "#CC79A7" , "Long" = "#E69F00")) +  # Colors for each simulation
  scale_shape_manual(values = c(1,5, 17)) +  # Shapes for each simulation (16=circle, 17=triangle, 18=square)
  scale_linetype_manual(values = c("solid","solid" , "dashed")) +  # Different line types for each simulation
  labs(x = "Percentage", y = "Mean ± 1*SE", 
       title = "Mean and ±1 SD of branch errors", color = "Simulation Type", 
       shape = "Simulation Type", linetype = "Simulation Type") +  # Adjust title and labels
  theme_minimal(base_size = 20) +
  theme(
    plot.margin = margin(40, 20, 20, 20),  # Add extra space at the top of the plot
    legend.position = c(0.8, 1),       # Position the legend inside the plot (values between 0 and 1)
    legend.justification = c(1, 1),      # Ensure the legend is aligned properly (right-top corner of legend box)
    legend.direction = "horizontal",     # Place legend items in a horizontal line
    panel.grid.major = element_line(color = "lightgray", linetype = "dotted"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),  # Border for plot
    axis.text.x = element_text(margin = margin(t = 10)),  # Add margin to x-axis labels
    axis.text.y = element_text(margin = margin(r = 10)),# Add margin to y-axis labels
    plot.title = element_blank()
  ) +
  coord_cartesian(ylim = c(y_min, y_max))  # Manually set the y-axis limits

