# This script is to generate random trees in the Mislabelling Simulations.
# This script is for the Short branch length, therefore the tree branch lengths were divided by 10.
# For the Medium and Long branch length simulations, users can change the parameter: factor_BranchLength


setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation")
source("robust_phylo_functions.R")
library(ape)
library(phangorn)
library("stringr")
library(dplyr)
library(TreeSim)
#####################################################################
num_replicate<- 400
tree_list<-sim.bd.taxa(n=10,numbsim = num_replicate,lambda =0.9,mu = 0.15,complete = FALSE)

is.rooted(tree_list[[1]])
cat(write.tree(tree_list[[1]]))

for (i in 1:num_replicate){
  tree_list[[i]]<-unroot(tree_list[[i]])
}
cat(write.tree(tree_list[[1]]))

factor_BranchLength<-10

for (i in 1:num_replicate){
  tree_list[[i]]$edge.length<-tree_list[[i]]$edge.length/factor_BranchLength
}
cat(write.tree(tree_list[[1]]))


# save the trees
setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short/trees")
for (i in 1:num_replicate){
  filename <- paste0("tree-", i, ".tre")
  write.tree(tree_list[[i]], file = filename)
}


################################
# use R to generate 100 pair of numbers from (2-11), can't be repeated for each pair.
# This numbers decide which leaves to swap for each tree.

# Initialise an empty list to store the pairs
pairs_list <- list()

# Set the range of numbers
# tips are from 1 to 10, however, in the fst file, the alignment starts in row 2.
# so tip 1 will be in row 2, tip 10 will be in row 11. 
# That is why we need to use 2 and 11.

min_num <- 2
max_num <- 11

# Number of pairs to generate
num_pairs <- 400

for (i in 1:num_pairs) {
  # Generate a random pair of different numbers
  pair <- sample(min_num:max_num, 2, replace = FALSE)
  pairs_list[[i]] <- pair
}

# Print the first few pairs
head(pairs_list)

# Create a dataframe from the list
pairs_df <- as.data.frame(do.call(rbind, pairs_list))

# Rename the columns
colnames(pairs_df) <- c("FirstNumber", "SecondNumber")

# Print the first few rows of the dataframe
head(pairs_df)

range(pairs_df$FirstNumber)
range(pairs_df$SecondNumber)

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper/swap-leaves-short")

# save file
save(pairs_df,file="random_num.Rdata")

# Be awear that
write(pairs_df$FirstNumber, file = "random_num_first.txt", ncolumns = 1)

write(pairs_df$SecondNumber, file = "random_num_second.txt", ncolumns = 1)

# You need to manually delete row 401. Not sure why there is an empty row in the txt files.



