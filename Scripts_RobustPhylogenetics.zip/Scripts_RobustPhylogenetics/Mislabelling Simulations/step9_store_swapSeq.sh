# store the mislabelling data in a folder
mkdir sequence-swap

for Num in $(seq 1 1 400); 
do
mv $Num-simc1c2-swap.fst sequence-swap
done
