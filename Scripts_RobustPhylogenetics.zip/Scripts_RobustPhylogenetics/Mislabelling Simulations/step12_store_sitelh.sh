# This script is to store the sitelh files.

for k in $(seq 80 1 100);
do
for i in $(seq 1 1 400);
do

sed -n "2p" $k-per-results/$k-$i.sitelh > all_tree_sitelh_txt/$k-sitelh/$k-$i.sitelh

cut -c1-11 --complement  all_tree_sitelh_txt/$k-sitelh/$k-$i.sitelh > all_tree_sitelh_txt/$k-sitelh/$k-$i.txt

rm all_tree_sitelh_txt/$k-sitelh/$k-$i.sitelh

done
done

