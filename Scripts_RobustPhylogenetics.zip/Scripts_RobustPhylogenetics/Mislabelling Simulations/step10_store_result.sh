
# Store the IQTREE results
for i in $(seq 80 1 100);
do
mkdir $i-per-results
done

for i in $(seq 80 1 100);
do
for Num in $(seq 1 1 400); 
do
mv $i-$Num.iqtree $i-per-results
mv $i-$Num.sitelh $i-per-results
mv $i-$Num.treefile $i-per-results
done
done

# Remove unnecessary files.
rm *.bionj 
rm *.mldist 
rm *.ckp.gz 
rm *.log 
