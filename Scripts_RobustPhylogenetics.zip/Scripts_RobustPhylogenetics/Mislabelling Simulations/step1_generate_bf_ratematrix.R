# This script is to use to generate substitution model parameters (i.e. rate matrix and base frequencies) for the Mislabelling Simulations.


# The G-T rate is fixed at 1, and the other 5 transition rates were drawn randomly from a 
# uniform distribution in  [0.5, 5].
# Base frequencies: draw four uniform random numbers on [0,1], and normalized them to sum to 0.6,
# then added 0.1 to each value.

# Rate matrix

vec_Q<- round(runif(5, min=0.5, max =5),2)
# 2.12 3.12 0.91 4.96 1.37
vec_Q

# Base frequencies

# Generate four random numbers from a uniform distribution between 0 and 1
bf <- round(runif(4),2)
bf
# Normalize the numbers to sum up to 0.6
normalised_bf <- round(0.6 * (bf / sum(bf)),2)

normalised_bf
sum(normalised_bf)
# Add 0.1 to each value
vec_bf <- normalised_bf + 0.1

#  0.27 0.27 0.26 0.20
vec_bf
sum(vec_bf)

list_Q<-list()
list_bf<-list()
n_replicates<-400
for (i in 1:n_replicates){
  vec_Q<- round(runif(5, min=0.5, max =5),2)
  # 2.12 3.12 0.91 4.96 1.37
  vec_Q<-c(vec_Q,1)
  list_Q[[i]]<-vec_Q
  
}

# Loop to generate 100 vectors
for (i in 1:n_replicates) {
  repeat {
    bf <- round(runif(4), 2)
    
    # Normalize the numbers to sum up to 0.6
    normalised_bf <- round(0.6 * (bf / sum(bf)), 2)
    
    # Add 0.1 to each value
    vec_bf <- normalised_bf + 0.1
    
    # Check if the sum is equal to 1
    if (sum(vec_bf) == 1) {
      list_bf[[i]] <- vec_bf
      break
    }
  }
}

# Print the list of vectors
list_bf_short<-list_bf
list_Q_short<-list_Q


list_Q<-list()
list_bf<-list()
for (i in 1:n_replicates){
  vec_Q<- round(runif(5, min=0.5, max =5),2)
  # 2.12 3.12 0.91 4.96 1.37
  vec_Q<-c(vec_Q,1)
  list_Q[[i]]<-vec_Q
  
}

# Loop to generate 100 vectors
for (i in 1:n_replicates) {
  repeat {
    bf <- round(runif(4), 2)
    
    # Normalize the numbers to sum up to 0.6
    normalised_bf <- round(0.6 * (bf / sum(bf)), 2)
    
    # Add 0.1 to each value
    vec_bf <- normalised_bf + 0.1
    
    # Check if the sum is equal to 1
    if (sum(vec_bf) == 1) {
      list_bf[[i]] <- vec_bf
      break
    }
  }
}

# Print the list of vectors
list_bf_medium<-list_bf
list_Q_medium<-list_Q

list_Q<-list()
list_bf<-list()
for (i in 1:n_replicates){
  vec_Q<- round(runif(5, min=0.5, max =5),2)
  # 2.12 3.12 0.91 4.96 1.37
  vec_Q<-c(vec_Q,1)
  list_Q[[i]]<-vec_Q
  
}

# Loop to generate 100 vectors
for (i in 1:n_replicates) {
  repeat {
    bf <- round(runif(4), 2)
    
    # Normalize the numbers to sum up to 0.6
    normalised_bf <- round(0.6 * (bf / sum(bf)), 2)
    
    # Add 0.1 to each value
    vec_bf <- normalised_bf + 0.1
    
    # Check if the sum is equal to 1
    if (sum(vec_bf) == 1) {
      list_bf[[i]] <- vec_bf
      break
    }
  }
}

# Print the list of vectors
list_bf_long<-list_bf
list_Q_long<-list_Q

setwd("C:/QinPhDStudy/RobustPhylogenetics/RPsimulation/swap_labels_paper")

save(list_bf_short,list_Q_short,
     list_bf_medium,list_Q_medium,
     list_bf_long,list_Q_long,
     file ="swap_label_para.rdata")

###################################

list_Q_short

head(list_bf_short)
#####################
# Open a connection to write to a text file
model_parameter_bf_short <- file("model_parameter_bf_short.txt", "w")

# Loop through each element of the list and write to the file in the desired format
for (vec in list_bf_short) {
  # Create a string where the numbers are separated by a space
  line <- paste(sprintf('%.2f', vec), collapse = " ")
  # Write it to the file with quotes around the entire line
  writeLines(paste('"', line, '"', sep = ""), model_parameter_bf_short)
}

# Close the connection to the file
close(model_parameter_bf_short)
#####################
# Open a connection to write to a text file
model_parameter_bf_medium <- file("model_parameter_bf_medium.txt", "w")

# Loop through each element of the list and write to the file in the desired format
for (vec in list_bf_medium) {
  # Create a string where the numbers are separated by a space
  line <- paste(sprintf('%.2f', vec), collapse = " ")
  # Write it to the file with quotes around the entire line
  writeLines(paste('"', line, '"', sep = ""), model_parameter_bf_medium)
}

# Close the connection to the file
close(model_parameter_bf_medium)
#####################
# Open a connection to write to a text file
model_parameter_bf_long <- file("model_parameter_bf_long.txt", "w")

# Loop through each element of the list and write to the file in the desired format
for (vec in list_bf_long) {
  # Create a string where the numbers are separated by a space
  line <- paste(sprintf('%.2f', vec), collapse = " ")
  # Write it to the file with quotes around the entire line
  writeLines(paste('"', line, '"', sep = ""), model_parameter_bf_long)
}

# Close the connection to the file
close(model_parameter_bf_long)
############################################################################
# rate matrix
#####################
# Open a connection to write to a text file
model_parameter_Q_short <- file("model_parameter_Q_short.txt", "w")

# Loop through each element of the list and write to the file in the desired format
for (vec in list_Q_short) {
  # Create a string where the numbers are separated by a space
  line <- paste(sprintf('%.2f', vec), collapse = " ")
  # Write it to the file with quotes around the entire line
  writeLines(paste('"', line, '"', sep = ""), model_parameter_Q_short)
}

# Close the connection to the file
close(model_parameter_Q_short)
#####################
# Open a connection to write to a text file
model_parameter_Q_medium <- file("model_parameter_Q_medium.txt", "w")

# Loop through each element of the list and write to the file in the desired format
for (vec in list_Q_medium) {
  # Create a string where the numbers are separated by a space
  line <- paste(sprintf('%.2f', vec), collapse = " ")
  # Write it to the file with quotes around the entire line
  writeLines(paste('"', line, '"', sep = ""), model_parameter_Q_medium)
}

# Close the connection to the file
close(model_parameter_Q_medium)
#####################
# Open a connection to write to a text file
model_parameter_Q_long <- file("model_parameter_Q_long.txt", "w")

# Loop through each element of the list and write to the file in the desired format
for (vec in list_Q_long) {
  # Create a string where the numbers are separated by a space
  line <- paste(sprintf('%.2f', vec), collapse = " ")
  # Write it to the file with quotes around the entire line
  writeLines(paste('"', line, '"', sep = ""), model_parameter_Q_long)
}

# Close the connection to the file
close(model_parameter_Q_long)
